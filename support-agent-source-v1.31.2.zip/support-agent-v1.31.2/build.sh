#!/usr/bin/env bash
# SUPPORT AGENT 1.31.2 — one-command rebuild of the APK from the apktool project.
#
# Requirements: JDK 11+ (java), curl, unzip, bash.  First run downloads
# apktool 2.10.0 and Android build-tools r34 into ./tools/ (about 90 MB).
# Both can also be supplied via environment variables, see below.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="${SRC_DIR:-$ROOT/support-agent-src}"
if [ ! -d "$SRC" ] && [ -d "$ROOT/src" ]; then SRC="$ROOT/src"; fi
BUILD="$ROOT/build"
TOOLS="$ROOT/tools"
OUT="$ROOT/SUPPORT-AGENT-v1.31.2.apk"

APKTOOL_JAR="${APKTOOL_JAR:-$TOOLS/apktool_2.10.0.jar}"
BT_DIR="${ANDROID_BUILD_TOOLS:-$TOOLS/build-tools-r34}"
ZIPALIGN="${ZIPALIGN:-$BT_DIR/zipalign}"
APKSIGNER="${APKSIGNER:-$BT_DIR/apksigner}"
KEYSTORE="${KEYSTORE:-$ROOT/keystore/support-agent.jks}"
STOREPASS="${STOREPASS:-supportagent2026}"
KEYPASS="${KEYPASS:-supportagent2026}"

mkdir -p "$BUILD" "$TOOLS"

if [ ! -f "$APKTOOL_JAR" ]; then
  echo "==> downloading apktool 2.10.0"
  curl -fL --retry 3 -o "$APKTOOL_JAR" \
    "https://github.com/iBotPeaches/Apktool/releases/download/v2.10.0/apktool_2.10.0.jar"
fi

if [ ! -x "$ZIPALIGN" ] || [ ! -x "$APKSIGNER" ]; then
  echo "==> downloading Android build-tools r34"
  curl -fL --retry 3 -o "$TOOLS/build-tools.zip" \
    "https://dl.google.com/android/repository/build-tools_r34-linux.zip"
  rm -rf "$TOOLS/bt-tmp"
  mkdir -p "$TOOLS/bt-tmp" "$BT_DIR"
  unzip -q -o "$TOOLS/build-tools.zip" -d "$TOOLS/bt-tmp"
  cp -a "$TOOLS/bt-tmp"/android-14/. "$BT_DIR"/
  chmod +x "$BT_DIR/zipalign" "$BT_DIR/apksigner" "$BT_DIR/aapt2" 2>/dev/null || true
fi

if [ ! -f "$KEYSTORE" ]; then
  echo "ERROR: signing keystore not found: $KEYSTORE" >&2
  echo "Keep the bundled keystore — it is required so updates install over this build." >&2
  exit 1
fi

echo "==> building APK (apktool b)"
java -jar "$APKTOOL_JAR" b "$SRC" -o "$BUILD/unsigned.apk"

echo "==> zipalign"
"$ZIPALIGN" -f -p 4 "$BUILD/unsigned.apk" "$BUILD/aligned.apk"

echo "==> signing (v1 + v2 + v3)"
"$APKSIGNER" sign \
  --ks "$KEYSTORE" --ks-pass "pass:$STOREPASS" --key-pass "pass:$KEYPASS" \
  --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
  --v4-signing-enabled false --min-sdk-version 21 \
  --out "$OUT" "$BUILD/aligned.apk"

echo "==> verifying"
"$APKSIGNER" verify --min-sdk-version 21 --verbose "$OUT"

echo
echo "DONE: $OUT"
