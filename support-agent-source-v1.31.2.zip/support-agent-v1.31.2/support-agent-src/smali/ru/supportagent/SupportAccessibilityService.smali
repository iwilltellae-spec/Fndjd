.class public final Lru/supportagent/SupportAccessibilityService;
.super Landroid/accessibilityservice/AccessibilityService;
.source "SupportAccessibilityService.java"


# static fields
.field private static final BLACK_RUSSIA_PACKAGES:[Ljava/lang/String;


# instance fields
.field private statistics:Lru/supportagent/StatisticsRepository;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const-string v0, "com.launcher.brgame"

    const-string v1, "com.br.top"

    .line 16
    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lru/supportagent/SupportAccessibilityService;->BLACK_RUSSIA_PACKAGES:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 15
    invoke-direct {p0}, Landroid/accessibilityservice/AccessibilityService;-><init>()V

    return-void
.end method

.method private static isBlackRussiaPackage(Ljava/lang/String;)Z
    .locals 5

    .line 53
    sget-object v0, Lru/supportagent/SupportAccessibilityService;->BLACK_RUSSIA_PACKAGES:[Ljava/lang/String;

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    if-ge v3, v1, :cond_1

    aget-object v4, v0, v3

    invoke-virtual {v4, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    return v2
.end method

.method public static isEnabled(Landroid/content/Context;)Z
    .locals 5

    .line 67
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v1, "enabled_accessibility_services"

    invoke-static {v0, v1}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 68
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    return v2

    .line 69
    :cond_0
    new-instance v1, Landroid/content/ComponentName;

    const-class v3, Lru/supportagent/SupportAccessibilityService;

    invoke-direct {v1, p0, v3}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v1}, Landroid/content/ComponentName;->flattenToString()Ljava/lang/String;

    move-result-object p0

    const-string v1, ":"

    .line 70
    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    array-length v1, v0

    move v3, v2

    :goto_0
    if-ge v3, v1, :cond_2

    aget-object v4, v0, v3

    invoke-virtual {p0, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1

    const/4 p0, 0x1

    return p0

    :cond_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_2
    return v2
.end method

.method private static isSystemOrInputPackage(Ljava/lang/String;)Z
    .locals 1

    const-string v0, "com.android.systemui"

    .line 58
    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "com.android.inputmethod"

    .line 59
    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "com.google.android.inputmethod"

    .line 60
    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "com.swiftkey"

    .line 61
    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "com.huawei.inputmethod"

    .line 62
    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "android"

    .line 63
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method


# virtual methods
.method public onAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 3

    if-eqz p1, :cond_4

    .line 30
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_4

    iget-object v0, p0, Lru/supportagent/SupportAccessibilityService;->statistics:Lru/supportagent/StatisticsRepository;

    if-nez v0, :cond_0

    goto :goto_0

    .line 31
    :cond_0
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 32
    invoke-static {v0}, Lru/supportagent/SupportAccessibilityService;->isBlackRussiaPackage(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 33
    iget-object p1, p0, Lru/supportagent/SupportAccessibilityService;->statistics:Lru/supportagent/StatisticsRepository;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Lru/supportagent/StatisticsRepository;->setGameForeground(Z)V

    goto :goto_0

    .line 34
    :cond_1
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result v1

    const/16 v2, 0x20

    if-eq v1, v2, :cond_2

    .line 35
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result p1

    const/high16 v1, 0x400000

    if-ne p1, v1, :cond_4

    .line 36
    :cond_2
    invoke-virtual {p0}, Lru/supportagent/SupportAccessibilityService;->getPackageName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_3

    invoke-static {v0}, Lru/supportagent/SupportAccessibilityService;->isSystemOrInputPackage(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_4

    .line 37
    :cond_3
    iget-object p1, p0, Lru/supportagent/SupportAccessibilityService;->statistics:Lru/supportagent/StatisticsRepository;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lru/supportagent/StatisticsRepository;->setGameForeground(Z)V

    :cond_4
    :goto_0
    return-void
.end method

.method public onDestroy()V
    .locals 1

    .line 48
    iget-object v0, p0, Lru/supportagent/SupportAccessibilityService;->statistics:Lru/supportagent/StatisticsRepository;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lru/supportagent/StatisticsRepository;->stopGameTimer()V

    .line 49
    :cond_0
    invoke-super {p0}, Landroid/accessibilityservice/AccessibilityService;->onDestroy()V

    return-void
.end method

.method public onInterrupt()V
    .locals 1

    .line 43
    iget-object v0, p0, Lru/supportagent/SupportAccessibilityService;->statistics:Lru/supportagent/StatisticsRepository;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lru/supportagent/StatisticsRepository;->stopGameTimer()V

    :cond_0
    return-void
.end method

.method protected onServiceConnected()V
    .locals 1

    .line 24
    invoke-super {p0}, Landroid/accessibilityservice/AccessibilityService;->onServiceConnected()V

    .line 25
    new-instance v0, Lru/supportagent/StatisticsRepository;

    invoke-direct {v0, p0}, Lru/supportagent/StatisticsRepository;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lru/supportagent/SupportAccessibilityService;->statistics:Lru/supportagent/StatisticsRepository;

    return-void
.end method
