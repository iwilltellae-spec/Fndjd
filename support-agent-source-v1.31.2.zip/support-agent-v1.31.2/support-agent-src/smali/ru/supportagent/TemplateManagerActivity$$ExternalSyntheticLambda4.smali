.class public final synthetic Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/TemplateManagerActivity;

.field public final synthetic f$1:Landroidx/appcompat/app/AlertDialog;

.field public final synthetic f$2:Lru/supportagent/AnswerTemplate;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/TemplateManagerActivity;Landroidx/appcompat/app/AlertDialog;Lru/supportagent/AnswerTemplate;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda4;->f$0:Lru/supportagent/TemplateManagerActivity;

    iput-object p2, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda4;->f$1:Landroidx/appcompat/app/AlertDialog;

    iput-object p3, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda4;->f$2:Lru/supportagent/AnswerTemplate;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda4;->f$0:Lru/supportagent/TemplateManagerActivity;

    iget-object v1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda4;->f$1:Landroidx/appcompat/app/AlertDialog;

    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda4;->f$2:Lru/supportagent/AnswerTemplate;

    invoke-virtual {v0, v1, v2, p1}, Lru/supportagent/TemplateManagerActivity;->lambda$templateDialog$13$ru-supportagent-TemplateManagerActivity(Landroidx/appcompat/app/AlertDialog;Lru/supportagent/AnswerTemplate;Landroid/view/View;)V

    return-void
.end method
