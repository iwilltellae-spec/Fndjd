.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:Landroid/widget/EditText;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;Landroid/widget/EditText;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda0;->f$0:Lru/supportagent/OverlayService;

    iput-object p2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda0;->f$1:Landroid/widget/EditText;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda0;->f$0:Lru/supportagent/OverlayService;

    iget-object v1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda0;->f$1:Landroid/widget/EditText;

    invoke-virtual {v0, v1}, Lru/supportagent/OverlayService;->lambda$focusInput$7$ru-supportagent-OverlayService(Landroid/widget/EditText;)V

    return-void
.end method
