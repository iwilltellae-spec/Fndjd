.class public final synthetic Lru/supportagent/OverlayService$PanelDragTouchListener-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
