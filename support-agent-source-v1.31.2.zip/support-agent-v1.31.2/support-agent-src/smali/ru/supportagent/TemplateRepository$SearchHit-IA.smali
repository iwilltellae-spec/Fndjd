.class public final synthetic Lru/supportagent/TemplateRepository$SearchHit-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
