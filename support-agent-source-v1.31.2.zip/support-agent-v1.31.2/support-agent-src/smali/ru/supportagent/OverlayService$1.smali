.class Lru/supportagent/OverlayService$1;
.super Ljava/lang/Object;
.source "OverlayService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lru/supportagent/OverlayService;->startAiTypingAnimation()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lru/supportagent/OverlayService;


# direct methods
.method constructor <init>(Lru/supportagent/OverlayService;)V
    .locals 0

    .line 1356
    iput-object p1, p0, Lru/supportagent/OverlayService$1;->this$0:Lru/supportagent/OverlayService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 1358
    iget-object v0, p0, Lru/supportagent/OverlayService$1;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetaiRequestInFlight(Lru/supportagent/OverlayService;)Z

    move-result v0

    if-eqz v0, :cond_5

    iget-object v0, p0, Lru/supportagent/OverlayService$1;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetaiTypingIndicator(Lru/supportagent/OverlayService;)Landroid/widget/TextView;

    move-result-object v0

    if-eqz v0, :cond_5

    iget-object v0, p0, Lru/supportagent/OverlayService$1;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$misAiChatShowing(Lru/supportagent/OverlayService;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_2

    .line 1359
    :cond_0
    iget-object v0, p0, Lru/supportagent/OverlayService$1;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetaiTypingPhase(Lru/supportagent/OverlayService;)I

    move-result v0

    rem-int/lit8 v0, v0, 0x4

    const/4 v1, 0x1

    if-nez v0, :cond_1

    const-string v2, ""

    goto :goto_0

    :cond_1
    if-ne v0, v1, :cond_2

    const-string v2, "."

    goto :goto_0

    :cond_2
    const/4 v2, 0x2

    if-ne v0, v2, :cond_3

    const-string v2, ".."

    goto :goto_0

    :cond_3
    const-string v2, "..."

    .line 1361
    :goto_0
    iget-object v3, p0, Lru/supportagent/OverlayService$1;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v3}, Lru/supportagent/OverlayService;->-$$Nest$fgetaiTypingIndicator(Lru/supportagent/OverlayService;)Landroid/widget/TextView;

    move-result-object v3

    const-string v4, "AGENT \u041f\u0415\u0427\u0410\u0422\u0410\u0415\u0422"

    invoke-virtual {v4, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1362
    iget-object v2, p0, Lru/supportagent/OverlayService$1;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v2}, Lru/supportagent/OverlayService;->-$$Nest$fgetaiTypingIndicator(Lru/supportagent/OverlayService;)Landroid/widget/TextView;

    move-result-object v2

    if-nez v0, :cond_4

    const v0, 0x3f1eb852    # 0.62f

    goto :goto_1

    :cond_4
    const/high16 v0, 0x3f800000    # 1.0f

    :goto_1
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setAlpha(F)V

    .line 1363
    iget-object v0, p0, Lru/supportagent/OverlayService$1;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetaiTypingPhase(Lru/supportagent/OverlayService;)I

    move-result v2

    add-int/2addr v2, v1

    invoke-static {v0, v2}, Lru/supportagent/OverlayService;->-$$Nest$fputaiTypingPhase(Lru/supportagent/OverlayService;I)V

    .line 1364
    iget-object v0, p0, Lru/supportagent/OverlayService$1;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetsearchHandler(Lru/supportagent/OverlayService;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v1, 0x14a

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_5
    :goto_2
    return-void
.end method
