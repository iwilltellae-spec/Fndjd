.class public final Lru/supportagent/ColorWheelView;
.super Landroid/view/View;
.source "ColorWheelView.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lru/supportagent/ColorWheelView$OnColorChangedListener;
    }
.end annotation


# instance fields
.field private final bitmapPaint:Landroid/graphics/Paint;

.field private final borderPaint:Landroid/graphics/Paint;

.field private centerX:F

.field private centerY:F

.field private hue:F

.field private listener:Lru/supportagent/ColorWheelView$OnColorChangedListener;

.field private radius:F

.field private saturation:F

.field private final selectorPaint:Landroid/graphics/Paint;

.field private wheelBitmap:Landroid/graphics/Bitmap;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 33
    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 22
    new-instance p1, Landroid/graphics/Paint;

    const/4 v0, 0x3

    invoke-direct {p1, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lru/supportagent/ColorWheelView;->bitmapPaint:Landroid/graphics/Paint;

    .line 23
    new-instance p1, Landroid/graphics/Paint;

    const/4 v0, 0x1

    invoke-direct {p1, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lru/supportagent/ColorWheelView;->borderPaint:Landroid/graphics/Paint;

    .line 24
    new-instance p1, Landroid/graphics/Paint;

    invoke-direct {p1, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lru/supportagent/ColorWheelView;->selectorPaint:Landroid/graphics/Paint;

    const/high16 p1, 0x41000000    # 8.0f

    .line 29
    iput p1, p0, Lru/supportagent/ColorWheelView;->hue:F

    const p1, 0x3f6147ae    # 0.88f

    .line 30
    iput p1, p0, Lru/supportagent/ColorWheelView;->saturation:F

    .line 33
    invoke-direct {p0}, Lru/supportagent/ColorWheelView;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    .line 34
    invoke-direct {p0, p1, p2}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 22
    new-instance p1, Landroid/graphics/Paint;

    const/4 p2, 0x3

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lru/supportagent/ColorWheelView;->bitmapPaint:Landroid/graphics/Paint;

    .line 23
    new-instance p1, Landroid/graphics/Paint;

    const/4 p2, 0x1

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lru/supportagent/ColorWheelView;->borderPaint:Landroid/graphics/Paint;

    .line 24
    new-instance p1, Landroid/graphics/Paint;

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lru/supportagent/ColorWheelView;->selectorPaint:Landroid/graphics/Paint;

    const/high16 p1, 0x41000000    # 8.0f

    .line 29
    iput p1, p0, Lru/supportagent/ColorWheelView;->hue:F

    const p1, 0x3f6147ae    # 0.88f

    .line 30
    iput p1, p0, Lru/supportagent/ColorWheelView;->saturation:F

    .line 34
    invoke-direct {p0}, Lru/supportagent/ColorWheelView;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    .line 35
    invoke-direct {p0, p1, p2, p3}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 22
    new-instance p1, Landroid/graphics/Paint;

    const/4 p2, 0x3

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lru/supportagent/ColorWheelView;->bitmapPaint:Landroid/graphics/Paint;

    .line 23
    new-instance p1, Landroid/graphics/Paint;

    const/4 p2, 0x1

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lru/supportagent/ColorWheelView;->borderPaint:Landroid/graphics/Paint;

    .line 24
    new-instance p1, Landroid/graphics/Paint;

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lru/supportagent/ColorWheelView;->selectorPaint:Landroid/graphics/Paint;

    const/high16 p1, 0x41000000    # 8.0f

    .line 29
    iput p1, p0, Lru/supportagent/ColorWheelView;->hue:F

    const p1, 0x3f6147ae    # 0.88f

    .line 30
    iput p1, p0, Lru/supportagent/ColorWheelView;->saturation:F

    .line 35
    invoke-direct {p0}, Lru/supportagent/ColorWheelView;->init()V

    return-void
.end method

.method private init()V
    .locals 5

    const-string v0, "\u0412\u044b\u0431\u043e\u0440 \u0446\u0432\u0435\u0442\u0430"

    .line 38
    invoke-virtual {p0, v0}, Lru/supportagent/ColorWheelView;->setContentDescription(Ljava/lang/CharSequence;)V

    const/4 v0, 0x1

    .line 39
    invoke-virtual {p0, v0}, Lru/supportagent/ColorWheelView;->setFocusable(Z)V

    .line 40
    iget-object v0, p0, Lru/supportagent/ColorWheelView;->borderPaint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 41
    iget-object v0, p0, Lru/supportagent/ColorWheelView;->borderPaint:Landroid/graphics/Paint;

    invoke-virtual {p0}, Lru/supportagent/ColorWheelView;->getContext()Landroid/content/Context;

    move-result-object v1

    const/high16 v2, 0x3fc00000    # 1.5f

    invoke-static {v1, v2}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 42
    iget-object v0, p0, Lru/supportagent/ColorWheelView;->borderPaint:Landroid/graphics/Paint;

    const/16 v1, 0xf7

    const/16 v2, 0xfb

    const/16 v3, 0xdc

    const/16 v4, 0xf6

    invoke-static {v3, v4, v1, v2}, Landroid/graphics/Color;->argb(IIII)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 43
    iget-object v0, p0, Lru/supportagent/ColorWheelView;->selectorPaint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 44
    iget-object v0, p0, Lru/supportagent/ColorWheelView;->selectorPaint:Landroid/graphics/Paint;

    invoke-virtual {p0}, Lru/supportagent/ColorWheelView;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x4019999a    # 2.4f

    invoke-static {v1, v2}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 45
    iget-object v0, p0, Lru/supportagent/ColorWheelView;->selectorPaint:Landroid/graphics/Paint;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    return-void
.end method

.method private updateFromTouch(FF)V
    .locals 4

    .line 146
    iget v0, p0, Lru/supportagent/ColorWheelView;->centerX:F

    sub-float/2addr p1, v0

    .line 147
    iget v0, p0, Lru/supportagent/ColorWheelView;->centerY:F

    sub-float/2addr p2, v0

    mul-float v0, p1, p1

    mul-float v1, p2, p2

    add-float/2addr v0, v1

    float-to-double v0, v0

    .line 148
    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0

    double-to-float v0, v0

    .line 149
    iget v1, p0, Lru/supportagent/ColorWheelView;->radius:F

    const/4 v2, 0x0

    cmpg-float v2, v1, v2

    if-lez v2, :cond_1

    invoke-virtual {p0}, Lru/supportagent/ColorWheelView;->getContext()Landroid/content/Context;

    move-result-object v2

    const/high16 v3, 0x41400000    # 12.0f

    invoke-static {v2, v3}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    int-to-float v2, v2

    add-float/2addr v1, v2

    cmpl-float v1, v0, v1

    if-lez v1, :cond_0

    goto :goto_0

    .line 150
    :cond_0
    iget v1, p0, Lru/supportagent/ColorWheelView;->radius:F

    div-float/2addr v0, v1

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const v1, 0x3ca3d70a    # 0.02f

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    iput v0, p0, Lru/supportagent/ColorWheelView;->saturation:F

    float-to-double v0, p2

    float-to-double p1, p1

    .line 151
    invoke-static {v0, v1, p1, p2}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide p1

    invoke-static {p1, p2}, Ljava/lang/Math;->toDegrees(D)D

    move-result-wide p1

    const-wide v0, 0x4076800000000000L    # 360.0

    add-double/2addr p1, v0

    rem-double/2addr p1, v0

    double-to-float p1, p1

    iput p1, p0, Lru/supportagent/ColorWheelView;->hue:F

    .line 152
    invoke-virtual {p0}, Lru/supportagent/ColorWheelView;->invalidate()V

    .line 153
    iget-object p1, p0, Lru/supportagent/ColorWheelView;->listener:Lru/supportagent/ColorWheelView$OnColorChangedListener;

    if-eqz p1, :cond_1

    invoke-virtual {p0}, Lru/supportagent/ColorWheelView;->getColor()I

    move-result p2

    invoke-interface {p1, p2}, Lru/supportagent/ColorWheelView$OnColorChangedListener;->onColorChanged(I)V

    :cond_1
    :goto_0
    return-void
.end method


# virtual methods
.method public getColor()I
    .locals 3

    const/4 v0, 0x3

    new-array v0, v0, [F

    const/4 v1, 0x0

    .line 61
    iget v2, p0, Lru/supportagent/ColorWheelView;->hue:F

    aput v2, v0, v1

    const/4 v1, 0x1

    iget v2, p0, Lru/supportagent/ColorWheelView;->saturation:F

    aput v2, v0, v1

    const/4 v1, 0x2

    const/high16 v2, 0x3f800000    # 1.0f

    aput v2, v0, v1

    invoke-static {v0}, Landroid/graphics/Color;->HSVToColor([F)I

    move-result v0

    return v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 7

    .line 104
    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    .line 105
    iget-object v0, p0, Lru/supportagent/ColorWheelView;->wheelBitmap:Landroid/graphics/Bitmap;

    if-nez v0, :cond_0

    return-void

    .line 106
    :cond_0
    new-instance v0, Landroid/graphics/RectF;

    iget v1, p0, Lru/supportagent/ColorWheelView;->centerX:F

    iget v2, p0, Lru/supportagent/ColorWheelView;->radius:F

    sub-float v3, v1, v2

    iget v4, p0, Lru/supportagent/ColorWheelView;->centerY:F

    sub-float v5, v4, v2

    add-float/2addr v1, v2

    add-float/2addr v4, v2

    invoke-direct {v0, v3, v5, v1, v4}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 107
    iget-object v1, p0, Lru/supportagent/ColorWheelView;->wheelBitmap:Landroid/graphics/Bitmap;

    const/4 v2, 0x0

    iget-object v3, p0, Lru/supportagent/ColorWheelView;->bitmapPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v2, v0, v3}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 108
    iget v0, p0, Lru/supportagent/ColorWheelView;->centerX:F

    iget v1, p0, Lru/supportagent/ColorWheelView;->centerY:F

    iget v2, p0, Lru/supportagent/ColorWheelView;->radius:F

    iget-object v3, p0, Lru/supportagent/ColorWheelView;->borderPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v2, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 109
    iget v0, p0, Lru/supportagent/ColorWheelView;->hue:F

    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v0

    double-to-float v0, v0

    .line 110
    iget v1, p0, Lru/supportagent/ColorWheelView;->saturation:F

    iget v2, p0, Lru/supportagent/ColorWheelView;->radius:F

    mul-float/2addr v1, v2

    .line 111
    iget v2, p0, Lru/supportagent/ColorWheelView;->centerX:F

    float-to-double v3, v0

    invoke-static {v3, v4}, Ljava/lang/Math;->cos(D)D

    move-result-wide v5

    double-to-float v0, v5

    mul-float/2addr v0, v1

    add-float/2addr v2, v0

    .line 112
    iget v0, p0, Lru/supportagent/ColorWheelView;->centerY:F

    invoke-static {v3, v4}, Ljava/lang/Math;->sin(D)D

    move-result-wide v3

    double-to-float v3, v3

    mul-float/2addr v3, v1

    add-float/2addr v0, v3

    .line 113
    invoke-virtual {p0}, Lru/supportagent/ColorWheelView;->getContext()Landroid/content/Context;

    move-result-object v1

    const/high16 v3, 0x40e00000    # 7.0f

    invoke-static {v1, v3}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    int-to-float v1, v1

    iget-object v3, p0, Lru/supportagent/ColorWheelView;->selectorPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v2, v0, v1, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 114
    iget-object v1, p0, Lru/supportagent/ColorWheelView;->selectorPaint:Landroid/graphics/Paint;

    const/16 v3, 0x10

    const/16 v4, 0x1c

    const/16 v5, 0xbe

    const/16 v6, 0x9

    invoke-static {v5, v6, v3, v4}, Landroid/graphics/Color;->argb(IIII)I

    move-result v3

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 115
    iget-object v1, p0, Lru/supportagent/ColorWheelView;->selectorPaint:Landroid/graphics/Paint;

    invoke-virtual {p0}, Lru/supportagent/ColorWheelView;->getContext()Landroid/content/Context;

    move-result-object v3

    const v4, 0x3f99999a    # 1.2f

    invoke-static {v3, v4}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 116
    invoke-virtual {p0}, Lru/supportagent/ColorWheelView;->getContext()Landroid/content/Context;

    move-result-object v1

    const/high16 v3, 0x41100000    # 9.0f

    invoke-static {v1, v3}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    int-to-float v1, v1

    iget-object v3, p0, Lru/supportagent/ColorWheelView;->selectorPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v2, v0, v1, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 117
    iget-object p1, p0, Lru/supportagent/ColorWheelView;->selectorPaint:Landroid/graphics/Paint;

    const/4 v0, -0x1

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 118
    iget-object p1, p0, Lru/supportagent/ColorWheelView;->selectorPaint:Landroid/graphics/Paint;

    invoke-virtual {p0}, Lru/supportagent/ColorWheelView;->getContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x4019999a    # 2.4f

    invoke-static {v0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    return-void
.end method

.method protected onMeasure(II)V
    .locals 2

    .line 66
    invoke-virtual {p0}, Lru/supportagent/ColorWheelView;->getContext()Landroid/content/Context;

    move-result-object v0

    const/high16 v1, 0x43040000    # 132.0f

    invoke-static {v0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    .line 67
    invoke-static {v0, p1}, Lru/supportagent/ColorWheelView;->resolveSize(II)I

    move-result p1

    .line 68
    invoke-static {v0, p2}, Lru/supportagent/ColorWheelView;->resolveSize(II)I

    move-result p2

    .line 69
    invoke-virtual {p0}, Lru/supportagent/ColorWheelView;->getContext()Landroid/content/Context;

    move-result-object v0

    const/high16 v1, 0x42a40000    # 82.0f

    invoke-static {v0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    invoke-static {p1, p2}, Ljava/lang/Math;->min(II)I

    move-result p1

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    .line 70
    invoke-virtual {p0, p1, p1}, Lru/supportagent/ColorWheelView;->setMeasuredDimension(II)V

    return-void
.end method

.method protected onSizeChanged(IIII)V
    .locals 11

    .line 75
    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/View;->onSizeChanged(IIII)V

    .line 76
    invoke-virtual {p0}, Lru/supportagent/ColorWheelView;->getContext()Landroid/content/Context;

    move-result-object p3

    const/high16 p4, 0x40a00000    # 5.0f

    invoke-static {p3, p4}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result p3

    .line 77
    invoke-static {p1, p2}, Ljava/lang/Math;->min(II)I

    move-result p4

    const/4 v0, 0x2

    mul-int/2addr p3, v0

    sub-int/2addr p4, p3

    const/4 p3, 0x1

    invoke-static {p3, p4}, Ljava/lang/Math;->max(II)I

    move-result v8

    int-to-float p1, p1

    const/high16 p4, 0x40000000    # 2.0f

    div-float/2addr p1, p4

    .line 78
    iput p1, p0, Lru/supportagent/ColorWheelView;->centerX:F

    int-to-float p1, p2

    div-float/2addr p1, p4

    .line 79
    iput p1, p0, Lru/supportagent/ColorWheelView;->centerY:F

    int-to-float p1, v8

    div-float/2addr p1, p4

    .line 80
    iput p1, p0, Lru/supportagent/ColorWheelView;->radius:F

    .line 81
    sget-object p1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v8, v8, p1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object p1

    iput-object p1, p0, Lru/supportagent/ColorWheelView;->wheelBitmap:Landroid/graphics/Bitmap;

    mul-int p1, v8, v8

    .line 82
    new-array v2, p1, [I

    add-int/lit8 p1, v8, -0x1

    int-to-float p1, p1

    div-float/2addr p1, p4

    const/4 p2, 0x0

    move p4, p2

    :goto_0
    if-ge p4, v8, :cond_2

    move v1, p2

    :goto_1
    if-ge v1, v8, :cond_1

    int-to-float v3, v1

    sub-float/2addr v3, p1

    int-to-float v4, p4

    sub-float/2addr v4, p1

    mul-float v5, v3, v3

    mul-float v6, v4, v4

    add-float/2addr v5, v6

    float-to-double v5, v5

    .line 88
    invoke-static {v5, v6}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v5

    double-to-float v5, v5

    mul-int v6, p4, v8

    add-int/2addr v6, v1

    cmpl-float v7, v5, p1

    if-lez v7, :cond_0

    .line 91
    aput p2, v2, v6

    goto :goto_2

    :cond_0
    float-to-double v9, v4

    float-to-double v3, v3

    .line 93
    invoke-static {v9, v10, v3, v4}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Math;->toDegrees(D)D

    move-result-wide v3

    const-wide v9, 0x4076800000000000L    # 360.0

    add-double/2addr v3, v9

    rem-double/2addr v3, v9

    double-to-float v3, v3

    const/high16 v4, 0x3f800000    # 1.0f

    .line 94
    invoke-static {v4, p1}, Ljava/lang/Math;->max(FF)F

    move-result v7

    div-float/2addr v5, v7

    invoke-static {v4, v5}, Ljava/lang/Math;->min(FF)F

    move-result v5

    const/4 v7, 0x3

    new-array v7, v7, [F

    aput v3, v7, p2

    aput v5, v7, p3

    aput v4, v7, v0

    .line 95
    invoke-static {v7}, Landroid/graphics/Color;->HSVToColor([F)I

    move-result v3

    aput v3, v2, v6

    :goto_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_1
    add-int/lit8 p4, p4, 0x1

    goto :goto_0

    .line 99
    :cond_2
    iget-object v1, p0, Lru/supportagent/ColorWheelView;->wheelBitmap:Landroid/graphics/Bitmap;

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move v4, v8

    move v7, v8

    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Bitmap;->setPixels([IIIIIII)V

    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 3

    .line 123
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_2

    if-eq v0, v1, :cond_1

    const/4 v2, 0x2

    if-eq v0, v2, :cond_2

    const/4 v2, 0x3

    if-eq v0, v2, :cond_0

    .line 135
    invoke-super {p0, p1}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    return p1

    :cond_0
    return v1

    .line 129
    :cond_1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    invoke-direct {p0, v0, p1}, Lru/supportagent/ColorWheelView;->updateFromTouch(FF)V

    .line 130
    invoke-virtual {p0}, Lru/supportagent/ColorWheelView;->performClick()Z

    return v1

    .line 126
    :cond_2
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    invoke-direct {p0, v0, p1}, Lru/supportagent/ColorWheelView;->updateFromTouch(FF)V

    return v1
.end method

.method public performClick()Z
    .locals 1

    .line 141
    invoke-super {p0}, Landroid/view/View;->performClick()Z

    const/4 v0, 0x1

    return v0
.end method

.method public setColor(I)V
    .locals 1

    const/4 v0, 0x3

    new-array v0, v0, [F

    .line 54
    invoke-static {p1, v0}, Landroid/graphics/Color;->colorToHSV(I[F)V

    const/4 p1, 0x0

    aget p1, v0, p1

    .line 55
    iput p1, p0, Lru/supportagent/ColorWheelView;->hue:F

    const/4 p1, 0x1

    aget p1, v0, p1

    const/high16 v0, 0x3f800000    # 1.0f

    .line 56
    invoke-static {v0, p1}, Ljava/lang/Math;->min(FF)F

    move-result p1

    const v0, 0x3ca3d70a    # 0.02f

    invoke-static {v0, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    iput p1, p0, Lru/supportagent/ColorWheelView;->saturation:F

    .line 57
    invoke-virtual {p0}, Lru/supportagent/ColorWheelView;->invalidate()V

    return-void
.end method

.method public setOnColorChangedListener(Lru/supportagent/ColorWheelView$OnColorChangedListener;)V
    .locals 0

    .line 49
    iput-object p1, p0, Lru/supportagent/ColorWheelView;->listener:Lru/supportagent/ColorWheelView$OnColorChangedListener;

    return-void
.end method
