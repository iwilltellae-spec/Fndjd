.class public final synthetic Lru/supportagent/MainActivity$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lru/supportagent/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/MainActivity$$ExternalSyntheticLambda0;->f$0:Lru/supportagent/MainActivity;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, Lru/supportagent/MainActivity$$ExternalSyntheticLambda0;->f$0:Lru/supportagent/MainActivity;

    invoke-static {v0}, Lru/supportagent/MainActivity;->$r8$lambda$4Woha_Lm5Lvdl4GBj26i9ks3J8s(Lru/supportagent/MainActivity;)V

    return-void
.end method
