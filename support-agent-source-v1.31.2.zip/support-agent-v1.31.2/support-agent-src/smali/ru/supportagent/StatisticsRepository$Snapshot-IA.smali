.class public final synthetic Lru/supportagent/StatisticsRepository$Snapshot-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
