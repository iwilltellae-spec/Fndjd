.class public final Lru/supportagent/PermissionTick;
.super Ljava/lang/Object;
.source "PermissionTick.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final f$0:Lru/supportagent/OverlayService;


# direct methods
.method public constructor <init>(Lru/supportagent/OverlayService;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/PermissionTick;->f$0:Lru/supportagent/OverlayService;

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object v0, p0, Lru/supportagent/PermissionTick;->f$0:Lru/supportagent/OverlayService;

    invoke-virtual {v0}, Lru/supportagent/OverlayService;->onPermissionTick()V

    return-void
.end method
