.class public final synthetic Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/TemplateManagerActivity;

.field public final synthetic f$1:Lru/supportagent/AnswerTemplate;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/TemplateManagerActivity;Lru/supportagent/AnswerTemplate;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda6;->f$0:Lru/supportagent/TemplateManagerActivity;

    iput-object p2, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda6;->f$1:Lru/supportagent/AnswerTemplate;

    return-void
.end method


# virtual methods
.method public final onLongClick(Landroid/view/View;)Z
    .locals 2

    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda6;->f$0:Lru/supportagent/TemplateManagerActivity;

    iget-object v1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda6;->f$1:Lru/supportagent/AnswerTemplate;

    invoke-virtual {v0, v1, p1}, Lru/supportagent/TemplateManagerActivity;->lambda$templateCard$6$ru-supportagent-TemplateManagerActivity(Lru/supportagent/AnswerTemplate;Landroid/view/View;)Z

    move-result p1

    return p1
.end method
