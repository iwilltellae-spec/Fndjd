.class public final synthetic Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/TemplateManagerActivity;

.field public final synthetic f$1:Lru/supportagent/AnswerTemplate;

.field public final synthetic f$2:Landroid/widget/EditText;

.field public final synthetic f$3:Landroid/widget/EditText;

.field public final synthetic f$4:Landroidx/appcompat/app/AlertDialog;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/TemplateManagerActivity;Lru/supportagent/AnswerTemplate;Landroid/widget/EditText;Landroid/widget/EditText;Landroidx/appcompat/app/AlertDialog;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda3;->f$0:Lru/supportagent/TemplateManagerActivity;

    iput-object p2, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda3;->f$1:Lru/supportagent/AnswerTemplate;

    iput-object p3, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda3;->f$2:Landroid/widget/EditText;

    iput-object p4, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda3;->f$3:Landroid/widget/EditText;

    iput-object p5, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda3;->f$4:Landroidx/appcompat/app/AlertDialog;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda3;->f$0:Lru/supportagent/TemplateManagerActivity;

    iget-object v1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda3;->f$1:Lru/supportagent/AnswerTemplate;

    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda3;->f$2:Landroid/widget/EditText;

    iget-object v3, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda3;->f$3:Landroid/widget/EditText;

    iget-object v4, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda3;->f$4:Landroidx/appcompat/app/AlertDialog;

    move-object v5, p1

    invoke-virtual/range {v0 .. v5}, Lru/supportagent/TemplateManagerActivity;->lambda$templateDialog$12$ru-supportagent-TemplateManagerActivity(Lru/supportagent/AnswerTemplate;Landroid/widget/EditText;Landroid/widget/EditText;Landroidx/appcompat/app/AlertDialog;Landroid/view/View;)V

    return-void
.end method
