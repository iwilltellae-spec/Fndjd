.class Lru/supportagent/OverlayService$4;
.super Ljava/lang/Object;
.source "OverlayService.java"

# interfaces
.implements Landroid/text/TextWatcher;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lru/supportagent/OverlayService;->debouncedSearchWatcher(Lru/supportagent/OverlayService$SearchRenderer;)Landroid/text/TextWatcher;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lru/supportagent/OverlayService;

.field final synthetic val$renderer:Lru/supportagent/OverlayService$SearchRenderer;


# direct methods
.method constructor <init>(Lru/supportagent/OverlayService;Lru/supportagent/OverlayService$SearchRenderer;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 2508
    iput-object p1, p0, Lru/supportagent/OverlayService$4;->this$0:Lru/supportagent/OverlayService;

    iput-object p2, p0, Lru/supportagent/OverlayService$4;->val$renderer:Lru/supportagent/OverlayService$SearchRenderer;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public afterTextChanged(Landroid/text/Editable;)V
    .locals 0

    return-void
.end method

.method public beforeTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 2511
    iget-object p2, p0, Lru/supportagent/OverlayService$4;->this$0:Lru/supportagent/OverlayService;

    if-nez p1, :cond_0

    const-string p1, ""

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_0
    iget-object p3, p0, Lru/supportagent/OverlayService$4;->val$renderer:Lru/supportagent/OverlayService$SearchRenderer;

    invoke-static {p2, p1, p3}, Lru/supportagent/OverlayService;->-$$Nest$mscheduleSearchRender(Lru/supportagent/OverlayService;Ljava/lang/String;Lru/supportagent/OverlayService$SearchRenderer;)V

    return-void
.end method
