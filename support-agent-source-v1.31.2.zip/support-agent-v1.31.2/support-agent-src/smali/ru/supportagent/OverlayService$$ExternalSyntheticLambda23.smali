.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda23;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:Lru/supportagent/AnswerTemplate;

.field public final synthetic f$2:Lru/supportagent/Topic;

.field public final synthetic f$3:Landroid/widget/EditText;

.field public final synthetic f$4:Landroid/widget/EditText;

.field public final synthetic f$5:Landroid/widget/EditText;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;Lru/supportagent/AnswerTemplate;Lru/supportagent/Topic;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda23;->f$0:Lru/supportagent/OverlayService;

    iput-object p2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda23;->f$1:Lru/supportagent/AnswerTemplate;

    iput-object p3, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda23;->f$2:Lru/supportagent/Topic;

    iput-object p4, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda23;->f$3:Landroid/widget/EditText;

    iput-object p5, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda23;->f$4:Landroid/widget/EditText;

    iput-object p6, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda23;->f$5:Landroid/widget/EditText;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 7

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda23;->f$0:Lru/supportagent/OverlayService;

    iget-object v1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda23;->f$1:Lru/supportagent/AnswerTemplate;

    iget-object v2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda23;->f$2:Lru/supportagent/Topic;

    iget-object v3, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda23;->f$3:Landroid/widget/EditText;

    iget-object v4, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda23;->f$4:Landroid/widget/EditText;

    iget-object v5, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda23;->f$5:Landroid/widget/EditText;

    move-object v6, p1

    invoke-virtual/range {v0 .. v6}, Lru/supportagent/OverlayService;->lambda$showAnswerEditor$64$ru-supportagent-OverlayService(Lru/supportagent/AnswerTemplate;Lru/supportagent/Topic;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/view/View;)V

    return-void
.end method
