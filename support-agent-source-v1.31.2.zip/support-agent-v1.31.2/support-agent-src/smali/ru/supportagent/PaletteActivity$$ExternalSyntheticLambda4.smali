.class public final synthetic Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/PaletteActivity;

.field public final synthetic f$1:Landroid/widget/EditText;

.field public final synthetic f$2:Landroid/widget/EditText;

.field public final synthetic f$3:Landroid/widget/EditText;

.field public final synthetic f$4:Landroid/widget/EditText;

.field public final synthetic f$5:Landroid/widget/EditText;

.field public final synthetic f$6:Landroidx/appcompat/app/AlertDialog;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/PaletteActivity;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroidx/appcompat/app/AlertDialog;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;->f$0:Lru/supportagent/PaletteActivity;

    iput-object p2, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;->f$1:Landroid/widget/EditText;

    iput-object p3, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;->f$2:Landroid/widget/EditText;

    iput-object p4, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;->f$3:Landroid/widget/EditText;

    iput-object p5, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;->f$4:Landroid/widget/EditText;

    iput-object p6, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;->f$5:Landroid/widget/EditText;

    iput-object p7, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;->f$6:Landroidx/appcompat/app/AlertDialog;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 8

    iget-object v0, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;->f$0:Lru/supportagent/PaletteActivity;

    iget-object v1, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;->f$1:Landroid/widget/EditText;

    iget-object v2, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;->f$2:Landroid/widget/EditText;

    iget-object v3, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;->f$3:Landroid/widget/EditText;

    iget-object v4, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;->f$4:Landroid/widget/EditText;

    iget-object v5, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;->f$5:Landroid/widget/EditText;

    iget-object v6, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;->f$6:Landroidx/appcompat/app/AlertDialog;

    move-object v7, p1

    invoke-virtual/range {v0 .. v7}, Lru/supportagent/PaletteActivity;->lambda$customPaletteDialog$4$ru-supportagent-PaletteActivity(Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroidx/appcompat/app/AlertDialog;Landroid/view/View;)V

    return-void
.end method
