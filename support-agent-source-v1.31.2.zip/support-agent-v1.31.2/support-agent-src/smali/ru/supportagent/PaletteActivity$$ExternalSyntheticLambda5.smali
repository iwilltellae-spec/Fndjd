.class public final synthetic Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnShowListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/PaletteActivity;

.field public final synthetic f$1:Landroidx/appcompat/app/AlertDialog;

.field public final synthetic f$2:Landroid/widget/EditText;

.field public final synthetic f$3:Landroid/widget/EditText;

.field public final synthetic f$4:Landroid/widget/EditText;

.field public final synthetic f$5:Landroid/widget/EditText;

.field public final synthetic f$6:Landroid/widget/EditText;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/PaletteActivity;Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;->f$0:Lru/supportagent/PaletteActivity;

    iput-object p2, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;->f$1:Landroidx/appcompat/app/AlertDialog;

    iput-object p3, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;->f$2:Landroid/widget/EditText;

    iput-object p4, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;->f$3:Landroid/widget/EditText;

    iput-object p5, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;->f$4:Landroid/widget/EditText;

    iput-object p6, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;->f$5:Landroid/widget/EditText;

    iput-object p7, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;->f$6:Landroid/widget/EditText;

    return-void
.end method


# virtual methods
.method public final onShow(Landroid/content/DialogInterface;)V
    .locals 8

    iget-object v0, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;->f$0:Lru/supportagent/PaletteActivity;

    iget-object v1, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;->f$1:Landroidx/appcompat/app/AlertDialog;

    iget-object v2, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;->f$2:Landroid/widget/EditText;

    iget-object v3, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;->f$3:Landroid/widget/EditText;

    iget-object v4, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;->f$4:Landroid/widget/EditText;

    iget-object v5, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;->f$5:Landroid/widget/EditText;

    iget-object v6, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;->f$6:Landroid/widget/EditText;

    move-object v7, p1

    invoke-virtual/range {v0 .. v7}, Lru/supportagent/PaletteActivity;->lambda$customPaletteDialog$5$ru-supportagent-PaletteActivity(Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/content/DialogInterface;)V

    return-void
.end method
