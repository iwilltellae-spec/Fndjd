.class public final synthetic Lru/supportagent/SearchHistoryDrop;
.super Ljava/lang/Object;
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lru/supportagent/SearchHistoryDrop;->f$0:Lru/supportagent/OverlayService;

    iput-object p2, p0, Lru/supportagent/SearchHistoryDrop;->f$1:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Lru/supportagent/SearchHistoryDrop;->f$0:Lru/supportagent/OverlayService;

    iget-object p1, p0, Lru/supportagent/SearchHistoryDrop;->f$1:Ljava/lang/String;

    invoke-virtual {v0, p1}, Lru/supportagent/OverlayService;->dropSearchHistory(Ljava/lang/String;)V

    return-void
.end method
