.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lru/supportagent/ColorWheelView$OnColorChangedListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:[I

.field public final synthetic f$2:Landroid/widget/LinearLayout;

.field public final synthetic f$3:Landroid/widget/TextView;

.field public final synthetic f$4:Landroid/widget/TextView;

.field public final synthetic f$5:Landroid/widget/TextView;

.field public final synthetic f$6:Landroid/widget/TextView;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;[ILandroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;->f$0:Lru/supportagent/OverlayService;

    iput-object p2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;->f$1:[I

    iput-object p3, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;->f$2:Landroid/widget/LinearLayout;

    iput-object p4, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;->f$3:Landroid/widget/TextView;

    iput-object p5, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;->f$4:Landroid/widget/TextView;

    iput-object p6, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;->f$5:Landroid/widget/TextView;

    iput-object p7, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;->f$6:Landroid/widget/TextView;

    return-void
.end method


# virtual methods
.method public final onColorChanged(I)V
    .locals 8

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;->f$0:Lru/supportagent/OverlayService;

    iget-object v1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;->f$1:[I

    iget-object v2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;->f$2:Landroid/widget/LinearLayout;

    iget-object v3, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;->f$3:Landroid/widget/TextView;

    iget-object v4, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;->f$4:Landroid/widget/TextView;

    iget-object v5, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;->f$5:Landroid/widget/TextView;

    iget-object v6, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;->f$6:Landroid/widget/TextView;

    move v7, p1

    invoke-virtual/range {v0 .. v7}, Lru/supportagent/OverlayService;->lambda$showManageThemes$53$ru-supportagent-OverlayService([ILandroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;I)V

    return-void
.end method
