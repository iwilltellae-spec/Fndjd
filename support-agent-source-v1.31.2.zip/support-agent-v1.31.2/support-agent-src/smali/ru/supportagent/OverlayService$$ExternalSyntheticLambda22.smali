.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda22;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:Landroid/widget/ImageView;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;Landroid/widget/ImageView;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda22;->f$0:Lru/supportagent/OverlayService;

    iput-object p2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda22;->f$1:Landroid/widget/ImageView;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda22;->f$0:Lru/supportagent/OverlayService;

    iget-object v1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda22;->f$1:Landroid/widget/ImageView;

    invoke-virtual {v0, v1, p1}, Lru/supportagent/OverlayService;->lambda$shell$2$ru-supportagent-OverlayService(Landroid/widget/ImageView;Landroid/view/View;)V

    return-void
.end method
