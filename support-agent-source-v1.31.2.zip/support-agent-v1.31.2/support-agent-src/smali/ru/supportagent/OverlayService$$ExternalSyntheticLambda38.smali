.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda38;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:Lru/supportagent/Topic;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;Lru/supportagent/Topic;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda38;->f$0:Lru/supportagent/OverlayService;

    iput-object p2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda38;->f$1:Lru/supportagent/Topic;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda38;->f$0:Lru/supportagent/OverlayService;

    iget-object v1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda38;->f$1:Lru/supportagent/Topic;

    invoke-virtual {v0, v1}, Lru/supportagent/OverlayService;->lambda$showTopicSearch$43$ru-supportagent-OverlayService(Lru/supportagent/Topic;)V

    return-void
.end method
