.class public final synthetic Lru/supportagent/GpsShiftPick;
.super Ljava/lang/Object;
.implements Landroid/view/View$OnClickListener;

.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:I

.method public synthetic constructor <init>(Lru/supportagent/OverlayService;I)V
    .locals 0

    iput-object p1, p0, Lru/supportagent/GpsShiftPick;->f$0:Lru/supportagent/OverlayService;

    iput p2, p0, Lru/supportagent/GpsShiftPick;->f$1:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public final onClick(Landroid/view/View;)V
    .locals 2

    iget-object v0, p0, Lru/supportagent/GpsShiftPick;->f$0:Lru/supportagent/OverlayService;

    iget v1, p0, Lru/supportagent/GpsShiftPick;->f$1:I

    invoke-virtual {v0, v1}, Lru/supportagent/OverlayService;->pickGpsShift(I)V

    return-void
.end method
