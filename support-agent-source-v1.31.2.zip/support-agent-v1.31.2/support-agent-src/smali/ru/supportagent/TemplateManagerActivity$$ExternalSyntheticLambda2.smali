.class public final synthetic Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lru/supportagent/TemplateManagerActivity;

.field public final synthetic f$1:Landroid/widget/EditText;

.field public final synthetic f$2:Landroid/widget/TextView;

.field public final synthetic f$3:Landroidx/appcompat/app/AlertDialog;

.field public final synthetic f$4:Landroid/widget/EditText;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/TemplateManagerActivity;Landroid/widget/EditText;Landroid/widget/TextView;Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda2;->f$0:Lru/supportagent/TemplateManagerActivity;

    iput-object p2, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda2;->f$1:Landroid/widget/EditText;

    iput-object p3, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda2;->f$2:Landroid/widget/TextView;

    iput-object p4, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda2;->f$3:Landroidx/appcompat/app/AlertDialog;

    iput-object p5, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda2;->f$4:Landroid/widget/EditText;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda2;->f$0:Lru/supportagent/TemplateManagerActivity;

    iget-object v1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda2;->f$1:Landroid/widget/EditText;

    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda2;->f$2:Landroid/widget/TextView;

    iget-object v3, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda2;->f$3:Landroidx/appcompat/app/AlertDialog;

    iget-object v4, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda2;->f$4:Landroid/widget/EditText;

    invoke-virtual {v0, v1, v2, v3, v4}, Lru/supportagent/TemplateManagerActivity;->lambda$templateDialog$11$ru-supportagent-TemplateManagerActivity(Landroid/widget/EditText;Landroid/widget/TextView;Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;)V

    return-void
.end method
