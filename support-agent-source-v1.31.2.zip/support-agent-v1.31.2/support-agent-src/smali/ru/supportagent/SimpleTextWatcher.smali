.class public final Lru/supportagent/SimpleTextWatcher;
.super Ljava/lang/Object;
.source "SimpleTextWatcher.java"

# interfaces
.implements Landroid/text/TextWatcher;


# instance fields
.field private final onChange:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Ljava/lang/Runnable;)V
    .locals 0

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/SimpleTextWatcher;->onChange:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public afterTextChanged(Landroid/text/Editable;)V
    .locals 0

    return-void
.end method

.method public beforeTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 11
    iget-object p1, p0, Lru/supportagent/SimpleTextWatcher;->onChange:Ljava/lang/Runnable;

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    return-void
.end method
