.class public final Lru/supportagent/TemplateRepository;
.super Ljava/lang/Object;
.source "TemplateRepository.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lru/supportagent/TemplateRepository$SearchResults;,
        Lru/supportagent/TemplateRepository$SearchHit;
    }
.end annotation


# static fields
.field public static final COMMANDS_TOPIC_ID:Ljava/lang/String; = "commands"

.field private static final CURRENT_SEED_VERSION:I = 0x7

.field public static final GPS_TOPIC_ID:Ljava/lang/String; = "gps"

.field private static final KEY_SEED_VERSION:Ljava/lang/String; = "seed_version"

.field private static final KEY_TEMPLATES:Ljava/lang/String; = "templates"

.field private static final KEY_TOPICS:Ljava/lang/String; = "topics"

.field public static final MAX_QUICK_TITLE:I = 0xe

.field public static final MAX_SECTION_TITLE:I = 0x1e

.field public static final MAX_TEMPLATE_TITLE:I = 0x2e

.field public static final MAX_TOPIC_TITLE:I = 0x1a

.field private static final PREFS:Ljava/lang/String; = "support_agent_templates"

.field public static final QUICK_TOPIC_ID:Ljava/lang/String; = "quick"


# instance fields
.field private final appContext:Landroid/content/Context;

.field private cachedTemplates:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;"
        }
    .end annotation
.end field

.field private cachedTopics:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lru/supportagent/Topic;",
            ">;"
        }
    .end annotation
.end field

.field private final preferences:Landroid/content/SharedPreferences;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    .line 64
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 65
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lru/supportagent/TemplateRepository;->appContext:Landroid/content/Context;

    const-string v0, "support_agent_templates"

    const/4 v1, 0x0

    .line 66
    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    iput-object p1, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;

    .line 67
    :try_start_seed
    invoke-direct {p0}, Lru/supportagent/TemplateRepository;->ensureSeedData()V
    :try_end_seed
    .catch Ljava/lang/Exception; {:try_start_seed .. :try_end_seed} :catch_seed

    goto :seed_done

    :catch_seed
    move-exception v0

    :seed_done
    return-void
.end method

.method private addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 211
    new-instance v6, Lru/supportagent/AnswerTemplate;

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v1

    move-object v0, v6

    move-object v2, p2

    move-object v3, p4

    move-object v4, p5

    move-object v5, p3

    invoke-direct/range {v0 .. v5}, Lru/supportagent/AnswerTemplate;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p1, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private static cleanSection(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    const/16 v0, 0x1e

    .line 418
    invoke-static {p0, v0}, Lru/supportagent/TemplateRepository;->trimTo(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private static cleanTopicTitle(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    const/16 v0, 0x1a

    .line 414
    invoke-static {p0, v0}, Lru/supportagent/TemplateRepository;->trimTo(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private static copyTemplate(Lru/supportagent/AnswerTemplate;)Lru/supportagent/AnswerTemplate;
    .locals 7

    .line 239
    new-instance v6, Lru/supportagent/AnswerTemplate;

    iget-object v1, p0, Lru/supportagent/AnswerTemplate;->id:Ljava/lang/String;

    iget-object v2, p0, Lru/supportagent/AnswerTemplate;->topicId:Ljava/lang/String;

    iget-object v3, p0, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    iget-object v4, p0, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    iget-object v5, p0, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    move-object v0, v6

    invoke-direct/range {v0 .. v5}, Lru/supportagent/AnswerTemplate;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-object v6
.end method

.method private static copyTemplates(Ljava/util/List;)Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;)",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;"
        }
    .end annotation

    .line 249
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 250
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lru/supportagent/AnswerTemplate;

    invoke-static {v1}, Lru/supportagent/TemplateRepository;->copyTemplate(Lru/supportagent/AnswerTemplate;)Lru/supportagent/AnswerTemplate;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    return-object v0
.end method

.method private static copyTopic(Lru/supportagent/Topic;)Lru/supportagent/Topic;
    .locals 2

    .line 235
    new-instance v0, Lru/supportagent/Topic;

    iget-object v1, p0, Lru/supportagent/Topic;->id:Ljava/lang/String;

    iget-object p0, p0, Lru/supportagent/Topic;->name:Ljava/lang/String;

    invoke-direct {v0, v1, p0}, Lru/supportagent/Topic;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method private static copyTopics(Ljava/util/List;)Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/Topic;",
            ">;)",
            "Ljava/util/List<",
            "Lru/supportagent/Topic;",
            ">;"
        }
    .end annotation

    .line 243
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 244
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lru/supportagent/Topic;

    invoke-static {v1}, Lru/supportagent/TemplateRepository;->copyTopic(Lru/supportagent/Topic;)Lru/supportagent/Topic;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    return-object v0
.end method

.method private countIn(Ljava/util/List;Ljava/lang/String;)I
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;",
            "Ljava/lang/String;",
            ")I"
        }
    .end annotation

    .line 206
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v0, 0x0

    :cond_0
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lru/supportagent/AnswerTemplate;

    iget-object v1, v1, Lru/supportagent/AnswerTemplate;->topicId:Ljava/lang/String;

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return v0
.end method

.method private declared-synchronized ensureLoaded()V
    .locals 5

    monitor-enter p0

    .line 221
    :try_start_0
    iget-object v0, p0, Lru/supportagent/TemplateRepository;->cachedTopics:Ljava/util/List;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lru/supportagent/TemplateRepository;->cachedTemplates:Ljava/util/List;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v0, :cond_0

    monitor-exit p0

    return-void

    .line 222
    :cond_0
    :try_start_1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lru/supportagent/TemplateRepository;->cachedTopics:Ljava/util/List;

    .line 223
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lru/supportagent/TemplateRepository;->cachedTemplates:Ljava/util/List;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v0, 0x0

    .line 225
    :try_start_2
    new-instance v1, Lorg/json/JSONArray;

    iget-object v2, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v3, "topics"

    const-string v4, "[]"

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move v2, v0

    .line 226
    :goto_0
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v2, v3, :cond_1

    iget-object v3, p0, Lru/supportagent/TemplateRepository;->cachedTopics:Ljava/util/List;

    invoke-virtual {v1, v2}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    invoke-static {v4}, Lru/supportagent/Topic;->fromJson(Lorg/json/JSONObject;)Lru/supportagent/Topic;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 229
    :catch_0
    :cond_1
    :try_start_3
    new-instance v1, Lorg/json/JSONArray;

    iget-object v2, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v3, "templates"

    const-string v4, "[]"

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    .line 230
    :goto_1
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v0, v2, :cond_2

    iget-object v2, p0, Lru/supportagent/TemplateRepository;->cachedTemplates:Ljava/util/List;

    invoke-virtual {v1, v0}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    invoke-static {v3}, Lru/supportagent/AnswerTemplate;->fromJson(Lorg/json/JSONObject;)Lru/supportagent/AnswerTemplate;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 232
    :catch_1
    :cond_2
    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method private ensureSeedData()V
    .locals 13

    .line 75
    iget-object v0, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v1, "topics"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x1

    xor-int/2addr v0, v1

    if-eqz v0, :cond_0

    .line 76
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lru/supportagent/TemplateRepository;->getTopics()Ljava/util/List;

    move-result-object v2

    :goto_0
    if-eqz v0, :cond_1

    .line 77
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    goto :goto_1

    :cond_1
    invoke-virtual {p0}, Lru/supportagent/TemplateRepository;->getAllTemplates()Ljava/util/List;

    move-result-object v3

    :goto_1
    const-string v10, "\u0411\u044b\u0441\u0442\u0440\u044b\u0435 \u043e\u0442\u0432\u0435\u0442\u044b"

    const/4 v11, 0x0

    const-string v12, "quick"

    if-eqz v0, :cond_2

    .line 81
    new-instance v0, Lru/supportagent/Topic;

    const-string v4, "jobs"

    const-string v5, "\u041f\u043e\u043c\u043e\u0449\u044c \u043f\u043e \u0440\u0430\u0431\u043e\u0442\u0430\u043c"

    invoke-direct {v0, v4, v5}, Lru/supportagent/Topic;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 82
    new-instance v0, Lru/supportagent/Topic;

    invoke-direct {v0, v12, v10}, Lru/supportagent/Topic;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 83
    new-instance v0, Lru/supportagent/Topic;

    const-string v4, "mine"

    const-string v5, "\u041c\u043e\u0438 \u043e\u0442\u0432\u0435\u0442\u044b"

    invoke-direct {v0, v4, v5}, Lru/supportagent/Topic;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u0417\u0430\u0432\u043e\u0434"

    const-string v9, "\u043d\u0430 \u0437\u0430\u0432\u043e\u0434 \u043c\u043e\u0436\u043d\u043e \u0443\u0441\u0442\u0440\u043e\u0438\u0442\u044c\u0441\u044f \u0441 1 \u0443\u0440\u043e\u0432\u043d\u044f"

    move-object v4, p0

    move-object v5, v3

    .line 87
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u0428\u0430\u0445\u0442\u0451\u0440"

    const-string v9, "\u0448\u0430\u0445\u0442\u0451\u0440\u043e\u043c \u043c\u043e\u0436\u043d\u043e \u0440\u0430\u0431\u043e\u0442\u0430\u0442\u044c \u0441 1 \u0443\u0440\u043e\u0432\u043d\u044f"

    .line 88
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u0424\u0435\u0440\u043c\u0430"

    const-string v9, "\u043d\u0430 \u0444\u0435\u0440\u043c\u0435 \u043c\u043e\u0436\u043d\u043e \u0440\u0430\u0431\u043e\u0442\u0430\u0442\u044c \u0441 1 \u0443\u0440\u043e\u0432\u043d\u044f"

    .line 89
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u041a\u043b\u0443\u0431"

    const-string v9, "\u0432 \u043a\u043b\u0443\u0431 \u043c\u043e\u0436\u043d\u043e \u0443\u0441\u0442\u0440\u043e\u0438\u0442\u044c\u0441\u044f \u0441 1 \u0443\u0440\u043e\u0432\u043d\u044f"

    .line 90
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u0412\u043e\u0434\u0438\u0442\u0435\u043b\u044c \u0430\u0432\u0442\u043e\u0431\u0443\u0441\u0430"

    const-string v9, "\u0434\u043b\u044f \u0430\u0432\u0442\u043e\u0431\u0443\u0441\u0430 \u043d\u0443\u0436\u0435\u043d 2 \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u0438 \u043f\u0440\u0430\u0432\u0430 \u043a\u0430\u0442\u0435\u0433\u043e\u0440\u0438\u0438 D"

    .line 91
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u041a\u0443\u0440\u044c\u0435\u0440"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u043a\u0443\u0440\u044c\u0435\u0440\u043e\u043c \u043d\u0443\u0436\u0435\u043d 2 \u0443\u0440\u043e\u0432\u0435\u043d\u044c"

    .line 92
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u0420\u044b\u0431\u0430\u043a"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u0440\u044b\u0431\u0430\u043a\u043e\u043c \u043d\u0443\u0436\u0435\u043d 3 \u0443\u0440\u043e\u0432\u0435\u043d\u044c"

    .line 93
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u0421\u0431\u043e\u0440\u0449\u0438\u043a \u043c\u0443\u0441\u043e\u0440\u0430"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u0441\u0431\u043e\u0440\u0449\u0438\u043a\u043e\u043c \u043c\u0443\u0441\u043e\u0440\u0430 \u043d\u0443\u0436\u0435\u043d 3 \u0443\u0440\u043e\u0432\u0435\u043d\u044c"

    .line 94
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u041a\u043b\u0430\u0434\u043e\u0438\u0441\u043a\u0430\u0442\u0435\u043b\u044c"

    const-string v9, "\u0434\u043b\u044f \u043a\u043b\u0430\u0434\u043e\u0438\u0441\u043a\u0430\u0442\u0435\u043b\u044f \u043d\u0443\u0436\u0435\u043d 3 \u0443\u0440\u043e\u0432\u0435\u043d\u044c"

    .line 95
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u0423\u0433\u043e\u043d\u0449\u0438\u043a"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u0443\u0433\u043e\u043d\u0449\u0438\u043a\u043e\u043c \u043d\u0443\u0436\u0435\u043d 3 \u0443\u0440\u043e\u0432\u0435\u043d\u044c"

    .line 96
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u0422\u0430\u043a\u0441\u0438\u0441\u0442"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u0442\u0430\u043a\u0441\u0438\u0441\u0442\u043e\u043c \u043d\u0443\u0436\u0435\u043d 3 \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u0438 \u043f\u0440\u0430\u0432\u0430 \u043a\u0430\u0442\u0435\u0433\u043e\u0440\u0438\u0438 B"

    .line 97
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u041e\u0445\u043e\u0442\u043d\u0438\u043a"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u043e\u0445\u043e\u0442\u043d\u0438\u043a\u043e\u043c \u043d\u0443\u0436\u0435\u043d 4 \u0443\u0440\u043e\u0432\u0435\u043d\u044c"

    .line 98
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u0410\u0432\u0442\u043e\u043c\u0435\u0445\u0430\u043d\u0438\u043a"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u0430\u0432\u0442\u043e\u043c\u0435\u0445\u0430\u043d\u0438\u043a\u043e\u043c \u043d\u0443\u0436\u0435\u043d 4 \u0443\u0440\u043e\u0432\u0435\u043d\u044c"

    .line 99
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u0413\u0430\u0437\u043e\u0432\u0449\u0438\u043a"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u0433\u0430\u0437\u043e\u0432\u0449\u0438\u043a\u043e\u043c \u043d\u0443\u0436\u0435\u043d 5 \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u0438 \u043f\u0440\u0430\u0432\u0430 \u043a\u0430\u0442\u0435\u0433\u043e\u0440\u0438\u0438 B"

    .line 100
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u041c\u0427\u0421"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u041c\u0427\u0421 \u043d\u0443\u0436\u0435\u043d 5 \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u0438 \u043f\u0440\u0430\u0432\u0430 \u043a\u0430\u0442\u0435\u0433\u043e\u0440\u0438\u0438 B"

    .line 101
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u041a\u0443\u0440\u044c\u0435\u0440 \u041f\u0412\u0417"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u043a\u0443\u0440\u044c\u0435\u0440\u043e\u043c \u041f\u0412\u0417 \u043d\u0443\u0436\u0435\u043d 5 \u0443\u0440\u043e\u0432\u0435\u043d\u044c"

    .line 102
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u0421\u043a\u043b\u0430\u0434\u0441\u043a\u043e\u0439 \u0440\u0430\u0431\u043e\u0442\u043d\u0438\u043a"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u043d\u0430 \u0441\u043a\u043b\u0430\u0434\u0435 \u043d\u0443\u0436\u0435\u043d 7 \u0443\u0440\u043e\u0432\u0435\u043d\u044c"

    .line 103
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u0421\u0442\u0440\u043e\u0439\u043a\u0430"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u043d\u0430 \u0441\u0442\u0440\u043e\u0439\u043a\u0435 \u043d\u0443\u0436\u0435\u043d 8 \u0443\u0440\u043e\u0432\u0435\u043d\u044c"

    .line 104
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u0414\u0430\u043b\u044c\u043d\u043e\u0431\u043e\u0439\u0449\u0438\u043a"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u0434\u0430\u043b\u044c\u043d\u043e\u0431\u043e\u0439\u0449\u0438\u043a\u043e\u043c \u043d\u0443\u0436\u0435\u043d 10 \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u0438 \u043f\u0440\u0430\u0432\u0430 \u043a\u0430\u0442\u0435\u0433\u043e\u0440\u0438\u0438 C"

    .line 105
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u042d\u043b\u0435\u043a\u0442\u0440\u0438\u043a"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u044d\u043b\u0435\u043a\u0442\u0440\u0438\u043a\u043e\u043c \u043d\u0443\u0436\u0435\u043d 12 \u0443\u0440\u043e\u0432\u0435\u043d\u044c"

    .line 106
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u0418\u043d\u043a\u0430\u0441\u0441\u0430\u0442\u043e\u0440"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u0438\u043d\u043a\u0430\u0441\u0441\u0430\u0442\u043e\u0440\u043e\u043c \u043d\u0443\u0436\u0435\u043d 15 \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u0438 \u043f\u0440\u0430\u0432\u0430 \u043a\u0430\u0442\u0435\u0433\u043e\u0440\u0438\u0438 B"

    .line 107
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "jobs"

    const-string v7, ""

    const-string v8, "\u0412\u043e\u0434\u043e\u043b\u0430\u0437"

    const-string v9, "\u0434\u043b\u044f \u0440\u0430\u0431\u043e\u0442\u044b \u0432\u043e\u0434\u043e\u043b\u0430\u0437\u043e\u043c \u043d\u0443\u0436\u0435\u043d 18 \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u0438 \u043f\u0440\u0430\u0432\u0430 \u043d\u0430 \u0432\u043e\u0434\u043d\u044b\u0439 \u0442\u0440\u0430\u043d\u0441\u043f\u043e\u0440\u0442"

    .line 108
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    move v0, v1

    goto :goto_2

    :cond_2
    move v0, v11

    .line 112
    :goto_2
    invoke-direct {p0, v2, v12}, Lru/supportagent/TemplateRepository;->hasTopic(Ljava/util/List;Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_3

    .line 113
    new-instance v0, Lru/supportagent/Topic;

    invoke-direct {v0, v12, v10}, Lru/supportagent/Topic;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move v0, v1

    .line 116
    :cond_3
    iget-object v4, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v10, "seed_version"

    invoke-interface {v4, v10, v11}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    const/4 v5, 0x2

    if-ge v4, v5, :cond_4

    invoke-direct {p0, v3, v12}, Lru/supportagent/TemplateRepository;->countIn(Ljava/util/List;Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_4

    const-string v6, "quick"

    const-string v7, ""

    const-string v8, "\u041d\u0435 \u0442\u043e\u0442 \u0440\u0435\u043f\u043e\u0440\u0442"

    const-string v9, "\u0417\u0434\u0440\u0430\u0432\u0441\u0442\u0432\u0443\u0439\u0442\u0435, \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0439\u0442\u0435 /report - 1 //\u041f\u0440\u0438\u044f\u0442\u043d\u043e\u0439 \u0438\u0433\u0440\u044b"

    move-object v4, p0

    move-object v5, v3

    .line 117
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "quick"

    const-string v7, ""

    const-string v8, "\u0423\u0442\u043e\u0447\u043d\u0438\u0442\u0435"

    const-string v9, "\u0443\u0442\u043e\u0447\u043d\u0438\u0442\u0435 \u0432\u0430\u0448 \u0432\u043e\u043f\u0440\u043e\u0441, \u043f\u043e\u0436\u0430\u043b\u0443\u0439\u0441\u0442\u0430"

    .line 118
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "quick"

    const-string v7, ""

    const-string v8, "\u041d\u0435 \u043f\u043e \u0442\u0435\u043c\u0435"

    const-string v9, "\u0417\u0434\u0440\u0430\u0432\u0441\u0442\u0432\u0443\u0439\u0442\u0435, \u043d\u0435 \u043f\u043e \u0442\u0435\u043c\u0435. // \u041f\u0440\u0438\u044f\u0442\u043d\u043e\u0439 \u0438\u0433\u0440\u044b"

    .line 119
    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

        const-string v6, "quick"

    const-string v7, ""

    const-string v8, "\u0416\u0431 \u043d\u0430 \u0444\u043e\u0440\u0443\u043c"

    const-string v9, "\u0417\u0434\u0440\u0430\u0432\u0441\u0442\u0432\u0443\u0439\u0442\u0435, \u043f\u043e\u0434\u0430\u0439\u0442\u0435 \u0436\u0430\u043b\u043e\u0431\u0443 \u043d\u0430 \u0438\u0433\u0440\u043e\u043a\u0430 \u043d\u0430 \u0444\u043e\u0440\u0443\u043c\u0435, \u043f\u0440\u0438\u043a\u0440\u0435\u043f\u0438\u0432 \u0432\u0438\u0434\u0435\u043e\u0444\u0438\u043a\u0441\u0430\u0446\u0438\u044e \u0441 /time // \u041f\u0440\u0438\u044f\u0442\u043d\u043e\u0439 \u0438\u0433\u0440\u044b."

    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V


    goto :goto_3

    :cond_4
    move v1, v0

    .line 122
    :goto_3
    iget-object v0, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {v0, v10, v11}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x3

    if-ge v0, v4, :cond_5

    .line 123
    invoke-direct {p0, v2, v3}, Lru/supportagent/TemplateRepository;->seedKnowledgeBase(Ljava/util/List;Ljava/util/List;)Z

    move-result v0

    or-int/2addr v1, v0

    :cond_5
    iget-object v0, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {v0, v10, v11}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v5, 0x6

    if-ge v0, v5, :sa_seed_done

    invoke-direct {p0, v3}, Lru/supportagent/TemplateRepository;->normalizeQuickSeeds(Ljava/util/List;)Z

    move-result v0

    or-int/2addr v1, v0

    :sa_seed_done

    iget-object v0, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {v0, v10, v11}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x7

    if-ge v0, v4, :sa_seed7_done

    invoke-direct {p0, v2, v3}, Lru/supportagent/TemplateRepository;->seedExtraTopics(Ljava/util/List;Ljava/util/List;)Z

    move-result v0

    or-int/2addr v1, v0

    :sa_seed7_done
    if-eqz v1, :cond_6

    .line 125
    invoke-direct {p0, v2, v3}, Lru/supportagent/TemplateRepository;->saveAll(Ljava/util/List;Ljava/util/List;)V

    .line 126
    :cond_6
    const/4 v4, 0x7

    iget-object v0, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v10, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    return-void
.end method

.method private normalizeQuickSeeds(Ljava/util/List;)Z
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;",
            ")Z"
        }
    .end annotation

    const/4 v0, 0x0

    if-eqz p1, :nq_add

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :nq_loop
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :nq_add

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/AnswerTemplate;

    iget-object v3, v2, Lru/supportagent/AnswerTemplate;->topicId:Ljava/lang/String;

    const-string v4, "quick"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :nq_loop

    iget-object v3, v2, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    if-eqz v3, :nq_loop

    const-string v4, "\u0416\u0431 \u043d\u0430 \u0444\u043e\u0440\u0443\u043c"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :nq_check5

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    const/4 v0, 0x1

    goto :nq_loop

    :nq_check5
    const-string v4, "\u041d\u0435\u0442 \u0444\u0443\u043d\u043a\u0446\u0438\u0438"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :nq_loop

    iget-object v5, v2, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    const-string v6, "\u0417\u0434\u0440\u0430\u0432\u0441\u0442\u0432\u0443\u0439\u0442\u0435, \u0434\u0430\u043d\u043d\u0430\u044f \u0444\u0443\u043d\u043a\u0446\u0438\u044f \u043e\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u043d\u0430 \u0441\u0435\u0440\u0432\u0435\u0440\u0435. // \u041f\u0440\u0438\u044f\u0442\u043d\u043e\u0439 \u0438\u0433\u0440\u044b"

    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :nq_loop

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    const/4 v0, 0x1

    goto :nq_loop

    :nq_add
    move-object v4, p0

    move-object v5, p1

    const-string v6, "quick"

    const-string v7, ""

    const-string v8, "\u0416\u0431 \u043d\u0430 \u0444\u043e\u0440\u0443\u043c"

    const-string v9, "\u0417\u0434\u0440\u0430\u0432\u0441\u0442\u0432\u0443\u0439\u0442\u0435, \u043f\u043e\u0434\u0430\u0439\u0442\u0435 \u0436\u0430\u043b\u043e\u0431\u0443 \u043d\u0430 \u0438\u0433\u0440\u043e\u043a\u0430 \u043d\u0430 \u0444\u043e\u0440\u0443\u043c\u0435, \u043f\u0440\u0438\u043a\u0440\u0435\u043f\u0438\u0432 \u0432\u0438\u0434\u0435\u043e\u0444\u0438\u043a\u0441\u0430\u0446\u0438\u044e \u0441 /time // \u041f\u0440\u0438\u044f\u0442\u043d\u043e\u0439 \u0438\u0433\u0440\u044b."

    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x1

    return v0
.end method


.method private hasTopic(Ljava/util/List;Ljava/lang/String;)Z
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/Topic;",
            ">;",
            "Ljava/lang/String;",
            ")Z"
        }
    .end annotation

    .line 200
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lru/supportagent/Topic;

    iget-object v0, v0, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method private readAsset(Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 190
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 191
    iget-object v1, p0, Lru/supportagent/TemplateRepository;->appContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v1

    invoke-virtual {v1, p1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object p1

    .line 192
    new-instance v1, Ljava/io/BufferedReader;

    new-instance v2, Ljava/io/InputStreamReader;

    const-string v3, "UTF-8"

    invoke-direct {v2, p1, v3}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V

    invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 194
    :goto_0
    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const/16 v2, 0xa

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_0

    .line 195
    :cond_0
    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V

    .line 196
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private saveAll(Ljava/util/List;Ljava/util/List;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/Topic;",
            ">;",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;)V"
        }
    .end annotation

    .line 427
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    .line 428
    new-instance v1, Lorg/json/JSONArray;

    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    .line 430
    :try_start_0
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lru/supportagent/Topic;

    invoke-virtual {v3}, Lru/supportagent/Topic;->toJson()Lorg/json/JSONObject;

    move-result-object v3

    invoke-virtual {v0, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_0

    .line 431
    :cond_0
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lru/supportagent/AnswerTemplate;

    invoke-virtual {v3}, Lru/supportagent/AnswerTemplate;->toJson()Lorg/json/JSONObject;

    move-result-object v3

    invoke-virtual {v1, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    .line 435
    :catch_0
    :cond_1
    iget-object v2, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "topics"

    .line 436
    invoke-virtual {v0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v2, v3, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "templates"

    .line 437
    invoke-virtual {v1}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 438
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 439
    monitor-enter p0

    .line 440
    :try_start_1
    invoke-static {p1}, Lru/supportagent/TemplateRepository;->copyTopics(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Lru/supportagent/TemplateRepository;->cachedTopics:Ljava/util/List;

    .line 441
    invoke-static {p2}, Lru/supportagent/TemplateRepository;->copyTemplates(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Lru/supportagent/TemplateRepository;->cachedTemplates:Ljava/util/List;

    .line 442
    monitor-exit p0

    return-void

    :catchall_0
    move-exception p1

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private seedKnowledgeBase(Ljava/util/List;Ljava/util/List;)Z
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/Topic;",
            ">;",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;)Z"
        }
    .end annotation

    move-object/from16 v6, p0

    move-object/from16 v7, p1

    move-object/from16 v8, p2

    const-string v9, "gps"

    .line 131
    invoke-direct {v6, v8, v9}, Lru/supportagent/TemplateRepository;->countIn(Ljava/util/List;Ljava/lang/String;)I

    move-result v0

    const/4 v10, 0x0

    const/4 v11, 0x1

    if-nez v0, :cond_0

    move v12, v11

    goto :goto_0

    :cond_0
    move v12, v10

    :goto_0
    const-string v13, "commands"

    .line 132
    invoke-direct {v6, v8, v13}, Lru/supportagent/TemplateRepository;->countIn(Ljava/util/List;Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_1

    move v14, v11

    goto :goto_1

    :cond_1
    move v14, v10

    .line 135
    :goto_1
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    const-string v1, "seed_topics_v3.json"

    invoke-direct {v6, v1}, Lru/supportagent/TemplateRepository;->readAsset(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v1, "topics"

    .line 136
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    if-eqz v1, :cond_3

    move v2, v10

    move v3, v2

    .line 138
    :goto_2
    :try_start_1
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v2, v4, :cond_4

    .line 139
    invoke-virtual {v1, v2}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    const-string v5, "id"

    .line 140
    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v15, "name"

    .line 141
    invoke-virtual {v4, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 142
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-nez v15, :cond_2

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-nez v15, :cond_2

    invoke-direct {v6, v7, v5}, Lru/supportagent/TemplateRepository;->hasTopic(Ljava/util/List;Ljava/lang/String;)Z

    move-result v15

    if-nez v15, :cond_2

    .line 143
    new-instance v15, Lru/supportagent/Topic;

    invoke-direct {v15, v5, v4}, Lru/supportagent/Topic;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v7, v15}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move v3, v11

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_3
    move v3, v10

    :cond_4
    const-string v1, "templates"

    .line 148
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v15
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    if-eqz v15, :cond_b

    move/from16 v16, v3

    move v5, v10

    .line 150
    :goto_3
    :try_start_2
    invoke-virtual {v15}, Lorg/json/JSONArray;->length()I

    move-result v0

    if-ge v5, v0, :cond_a

    .line 151
    invoke-virtual {v15, v5}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "topicId"

    .line 152
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 153
    invoke-virtual {v9, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    if-nez v12, :cond_6

    .line 154
    :cond_5
    invoke-virtual {v13, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7

    if-eqz v14, :cond_7

    :cond_6
    move v1, v11

    goto :goto_4

    :cond_7
    move v1, v10

    :goto_4
    if-nez v1, :cond_9

    :cond_8
    move/from16 v18, v5

    goto :goto_5

    :cond_9
    const-string v1, "title"

    .line 156
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    const-string v1, "section"

    .line 157
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lru/supportagent/TemplateRepository;->cleanSection(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v1, "body"

    .line 158
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lru/supportagent/ReplyComposer;->cleanBody(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    .line 159
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_8

    invoke-static/range {v17 .. v17}, Lru/supportagent/ReplyComposer;->isValid(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_8

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move/from16 v18, v5

    move-object/from16 v5, v17

    .line 160
    invoke-direct/range {v0 .. v5}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    move/from16 v16, v11

    :goto_5
    add-int/lit8 v5, v18, 0x1

    goto :goto_3

    :cond_a
    move/from16 v11, v16

    goto :goto_7

    :catch_0
    move/from16 v10, v16

    goto :goto_6

    :cond_b
    move v11, v3

    goto :goto_7

    :catch_1
    move v10, v3

    .line 167
    :catch_2
    :goto_6
    invoke-direct {v6, v7, v9}, Lru/supportagent/TemplateRepository;->hasTopic(Ljava/util/List;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_c

    .line 168
    new-instance v0, Lru/supportagent/Topic;

    const-string v1, "GPS \u043d\u0430\u0432\u0438\u0433\u0430\u0442\u043e\u0440"

    invoke-direct {v0, v9, v1}, Lru/supportagent/Topic;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v7, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move v10, v11

    :cond_c
    if-eqz v12, :cond_d

    const-string v2, "gps"

    const-string v3, "\u041f\u043e\u0438\u0441\u043a \u0431\u043b\u0438\u0436\u0430\u0439\u0448\u0438\u0445 \u043c\u0435\u0441\u0442"

    const-string v4, "\u0411\u043b\u0438\u0436\u0430\u0439\u0448\u0430\u044f \u043f\u0430\u0440\u043a\u043e\u0432\u043a\u0430"

    const-string v5, "/gps - 15 - 1 = \u041d\u0430\u0439\u0442\u0438 \u0431\u043b\u0438\u0436\u0430\u0439\u0448\u0443\u044e \u043f\u0430\u0440\u043a\u043e\u0432\u043a\u0443"

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    .line 172
    invoke-direct/range {v0 .. v5}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    move v10, v11

    .line 176
    :cond_d
    invoke-direct {v6, v7, v13}, Lru/supportagent/TemplateRepository;->hasTopic(Ljava/util/List;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_e

    .line 177
    new-instance v0, Lru/supportagent/Topic;

    const-string v1, "\u041a\u043e\u043c\u0430\u043d\u0434\u044b \u0441\u0435\u0440\u0432\u0435\u0440\u0430"

    invoke-direct {v0, v13, v1}, Lru/supportagent/Topic;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v7, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move v10, v11

    :cond_e
    if-eqz v14, :cond_f

    const-string v2, "commands"

    const-string v3, "\u041e\u0431\u0449\u0438\u0435"

    const-string v4, "GPS-\u043d\u0430\u0432\u0438\u0433\u0430\u0442\u043e\u0440"

    const-string v5, "\u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0439\u0442\u0435 \u043a\u043e\u043c\u0430\u043d\u0434\u0443 \u00ab/gps\u00bb,"

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    .line 181
    invoke-direct/range {v0 .. v5}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_7

    :cond_f
    move v11, v10

    :goto_7
    return v11
.end method

.method private seedExtraTopics(Ljava/util/List;Ljava/util/List;)Z
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/Topic;",
            ">;",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;)Z"
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v9, 0x1

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    const-string v1, "seed_topics_v4.json"

    invoke-direct {p0, v1}, Lru/supportagent/TemplateRepository;->readAsset(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-instance v7, Ljava/util/HashSet;

    invoke-direct {v7}, Ljava/util/HashSet;-><init>()V

    const-string v1, "topics"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v11

    if-eqz v11, :sa_xt_templates

    const/4 v12, 0x0

    :sa_xt_loop_t
    invoke-virtual {v11}, Lorg/json/JSONArray;->length()I

    move-result v1

    if-ge v12, v1, :sa_xt_templates

    invoke-virtual {v11, v12}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "id"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "name"

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :sa_xt_next_t

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :sa_xt_next_t

    invoke-direct {p0, p1, v2}, Lru/supportagent/TemplateRepository;->hasTopic(Ljava/util/List;Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :sa_xt_next_t

    new-instance v4, Lru/supportagent/Topic;

    invoke-direct {v4, v2, v3}, Lru/supportagent/Topic;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p1, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-interface {v7, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move v8, v9

    :sa_xt_next_t
    add-int/lit8 v12, v12, 0x1

    goto :sa_xt_loop_t

    :sa_xt_templates
    const-string v1, "templates"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v11

    if-eqz v11, :sa_xt_ret

    const/4 v12, 0x0

    :sa_xt_loop_a
    invoke-virtual {v11}, Lorg/json/JSONArray;->length()I

    move-result v1

    if-ge v12, v1, :sa_xt_ret

    invoke-virtual {v11, v12}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "topicId"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v7, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :sa_xt_next_a

    const-string v2, "title"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    const-string v3, "section"

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lru/supportagent/TemplateRepository;->cleanSection(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "body"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lru/supportagent/ReplyComposer;->cleanBody(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :sa_xt_next_a

    invoke-static {v4}, Lru/supportagent/ReplyComposer;->isValid(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :sa_xt_next_a

    move-object/from16 v5, v4

    move-object v4, v2

    move-object v2, v1

    move-object/from16 v1, p2

    move-object v0, p0

    invoke-direct/range {v0 .. v5}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    move v8, v9

    :sa_xt_next_a
    add-int/lit8 v12, v12, 0x1

    goto :sa_xt_loop_a
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :sa_xt_ret
    return v8

    :catch_0
    move-exception v0

    return v8
.end method

.method public static titleLimitForTopic(Ljava/lang/String;)I
    .locals 1

    const-string v0, "quick"

    .line 404
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/16 p0, 0xe

    goto :goto_0

    :cond_0
    const/16 p0, 0x2e

    :goto_0
    return p0
.end method

.method private static trimTo(Ljava/lang/String;I)Ljava/lang/String;
    .locals 2

    if-nez p0, :cond_0

    const-string p0, ""

    goto :goto_0

    .line 422
    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const-string v0, "\\s+"

    const-string v1, " "

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 423
    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    if-gt v0, p1, :cond_1

    goto :goto_1

    :cond_1
    const/4 v0, 0x0

    invoke-virtual {p0, v0, p1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    :goto_1
    return-object p0
.end method


# virtual methods
.method public addTopic(Ljava/lang/String;)Lru/supportagent/Topic;
    .locals 3

    .line 343
    invoke-static {p1}, Lru/supportagent/TemplateRepository;->cleanTopicTitle(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 344
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p1, 0x0

    return-object p1

    .line 345
    :cond_0
    invoke-virtual {p0}, Lru/supportagent/TemplateRepository;->getTopics()Ljava/util/List;

    move-result-object v0

    .line 346
    new-instance v1, Lru/supportagent/Topic;

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2, p1}, Lru/supportagent/Topic;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 347
    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 348
    invoke-virtual {p0}, Lru/supportagent/TemplateRepository;->getAllTemplates()Ljava/util/List;

    move-result-object p1

    invoke-direct {p0, v0, p1}, Lru/supportagent/TemplateRepository;->saveAll(Ljava/util/List;Ljava/util/List;)V

    return-object v1
.end method

.method public declared-synchronized countForTopic(Ljava/lang/String;)I
    .locals 3

    monitor-enter p0

    .line 336
    :try_start_0
    invoke-direct {p0}, Lru/supportagent/TemplateRepository;->ensureLoaded()V

    .line 338
    iget-object v0, p0, Lru/supportagent/TemplateRepository;->cachedTemplates:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v1, 0x0

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/AnswerTemplate;

    iget-object v2, v2, Lru/supportagent/AnswerTemplate;->topicId:Ljava/lang/String;

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v2, :cond_0

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 339
    :cond_1
    monitor-exit p0

    return v1

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public deleteTemplate(Ljava/lang/String;)V
    .locals 3

    .line 408
    invoke-virtual {p0}, Lru/supportagent/TemplateRepository;->getAllTemplates()Ljava/util/List;

    move-result-object v0

    .line 409
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    :goto_0
    if-ltz v1, :cond_1

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/AnswerTemplate;

    iget-object v2, v2, Lru/supportagent/AnswerTemplate;->id:Ljava/lang/String;

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v0, v1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    :cond_0
    add-int/lit8 v1, v1, -0x1

    goto :goto_0

    .line 410
    :cond_1
    invoke-virtual {p0}, Lru/supportagent/TemplateRepository;->getTopics()Ljava/util/List;

    move-result-object p1

    invoke-direct {p0, p1, v0}, Lru/supportagent/TemplateRepository;->saveAll(Ljava/util/List;Ljava/util/List;)V

    return-void
.end method

.method public deleteTopic(Lru/supportagent/Topic;)V
    .locals 5

    if-nez p1, :cond_0

    return-void

    .line 362
    :cond_0
    invoke-virtual {p0}, Lru/supportagent/TemplateRepository;->getTopics()Ljava/util/List;

    move-result-object v0

    .line 363
    invoke-virtual {p0}, Lru/supportagent/TemplateRepository;->getAllTemplates()Ljava/util/List;

    move-result-object v1

    .line 364
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    :goto_0
    if-ltz v2, :cond_2

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lru/supportagent/Topic;

    iget-object v3, v3, Lru/supportagent/Topic;->id:Ljava/lang/String;

    iget-object v4, p1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v0, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    :cond_1
    add-int/lit8 v2, v2, -0x1

    goto :goto_0

    .line 365
    :cond_2
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    :goto_1
    if-ltz v2, :cond_4

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lru/supportagent/AnswerTemplate;

    iget-object v3, v3, Lru/supportagent/AnswerTemplate;->topicId:Ljava/lang/String;

    iget-object v4, p1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {v1, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    :cond_3
    add-int/lit8 v2, v2, -0x1

    goto :goto_1

    .line 366
    :cond_4
    invoke-direct {p0, v0, v1}, Lru/supportagent/TemplateRepository;->saveAll(Ljava/util/List;Ljava/util/List;)V

    return-void
.end method

.method public declared-synchronized getAllTemplates()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;"
        }
    .end annotation

    monitor-enter p0

    .line 298
    :try_start_0
    invoke-direct {p0}, Lru/supportagent/TemplateRepository;->ensureLoaded()V

    .line 299
    iget-object v0, p0, Lru/supportagent/TemplateRepository;->cachedTemplates:Ljava/util/List;

    invoke-static {v0}, Lru/supportagent/TemplateRepository;->copyTemplates(Ljava/util/List;)Ljava/util/List;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public getQuickTemplates()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;"
        }
    .end annotation

    const-string v0, "quick"

    .line 273
    invoke-virtual {p0, v0}, Lru/supportagent/TemplateRepository;->getTemplates(Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public declared-synchronized getRegularTopics()Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lru/supportagent/Topic;",
            ">;"
        }
    .end annotation

    monitor-enter p0

    .line 267
    :try_start_0
    invoke-direct {p0}, Lru/supportagent/TemplateRepository;->ensureLoaded()V

    .line 268
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 269
    iget-object v1, p0, Lru/supportagent/TemplateRepository;->cachedTopics:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/Topic;

    const-string v3, "quick"

    iget-object v4, v2, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    invoke-static {v2}, Lru/supportagent/TemplateRepository;->copyTopic(Lru/supportagent/Topic;)Lru/supportagent/Topic;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 270
    :cond_1
    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized getSections(Ljava/lang/String;)Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    monitor-enter p0

    .line 287
    :try_start_0
    invoke-direct {p0}, Lru/supportagent/TemplateRepository;->ensureLoaded()V

    .line 288
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 289
    iget-object v1, p0, Lru/supportagent/TemplateRepository;->cachedTemplates:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/AnswerTemplate;

    .line 290
    iget-object v3, v2, Lru/supportagent/AnswerTemplate;->topicId:Ljava/lang/String;

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    goto :goto_0

    .line 291
    :cond_1
    iget-object v2, v2, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    invoke-static {v2}, Lru/supportagent/TemplateRepository;->cleanSection(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 292
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_0

    invoke-interface {v0, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 294
    :cond_2
    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public declared-synchronized getTemplates(Ljava/lang/String;)Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;"
        }
    .end annotation

    monitor-enter p0

    .line 278
    :try_start_0
    invoke-direct {p0}, Lru/supportagent/TemplateRepository;->ensureLoaded()V

    .line 279
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 280
    iget-object v1, p0, Lru/supportagent/TemplateRepository;->cachedTemplates:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/AnswerTemplate;

    .line 281
    iget-object v3, v2, Lru/supportagent/AnswerTemplate;->topicId:Ljava/lang/String;

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-static {v2}, Lru/supportagent/TemplateRepository;->copyTemplate(Lru/supportagent/AnswerTemplate;)Lru/supportagent/AnswerTemplate;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 283
    :cond_1
    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public declared-synchronized getTopic(Ljava/lang/String;)Lru/supportagent/Topic;
    .locals 3

    monitor-enter p0

    .line 260
    :try_start_0
    invoke-direct {p0}, Lru/supportagent/TemplateRepository;->ensureLoaded()V

    .line 261
    iget-object v0, p0, Lru/supportagent/TemplateRepository;->cachedTopics:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lru/supportagent/Topic;

    iget-object v2, v1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-static {v1}, Lru/supportagent/TemplateRepository;->copyTopic(Lru/supportagent/Topic;)Lru/supportagent/Topic;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object p1

    .line 262
    :cond_1
    monitor-exit p0

    const/4 p1, 0x0

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public declared-synchronized getTopics()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lru/supportagent/Topic;",
            ">;"
        }
    .end annotation

    monitor-enter p0

    .line 255
    :try_start_0
    invoke-direct {p0}, Lru/supportagent/TemplateRepository;->ensureLoaded()V

    .line 256
    iget-object v0, p0, Lru/supportagent/TemplateRepository;->cachedTopics:Ljava/util/List;

    invoke-static {v0}, Lru/supportagent/TemplateRepository;->copyTopics(Ljava/util/List;)Ljava/util/List;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public isQuickTopic(Lru/supportagent/Topic;)Z
    .locals 1

    if-eqz p1, :cond_0

    const-string v0, "quick"

    .line 274
    iget-object p1, p1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public declared-synchronized reload()V
    .locals 1

    monitor-enter p0

    const/4 v0, 0x0

    .line 216
    :try_start_0
    iput-object v0, p0, Lru/supportagent/TemplateRepository;->cachedTopics:Ljava/util/List;

    .line 217
    iput-object v0, p0, Lru/supportagent/TemplateRepository;->cachedTemplates:Ljava/util/List;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 218
    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public saveTemplate(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lru/supportagent/AnswerTemplate;
    .locals 7

    .line 372
    invoke-virtual {p0}, Lru/supportagent/TemplateRepository;->getAllTemplates()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lru/supportagent/AnswerTemplate;

    .line 373
    iget-object v2, v1, Lru/supportagent/AnswerTemplate;->id:Ljava/lang/String;

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v0, v1, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    goto :goto_0

    :cond_1
    const-string v0, ""

    :goto_0
    move-object v6, v0

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    .line 375
    invoke-virtual/range {v1 .. v6}, Lru/supportagent/TemplateRepository;->saveTemplate(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lru/supportagent/AnswerTemplate;

    move-result-object p1

    return-object p1
.end method

.method public saveTemplate(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lru/supportagent/AnswerTemplate;
    .locals 7

    .line 379
    invoke-static {p2}, Lru/supportagent/TemplateRepository;->titleLimitForTopic(Ljava/lang/String;)I

    move-result v0

    invoke-static {p3, v0}, Lru/supportagent/TemplateRepository;->trimTo(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v4

    .line 380
    invoke-static {p5}, Lru/supportagent/TemplateRepository;->cleanSection(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 381
    invoke-static {p4}, Lru/supportagent/ReplyComposer;->cleanBody(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 382
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result p3

    const/4 p4, 0x0

    if-nez p3, :cond_4

    invoke-static {v5}, Lru/supportagent/ReplyComposer;->isValid(Ljava/lang/String;)Z

    move-result p3

    if-nez p3, :cond_0

    goto :goto_0

    .line 383
    :cond_0
    invoke-virtual {p0}, Lru/supportagent/TemplateRepository;->getAllTemplates()Ljava/util/List;

    move-result-object p3

    .line 385
    invoke-interface {p3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p5

    :cond_1
    invoke-interface {p5}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-interface {p5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lru/supportagent/AnswerTemplate;

    .line 386
    iget-object v1, v0, Lru/supportagent/AnswerTemplate;->id:Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 387
    iput-object p2, v0, Lru/supportagent/AnswerTemplate;->topicId:Ljava/lang/String;

    .line 388
    iput-object v4, v0, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    .line 389
    iput-object v6, v0, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    .line 390
    iput-object v5, v0, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    move-object p4, v0

    :cond_2
    if-nez p4, :cond_3

    .line 396
    new-instance p4, Lru/supportagent/AnswerTemplate;

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v2

    move-object v1, p4

    move-object v3, p2

    invoke-direct/range {v1 .. v6}, Lru/supportagent/AnswerTemplate;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 397
    invoke-interface {p3, p4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 399
    :cond_3
    invoke-virtual {p0}, Lru/supportagent/TemplateRepository;->getTopics()Ljava/util/List;

    move-result-object p1

    invoke-direct {p0, p1, p3}, Lru/supportagent/TemplateRepository;->saveAll(Ljava/util/List;Ljava/util/List;)V

    :cond_4
    :goto_0
    return-object p4
.end method

.method public declared-synchronized searchAll(Ljava/lang/String;I)Lru/supportagent/TemplateRepository$SearchResults;
    .locals 12

    monitor-enter p0

    .line 309
    :try_start_0
    invoke-direct {p0}, Lru/supportagent/TemplateRepository;->ensureLoaded()V

    if-nez p1, :cond_0

    const-string p1, ""

    goto :goto_0

    .line 310
    :cond_0
    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    .line 311
    :goto_0
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    new-instance p1, Lru/supportagent/TemplateRepository$SearchResults;

    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    invoke-direct {p1, p2, v2, v1}, Lru/supportagent/TemplateRepository$SearchResults;-><init>(Ljava/util/List;ILru/supportagent/TemplateRepository$SearchResults-IA;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object p1

    .line 313
    :cond_1
    :try_start_1
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 314
    iget-object v3, p0, Lru/supportagent/TemplateRepository;->cachedTopics:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lru/supportagent/Topic;

    iget-object v5, v4, Lru/supportagent/Topic;->id:Ljava/lang/String;

    iget-object v4, v4, Lru/supportagent/Topic;->name:Ljava/lang/String;

    invoke-interface {v0, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    .line 316
    :cond_2
    invoke-static {v2, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    .line 318
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 319
    iget-object v4, p0, Lru/supportagent/TemplateRepository;->cachedTemplates:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_3
    :goto_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_b

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lru/supportagent/AnswerTemplate;

    const-string v6, "quick"

    .line 320
    iget-object v7, v5, Lru/supportagent/AnswerTemplate;->topicId:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_4

    const-string v6, "\u0411\u044b\u0441\u0442\u0440\u044b\u0435 \u043e\u0442\u0432\u0435\u0442\u044b"

    goto :goto_3

    .line 321
    :cond_4
    iget-object v6, v5, Lru/supportagent/AnswerTemplate;->topicId:Ljava/lang/String;

    invoke-interface {v0, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    :goto_3
    if-eqz v6, :cond_5

    .line 322
    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_6

    :cond_5
    const-string v6, "\u0411\u0435\u0437 \u0442\u0435\u043c\u044b"

    .line 323
    :cond_6
    iget-object v7, v5, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    if-nez v7, :cond_7

    const-string v7, ""

    goto :goto_4

    :cond_7
    iget-object v7, v5, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    .line 324
    :goto_4
    iget-object v8, v5, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    if-nez v8, :cond_8

    const-string v8, ""

    goto :goto_5

    :cond_8
    iget-object v8, v5, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    .line 325
    :goto_5
    iget-object v9, v5, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    if-nez v9, :cond_9

    const-string v9, ""

    goto :goto_6

    :cond_9
    iget-object v9, v5, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    .line 326
    :goto_6
    invoke-static {v9}, Lru/supportagent/GpsShift;->apply(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v10, " "

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    sget-object v8, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 327
    invoke-virtual {v7, v8}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v7

    .line 328
    invoke-virtual {v7, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_a

    goto/16 :goto_2

    :cond_a
    add-int/lit8 v2, v2, 0x1

    .line 330
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v7

    if-ge v7, p2, :cond_3

    new-instance v7, Lru/supportagent/TemplateRepository$SearchHit;

    invoke-static {v5}, Lru/supportagent/TemplateRepository;->copyTemplate(Lru/supportagent/AnswerTemplate;)Lru/supportagent/AnswerTemplate;

    move-result-object v5

    invoke-direct {v7, v5, v6, v1}, Lru/supportagent/TemplateRepository$SearchHit;-><init>(Lru/supportagent/AnswerTemplate;Ljava/lang/String;Lru/supportagent/TemplateRepository$SearchHit-IA;)V

    invoke-interface {v3, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_2

    .line 332
    :cond_b
    new-instance p1, Lru/supportagent/TemplateRepository$SearchResults;

    invoke-direct {p1, v3, v2, v1}, Lru/supportagent/TemplateRepository$SearchResults;-><init>(Ljava/util/List;ILru/supportagent/TemplateRepository$SearchResults-IA;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public updateTopic(Lru/supportagent/Topic;Ljava/lang/String;)V
    .locals 5

    .line 353
    invoke-static {p2}, Lru/supportagent/TemplateRepository;->cleanTopicTitle(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    if-eqz p1, :cond_3

    .line 354
    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_1

    .line 355
    :cond_0
    invoke-virtual {p0}, Lru/supportagent/TemplateRepository;->getTopics()Ljava/util/List;

    move-result-object v0

    .line 356
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/Topic;

    iget-object v3, v2, Lru/supportagent/Topic;->id:Ljava/lang/String;

    iget-object v4, p1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    iput-object p2, v2, Lru/supportagent/Topic;->name:Ljava/lang/String;

    goto :goto_0

    .line 357
    :cond_2
    invoke-virtual {p0}, Lru/supportagent/TemplateRepository;->getAllTemplates()Ljava/util/List;

    move-result-object p1

    invoke-direct {p0, v0, p1}, Lru/supportagent/TemplateRepository;->saveAll(Ljava/util/List;Ljava/util/List;)V

    :cond_3
    :goto_1
    return-void
.end method
