.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda50;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lru/supportagent/OverlayService$SearchRenderer;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:Landroid/widget/LinearLayout;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;Landroid/widget/LinearLayout;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda50;->f$0:Lru/supportagent/OverlayService;

    iput-object p2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda50;->f$1:Landroid/widget/LinearLayout;

    return-void
.end method


# virtual methods
.method public final render(Ljava/lang/String;)V
    .locals 2

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda50;->f$0:Lru/supportagent/OverlayService;

    iget-object v1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda50;->f$1:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1, p1}, Lru/supportagent/OverlayService;->lambda$showSearch$47$ru-supportagent-OverlayService(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    return-void
.end method
