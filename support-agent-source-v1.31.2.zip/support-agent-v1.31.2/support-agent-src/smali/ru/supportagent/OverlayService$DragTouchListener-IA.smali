.class public final synthetic Lru/supportagent/OverlayService$DragTouchListener-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
