.class public interface abstract Lru/supportagent/ColorWheelView$OnColorChangedListener;
.super Ljava/lang/Object;
.source "ColorWheelView.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lru/supportagent/ColorWheelView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnColorChangedListener"
.end annotation


# virtual methods
.method public abstract onColorChanged(I)V
.end method
