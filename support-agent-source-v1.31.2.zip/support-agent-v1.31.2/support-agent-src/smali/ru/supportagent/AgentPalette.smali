.class public final Lru/supportagent/AgentPalette;
.super Ljava/lang/Object;
.source "AgentPalette.java"


# instance fields
.field public accent:Ljava/lang/String;

.field public background:Ljava/lang/String;

.field public builtIn:Z

.field public gold:Ljava/lang/String;

.field public id:Ljava/lang/String;

.field public muted:Ljava/lang/String;

.field public name:Ljava/lang/String;

.field public outline:Ljava/lang/String;

.field public panel:Ljava/lang/String;

.field public text:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    .locals 0

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    iput-object p1, p0, Lru/supportagent/AgentPalette;->id:Ljava/lang/String;

    .line 23
    iput-object p2, p0, Lru/supportagent/AgentPalette;->name:Ljava/lang/String;

    .line 24
    iput-object p3, p0, Lru/supportagent/AgentPalette;->background:Ljava/lang/String;

    .line 25
    iput-object p4, p0, Lru/supportagent/AgentPalette;->panel:Ljava/lang/String;

    .line 26
    iput-object p5, p0, Lru/supportagent/AgentPalette;->outline:Ljava/lang/String;

    .line 27
    iput-object p6, p0, Lru/supportagent/AgentPalette;->accent:Ljava/lang/String;

    .line 28
    iput-object p7, p0, Lru/supportagent/AgentPalette;->text:Ljava/lang/String;

    .line 29
    iput-object p8, p0, Lru/supportagent/AgentPalette;->muted:Ljava/lang/String;

    .line 30
    iput-object p9, p0, Lru/supportagent/AgentPalette;->gold:Ljava/lang/String;

    .line 31
    iput-boolean p10, p0, Lru/supportagent/AgentPalette;->builtIn:Z

    return-void
.end method

.method private static blend(IIF)I
    .locals 4

    const/high16 v0, 0x3f800000    # 1.0f

    .line 124
    invoke-static {v0, p2}, Ljava/lang/Math;->min(FF)F

    move-result p2

    const/4 v1, 0x0

    invoke-static {v1, p2}, Ljava/lang/Math;->max(FF)F

    move-result p2

    .line 125
    invoke-static {p0}, Landroid/graphics/Color;->red(I)I

    move-result v1

    int-to-float v1, v1

    sub-float/2addr v0, p2

    mul-float/2addr v1, v0

    invoke-static {p1}, Landroid/graphics/Color;->red(I)I

    move-result v2

    int-to-float v2, v2

    mul-float/2addr v2, p2

    add-float/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    .line 126
    invoke-static {p0}, Landroid/graphics/Color;->green(I)I

    move-result v2

    int-to-float v2, v2

    mul-float/2addr v2, v0

    invoke-static {p1}, Landroid/graphics/Color;->green(I)I

    move-result v3

    int-to-float v3, v3

    mul-float/2addr v3, p2

    add-float/2addr v2, v3

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    .line 127
    invoke-static {p0}, Landroid/graphics/Color;->blue(I)I

    move-result p0

    int-to-float p0, p0

    mul-float/2addr p0, v0

    invoke-static {p1}, Landroid/graphics/Color;->blue(I)I

    move-result p1

    int-to-float p1, p1

    mul-float/2addr p1, p2

    add-float/2addr p0, p1

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    .line 128
    invoke-static {v1, v2, p0}, Landroid/graphics/Color;->rgb(III)I

    move-result p0

    return p0
.end method

.method public static color(Ljava/lang/String;I)I
    .locals 0

    .line 44
    :try_start_0
    invoke-static {p0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p0

    :catch_0
    return p1
.end method

.method public static crimson()Lru/supportagent/AgentPalette;
    .locals 12

    .line 108
    new-instance v11, Lru/supportagent/AgentPalette;

    const-string v1, "crimson"

    const-string v2, "\u0411\u0430\u0433\u0440\u044f\u043d\u044b\u0439"

    const-string v3, "#1B0B10"

    const-string v4, "#291119"

    const-string v5, "#633040"

    const-string v6, "#FF5368"

    const-string v7, "#FFF5F7"

    const-string v8, "#D2A0AA"

    const-string v9, "#FF5368"

    const/4 v10, 0x1

    move-object v0, v11

    invoke-direct/range {v0 .. v10}, Lru/supportagent/AgentPalette;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-object v11
.end method

.method public static emerald()Lru/supportagent/AgentPalette;
    .locals 12

    .line 103
    new-instance v11, Lru/supportagent/AgentPalette;

    const-string v1, "emerald"

    const-string v2, "\u0418\u0437\u0443\u043c\u0440\u0443\u0434"

    const-string v3, "#071C18"

    const-string v4, "#0D2B25"

    const-string v5, "#286050"

    const-string v6, "#38D39F"

    const-string v7, "#F1FFF9"

    const-string v8, "#91C8B7"

    const-string v9, "#38D39F"

    const/4 v10, 0x1

    move-object v0, v11

    invoke-direct/range {v0 .. v10}, Lru/supportagent/AgentPalette;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-object v11
.end method

.method public static fromJson(Lorg/json/JSONObject;)Lru/supportagent/AgentPalette;
    .locals 12

    .line 63
    new-instance v11, Lru/supportagent/AgentPalette;

    const-string v0, "id"

    .line 64
    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v0, "name"

    const-string v2, "\u0421\u0432\u043e\u044f \u043f\u0430\u043b\u0438\u0442\u0440\u0430"

    .line 65
    invoke-virtual {p0, v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v0, "background"

    const-string v3, "#0C1220"

    .line 66
    invoke-virtual {p0, v0, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v0, "panel"

    const-string v4, "#121A2A"

    .line 67
    invoke-virtual {p0, v0, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v0, "outline"

    const-string v5, "#344361"

    .line 68
    invoke-virtual {p0, v0, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v0, "accent"

    const-string v6, "#FF583E"

    .line 69
    invoke-virtual {p0, v0, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "text"

    const-string v9, "#F6F7FB"

    .line 70
    invoke-virtual {p0, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "muted"

    const-string v10, "#8994AE"

    .line 71
    invoke-virtual {p0, v9, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "gold"

    .line 72
    invoke-virtual {p0, v0, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v10, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v0, "builtIn"

    const/4 v6, 0x0

    .line 73
    invoke-virtual {p0, v0, v6}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result p0

    move-object v0, v11

    move-object v6, v7

    move-object v7, v8

    move-object v8, v9

    move-object v9, v10

    move v10, p0

    invoke-direct/range {v0 .. v10}, Lru/supportagent/AgentPalette;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-object v11
.end method

.method public static frost()Lru/supportagent/AgentPalette;
    .locals 12

    .line 88
    new-instance v11, Lru/supportagent/AgentPalette;

    const-string v1, "frost"

    const-string v2, "\u0425\u043e\u043b\u043e\u0434\u043d\u044b\u0439 \u044d\u043a\u0440\u0430\u043d"

    const-string v3, "#0B1621"

    const-string v4, "#102332"

    const-string v5, "#315878"

    const-string v6, "#FF624B"

    const-string v7, "#F4F9FF"

    const-string v8, "#86A6C1"

    const-string v9, "#FF624B"

    const/4 v10, 0x1

    move-object v0, v11

    invoke-direct/range {v0 .. v10}, Lru/supportagent/AgentPalette;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-object v11
.end method

.method public static graphite()Lru/supportagent/AgentPalette;
    .locals 12

    .line 83
    new-instance v11, Lru/supportagent/AgentPalette;

    const-string v1, "graphite"

    const-string v2, "\u0413\u0440\u0430\u0444\u0438\u0442"

    const-string v3, "#111214"

    const-string v4, "#1B1D22"

    const-string v5, "#454A56"

    const-string v6, "#F05A43"

    const-string v7, "#FAFAFC"

    const-string v8, "#9A9DA7"

    const-string v9, "#F05A43"

    const/4 v10, 0x1

    move-object v0, v11

    invoke-direct/range {v0 .. v10}, Lru/supportagent/AgentPalette;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-object v11
.end method

.method private static hex(I)Ljava/lang/String;
    .locals 2

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const v1, 0xffffff

    and-int/2addr p0, v1

    .line 132
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v1, 0x0

    aput-object p0, v0, v1

    const-string p0, "#%06X"

    invoke-static {p0, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static night()Lru/supportagent/AgentPalette;
    .locals 12

    .line 78
    new-instance v11, Lru/supportagent/AgentPalette;

    const-string v1, "night"

    const-string v2, "\u041d\u043e\u0447\u043d\u0430\u044f BR"

    const-string v3, "#0C1220"

    const-string v4, "#121A2A"

    const-string v5, "#344361"

    const-string v6, "#FF583E"

    const-string v7, "#F6F7FB"

    const-string v8, "#8994AE"

    const-string v9, "#FF583E"

    const/4 v10, 0x1

    move-object v0, v11

    invoke-direct/range {v0 .. v10}, Lru/supportagent/AgentPalette;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-object v11
.end method

.method public static ocean()Lru/supportagent/AgentPalette;
    .locals 12

    .line 93
    new-instance v11, Lru/supportagent/AgentPalette;

    const-string v1, "ocean"

    const-string v2, "\u041e\u043a\u0435\u0430\u043d"

    const-string v3, "#071923"

    const-string v4, "#0C2835"

    const-string v5, "#24556D"

    const-string v6, "#3AB7E8"

    const-string v7, "#F0FBFF"

    const-string v8, "#8EB7C8"

    const-string v9, "#3AB7E8"

    const/4 v10, 0x1

    move-object v0, v11

    invoke-direct/range {v0 .. v10}, Lru/supportagent/AgentPalette;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-object v11
.end method

.method public static violet()Lru/supportagent/AgentPalette;
    .locals 12

    .line 98
    new-instance v11, Lru/supportagent/AgentPalette;

    const-string v1, "violet"

    const-string v2, "\u041d\u0435\u043e\u043d \u0444\u0438\u043e\u043b\u0435\u0442"

    const-string v3, "#130E20"

    const-string v4, "#211834"

    const-string v5, "#514071"

    const-string v6, "#B887FF"

    const-string v7, "#FAF6FF"

    const-string v8, "#B4A2CC"

    const-string v9, "#B887FF"

    const/4 v10, 0x1

    move-object v0, v11

    invoke-direct/range {v0 .. v10}, Lru/supportagent/AgentPalette;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-object v11
.end method

.method public static wheel(I)Lru/supportagent/AgentPalette;
    .locals 17

    .line 114
    invoke-static/range {p0 .. p0}, Landroid/graphics/Color;->red(I)I

    move-result v0

    invoke-static/range {p0 .. p0}, Landroid/graphics/Color;->green(I)I

    move-result v1

    invoke-static/range {p0 .. p0}, Landroid/graphics/Color;->blue(I)I

    move-result v2

    invoke-static {v0, v1, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v0

    const v1, -0xf6f0e5

    const v2, 0x3e051eb8    # 0.13f

    .line 115
    invoke-static {v1, v0, v2}, Lru/supportagent/AgentPalette;->blend(IIF)I

    move-result v1

    const v2, -0xede5d6

    const v3, 0x3e4ccccd    # 0.2f

    .line 116
    invoke-static {v2, v0, v3}, Lru/supportagent/AgentPalette;->blend(IIF)I

    move-result v2

    const v3, -0xc5b99f

    const v4, 0x3f051eb8    # 0.52f

    .line 117
    invoke-static {v3, v0, v4}, Lru/supportagent/AgentPalette;->blend(IIF)I

    move-result v3

    const v4, -0x62553f

    const v5, 0x3e6147ae    # 0.22f

    .line 118
    invoke-static {v4, v0, v5}, Lru/supportagent/AgentPalette;->blend(IIF)I

    move-result v4

    .line 119
    new-instance v16, Lru/supportagent/AgentPalette;

    const-string v6, "wheel_color"

    const-string v7, "\u041c\u043e\u0439 \u0446\u0432\u0435\u0442"

    invoke-static {v1}, Lru/supportagent/AgentPalette;->hex(I)Ljava/lang/String;

    move-result-object v8

    invoke-static {v2}, Lru/supportagent/AgentPalette;->hex(I)Ljava/lang/String;

    move-result-object v9

    invoke-static {v3}, Lru/supportagent/AgentPalette;->hex(I)Ljava/lang/String;

    move-result-object v10

    .line 120
    invoke-static {v0}, Lru/supportagent/AgentPalette;->hex(I)Ljava/lang/String;

    move-result-object v11

    const-string v12, "#F7F9FF"

    invoke-static {v4}, Lru/supportagent/AgentPalette;->hex(I)Ljava/lang/String;

    move-result-object v13

    invoke-static {v0}, Lru/supportagent/AgentPalette;->hex(I)Ljava/lang/String;

    move-result-object v14

    const/4 v15, 0x0

    move-object/from16 v5, v16

    invoke-direct/range {v5 .. v15}, Lru/supportagent/AgentPalette;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-object v16
.end method


# virtual methods
.method public accentColor()I
    .locals 2

    .line 37
    iget-object v0, p0, Lru/supportagent/AgentPalette;->accent:Ljava/lang/String;

    const v1, -0xa7c2

    invoke-static {v0, v1}, Lru/supportagent/AgentPalette;->color(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

.method public backgroundColor()I
    .locals 2

    .line 34
    iget-object v0, p0, Lru/supportagent/AgentPalette;->background:Ljava/lang/String;

    const v1, -0xf3ede0

    invoke-static {v0, v1}, Lru/supportagent/AgentPalette;->color(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

.method public goldColor()I
    .locals 1

    .line 41
    invoke-virtual {p0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    return v0
.end method

.method public mutedColor()I
    .locals 2

    .line 39
    iget-object v0, p0, Lru/supportagent/AgentPalette;->muted:Ljava/lang/String;

    const v1, -0x766b52

    invoke-static {v0, v1}, Lru/supportagent/AgentPalette;->color(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

.method public outlineColor()I
    .locals 2

    .line 36
    iget-object v0, p0, Lru/supportagent/AgentPalette;->outline:Ljava/lang/String;

    const v1, -0xcbbc9f

    invoke-static {v0, v1}, Lru/supportagent/AgentPalette;->color(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

.method public panelColor()I
    .locals 2

    .line 35
    iget-object v0, p0, Lru/supportagent/AgentPalette;->panel:Ljava/lang/String;

    const v1, -0xede5d6

    invoke-static {v0, v1}, Lru/supportagent/AgentPalette;->color(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

.method public textColor()I
    .locals 2

    .line 38
    iget-object v0, p0, Lru/supportagent/AgentPalette;->text:Ljava/lang/String;

    const v1, -0x90805

    invoke-static {v0, v1}, Lru/supportagent/AgentPalette;->color(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

.method public toJson()Lorg/json/JSONObject;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    .line 48
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const-string v1, "id"

    .line 49
    iget-object v2, p0, Lru/supportagent/AgentPalette;->id:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "name"

    .line 50
    iget-object v2, p0, Lru/supportagent/AgentPalette;->name:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "background"

    .line 51
    iget-object v2, p0, Lru/supportagent/AgentPalette;->background:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "panel"

    .line 52
    iget-object v2, p0, Lru/supportagent/AgentPalette;->panel:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "outline"

    .line 53
    iget-object v2, p0, Lru/supportagent/AgentPalette;->outline:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "accent"

    .line 54
    iget-object v2, p0, Lru/supportagent/AgentPalette;->accent:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "text"

    .line 55
    iget-object v2, p0, Lru/supportagent/AgentPalette;->text:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "muted"

    .line 56
    iget-object v2, p0, Lru/supportagent/AgentPalette;->muted:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "gold"

    .line 57
    iget-object v2, p0, Lru/supportagent/AgentPalette;->gold:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "builtIn"

    .line 58
    iget-boolean v2, p0, Lru/supportagent/AgentPalette;->builtIn:Z

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    return-object v0
.end method
