.class public final Lru/supportagent/TemplateRepository$SearchHit;
.super Ljava/lang/Object;
.source "TemplateRepository.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lru/supportagent/TemplateRepository;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "SearchHit"
.end annotation


# instance fields
.field public final answer:Lru/supportagent/AnswerTemplate;

.field public final topicName:Ljava/lang/String;


# direct methods
.method private constructor <init>(Lru/supportagent/AnswerTemplate;Ljava/lang/String;)V
    .locals 0

    .line 47
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 48
    iput-object p1, p0, Lru/supportagent/TemplateRepository$SearchHit;->answer:Lru/supportagent/AnswerTemplate;

    .line 49
    iput-object p2, p0, Lru/supportagent/TemplateRepository$SearchHit;->topicName:Ljava/lang/String;

    return-void
.end method

.method synthetic constructor <init>(Lru/supportagent/AnswerTemplate;Ljava/lang/String;Lru/supportagent/TemplateRepository$SearchHit-IA;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lru/supportagent/TemplateRepository$SearchHit;-><init>(Lru/supportagent/AnswerTemplate;Ljava/lang/String;)V

    return-void
.end method
