.class public final Lru/supportagent/PaletteRepository;
.super Ljava/lang/Object;
.source "PaletteRepository.java"


# static fields
.field private static final KEY_ACTIVE:Ljava/lang/String; = "active"

.field private static final KEY_ITEMS:Ljava/lang/String; = "items"

.field private static final PREFS:Ljava/lang/String; = "support_agent_palettes"


# instance fields
.field private final preferences:Landroid/content/SharedPreferences;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "support_agent_palettes"

    const/4 v1, 0x0

    .line 21
    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    iput-object p1, p0, Lru/supportagent/PaletteRepository;->preferences:Landroid/content/SharedPreferences;

    .line 22
    invoke-direct {p0}, Lru/supportagent/PaletteRepository;->ensureDefaults()V

    return-void
.end method

.method private builtIns()Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lru/supportagent/AgentPalette;",
            ">;"
        }
    .end annotation

    .line 26
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 27
    invoke-static {}, Lru/supportagent/AgentPalette;->night()Lru/supportagent/AgentPalette;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 28
    invoke-static {}, Lru/supportagent/AgentPalette;->graphite()Lru/supportagent/AgentPalette;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 29
    invoke-static {}, Lru/supportagent/AgentPalette;->frost()Lru/supportagent/AgentPalette;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 30
    invoke-static {}, Lru/supportagent/AgentPalette;->ocean()Lru/supportagent/AgentPalette;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 31
    invoke-static {}, Lru/supportagent/AgentPalette;->violet()Lru/supportagent/AgentPalette;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 32
    invoke-static {}, Lru/supportagent/AgentPalette;->emerald()Lru/supportagent/AgentPalette;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 33
    invoke-static {}, Lru/supportagent/AgentPalette;->crimson()Lru/supportagent/AgentPalette;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-object v0
.end method

.method private ensureDefaults()V
    .locals 10

    .line 39
    invoke-direct {p0}, Lru/supportagent/PaletteRepository;->readStored()Ljava/util/List;

    move-result-object v0

    .line 40
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    const-string v2, "night"

    if-eqz v1, :cond_0

    .line 41
    invoke-direct {p0}, Lru/supportagent/PaletteRepository;->builtIns()Ljava/util/List;

    move-result-object v0

    invoke-direct {p0, v0, v2}, Lru/supportagent/PaletteRepository;->write(Ljava/util/List;Ljava/lang/String;)V

    return-void

    .line 45
    :cond_0
    invoke-direct {p0}, Lru/supportagent/PaletteRepository;->builtIns()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v3, 0x0

    move v4, v3

    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lru/supportagent/AgentPalette;

    .line 47
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_2
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    const/4 v8, 0x1

    if-eqz v7, :cond_3

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lru/supportagent/AgentPalette;

    iget-object v9, v5, Lru/supportagent/AgentPalette;->id:Ljava/lang/String;

    iget-object v7, v7, Lru/supportagent/AgentPalette;->id:Ljava/lang/String;

    invoke-virtual {v9, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_2

    move v6, v8

    goto :goto_1

    :cond_3
    move v6, v3

    :goto_1
    if-nez v6, :cond_1

    .line 49
    invoke-interface {v0, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move v4, v8

    goto :goto_0

    :cond_4
    if-eqz v4, :cond_5

    .line 53
    iget-object v1, p0, Lru/supportagent/PaletteRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v3, "active"

    invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v0, v1}, Lru/supportagent/PaletteRepository;->write(Ljava/util/List;Ljava/lang/String;)V

    :cond_5
    return-void
.end method

.method private readStored()Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lru/supportagent/AgentPalette;",
            ">;"
        }
    .end annotation

    .line 57
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 59
    :try_start_0
    new-instance v1, Lorg/json/JSONArray;

    iget-object v2, p0, Lru/supportagent/PaletteRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v3, "items"

    const-string v4, "[]"

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    .line 60
    :goto_0
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v2, v3, :cond_0

    invoke-virtual {v1, v2}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    invoke-static {v3}, Lru/supportagent/AgentPalette;->fromJson(Lorg/json/JSONObject;)Lru/supportagent/AgentPalette;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :catch_0
    :cond_0
    return-object v0
.end method

.method private write(Ljava/util/List;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/AgentPalette;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 115
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    .line 117
    :try_start_0
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->toJson()Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 119
    :catch_0
    :cond_0
    iget-object p1, p0, Lru/supportagent/PaletteRepository;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const-string v1, "items"

    invoke-virtual {v0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1, v1, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const-string v0, "active"

    invoke-interface {p1, v0, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    return-void
.end method


# virtual methods
.method public delete(Ljava/lang/String;)V
    .locals 4

    .line 105
    invoke-virtual {p0}, Lru/supportagent/PaletteRepository;->getAll()Ljava/util/List;

    move-result-object v0

    .line 106
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    :goto_0
    if-ltz v1, :cond_1

    .line 107
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/AgentPalette;

    iget-object v2, v2, Lru/supportagent/AgentPalette;->id:Ljava/lang/String;

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/AgentPalette;

    iget-boolean v2, v2, Lru/supportagent/AgentPalette;->builtIn:Z

    if-nez v2, :cond_0

    invoke-interface {v0, v1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    :cond_0
    add-int/lit8 v1, v1, -0x1

    goto :goto_0

    .line 109
    :cond_1
    iget-object v1, p0, Lru/supportagent/PaletteRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v2, "active"

    const-string v3, "night"

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 110
    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    goto :goto_1

    :cond_2
    move-object v3, v1

    .line 111
    :goto_1
    invoke-direct {p0, v0, v3}, Lru/supportagent/PaletteRepository;->write(Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public getActive()Lru/supportagent/AgentPalette;
    .locals 4

    .line 71
    iget-object v0, p0, Lru/supportagent/PaletteRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v1, "active"

    const-string v2, "night"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 72
    invoke-virtual {p0}, Lru/supportagent/PaletteRepository;->getAll()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/AgentPalette;

    iget-object v3, v2, Lru/supportagent/AgentPalette;->id:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    return-object v2

    .line 73
    :cond_1
    invoke-static {}, Lru/supportagent/AgentPalette;->night()Lru/supportagent/AgentPalette;

    move-result-object v0

    return-object v0
.end method

.method public getAll()Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lru/supportagent/AgentPalette;",
            ">;"
        }
    .end annotation

    .line 66
    invoke-direct {p0}, Lru/supportagent/PaletteRepository;->readStored()Ljava/util/List;

    move-result-object v0

    .line 67
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-direct {p0}, Lru/supportagent/PaletteRepository;->builtIns()Ljava/util/List;

    move-result-object v0

    :cond_0
    return-object v0
.end method

.method public saveCustom(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 13

    .line 81
    invoke-virtual {p0}, Lru/supportagent/PaletteRepository;->getAll()Ljava/util/List;

    move-result-object v0

    .line 82
    new-instance v12, Lru/supportagent/AgentPalette;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "custom_"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    const-string v8, "#F6F7FB"

    const-string v9, "#A0AEC6"

    const/4 v11, 0x0

    move-object v1, v12

    move-object v4, p2

    move-object/from16 v5, p3

    move-object/from16 v6, p4

    move-object/from16 v7, p5

    move-object/from16 v10, p5

    invoke-direct/range {v1 .. v11}, Lru/supportagent/AgentPalette;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 84
    invoke-interface {v0, v12}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 85
    iget-object v1, v12, Lru/supportagent/AgentPalette;->id:Ljava/lang/String;

    move-object v2, p0

    invoke-direct {p0, v0, v1}, Lru/supportagent/PaletteRepository;->write(Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public saveWheelColor(I)V
    .locals 5

    .line 90
    invoke-virtual {p0}, Lru/supportagent/PaletteRepository;->getAll()Ljava/util/List;

    move-result-object v0

    .line 91
    invoke-static {p1}, Lru/supportagent/AgentPalette;->wheel(I)Lru/supportagent/AgentPalette;

    move-result-object p1

    const/4 v1, 0x0

    move v2, v1

    .line 93
    :goto_0
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    .line 94
    iget-object v3, p1, Lru/supportagent/AgentPalette;->id:Ljava/lang/String;

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lru/supportagent/AgentPalette;

    iget-object v4, v4, Lru/supportagent/AgentPalette;->id:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    .line 95
    invoke-interface {v0, v2, p1}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    if-nez v1, :cond_2

    .line 100
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 101
    :cond_2
    iget-object p1, p1, Lru/supportagent/AgentPalette;->id:Ljava/lang/String;

    invoke-direct {p0, v0, p1}, Lru/supportagent/PaletteRepository;->write(Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public setActive(Ljava/lang/String;)V
    .locals 2

    .line 77
    iget-object v0, p0, Lru/supportagent/PaletteRepository;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "active"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    return-void
.end method
