.class public final synthetic Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnShowListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/TemplateManagerActivity;

.field public final synthetic f$1:Landroidx/appcompat/app/AlertDialog;

.field public final synthetic f$2:Landroid/widget/EditText;

.field public final synthetic f$3:Landroid/widget/TextView;

.field public final synthetic f$4:Landroid/widget/EditText;

.field public final synthetic f$5:Lru/supportagent/AnswerTemplate;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/TemplateManagerActivity;Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;Landroid/widget/TextView;Landroid/widget/EditText;Lru/supportagent/AnswerTemplate;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda1;->f$0:Lru/supportagent/TemplateManagerActivity;

    iput-object p2, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda1;->f$1:Landroidx/appcompat/app/AlertDialog;

    iput-object p3, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda1;->f$2:Landroid/widget/EditText;

    iput-object p4, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda1;->f$3:Landroid/widget/TextView;

    iput-object p5, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda1;->f$4:Landroid/widget/EditText;

    iput-object p6, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda1;->f$5:Lru/supportagent/AnswerTemplate;

    return-void
.end method


# virtual methods
.method public final onShow(Landroid/content/DialogInterface;)V
    .locals 7

    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda1;->f$0:Lru/supportagent/TemplateManagerActivity;

    iget-object v1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda1;->f$1:Landroidx/appcompat/app/AlertDialog;

    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda1;->f$2:Landroid/widget/EditText;

    iget-object v3, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda1;->f$3:Landroid/widget/TextView;

    iget-object v4, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda1;->f$4:Landroid/widget/EditText;

    iget-object v5, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda1;->f$5:Lru/supportagent/AnswerTemplate;

    move-object v6, p1

    invoke-virtual/range {v0 .. v6}, Lru/supportagent/TemplateManagerActivity;->lambda$templateDialog$14$ru-supportagent-TemplateManagerActivity(Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;Landroid/widget/TextView;Landroid/widget/EditText;Lru/supportagent/AnswerTemplate;Landroid/content/DialogInterface;)V

    return-void
.end method
