.class public Lru/supportagent/ConfigActivity;
.super Landroid/app/Activity;
.source "ConfigActivity.java"


# static fields
.field private static final REQ_EXPORT:I = 0x1

.field private static final REQ_IMPORT:I = 0x2


# instance fields
.field private pendingExport:[B


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 20
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private toast(Ljava/lang/String;)V
    .registers 3

    .line 93
    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 94
    return-void
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .registers 5

    .line 67
    const/4 v0, -0x1

    if-ne p2, v0, :cond_6e

    if-eqz p3, :cond_6e

    :try_start_5
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p2

    if-eqz p2, :cond_6e

    .line 68
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p2

    .line 69
    invoke-virtual {p0}, Lru/supportagent/ConfigActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p3

    .line 70
    const/4 v0, 0x1

    if-ne p1, v0, :cond_2f

    iget-object v0, p0, Lru/supportagent/ConfigActivity;->pendingExport:[B

    if-eqz v0, :cond_2f

    .line 71
    invoke-virtual {p3, p2}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object p1

    .line 72
    iget-object p2, p0, Lru/supportagent/ConfigActivity;->pendingExport:[B

    invoke-virtual {p1, p2}, Ljava/io/OutputStream;->write([B)V

    .line 73
    invoke-virtual {p1}, Ljava/io/OutputStream;->flush()V

    .line 74
    invoke-virtual {p1}, Ljava/io/OutputStream;->close()V

    .line 75
    const-string p1, "\u041a\u043e\u043d\u0444\u0438\u0433 \u0432\u044b\u0433\u0440\u0443\u0436\u0435\u043d \u0432 \u0444\u0430\u0439\u043b"

    invoke-direct {p0, p1}, Lru/supportagent/ConfigActivity;->toast(Ljava/lang/String;)V

    goto :goto_51

    .line 76
    :cond_2f
    const/4 v0, 0x2

    if-ne p1, v0, :cond_51

    .line 77
    invoke-virtual {p3, p2}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object p1

    .line 78
    invoke-static {p0, p1}, Lru/supportagent/ConfigStore;->importConfig(Landroid/content/Context;Ljava/io/InputStream;)Ljava/lang/String;

    .line 79
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V

    .line 80
    const-string p1, "\u041a\u043e\u043d\u0444\u0438\u0433 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043d \u2014 \u0432\u0441\u0435 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u043f\u0435\u0440\u0435\u043d\u0435\u0441\u0435\u043d\u044b"

    invoke-direct {p0, p1}, Lru/supportagent/ConfigActivity;->toast(Ljava/lang/String;)V

    .line 81
    new-instance p1, Landroid/content/Intent;

    const-class p2, Lru/supportagent/OverlayService;

    invoke-direct {p1, p0, p2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 82
    const-string p2, "ru.supportagent.CONFIG_IMPORTED"

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 83
    invoke-virtual {p0, p1}, Lru/supportagent/ConfigActivity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_50
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_50} :catch_52

    goto :goto_6e

    .line 76
    :cond_51
    :goto_51
    goto :goto_6e

    .line 86
    :catch_52
    move-exception p1

    .line 87
    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lru/supportagent/ConfigActivity;->toast(Ljava/lang/String;)V

    goto :goto_6f

    .line 88
    :cond_6e
    :goto_6e
    nop

    .line 89
    :goto_6f
    invoke-virtual {p0}, Lru/supportagent/ConfigActivity;->finish()V

    .line 90
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 5

    .line 27
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 28
    invoke-virtual {p0}, Lru/supportagent/ConfigActivity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string v0, "mode"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 29
    if-nez p1, :cond_11

    .line 30
    const-string p1, ""

    .line 33
    :cond_11
    :try_start_11
    const-string v0, "save"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2e

    .line 34
    invoke-static {p0}, Lru/supportagent/ConfigStore;->snapshot(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_25

    .line 35
    const-string p1, "\u0421\u043d\u0438\u043c\u043e\u043a \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d"

    invoke-direct {p0, p1}, Lru/supportagent/ConfigActivity;->toast(Ljava/lang/String;)V

    goto :goto_2a

    .line 37
    :cond_25
    const-string p1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u0441\u043d\u0438\u043c\u043e\u043a"

    invoke-direct {p0, p1}, Lru/supportagent/ConfigActivity;->toast(Ljava/lang/String;)V

    .line 39
    :goto_2a
    invoke-virtual {p0}, Lru/supportagent/ConfigActivity;->finish()V

    .line 40
    return-void

    .line 42
    :cond_2e
    const-string v0, "export"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0
    :try_end_34
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_34} :catch_9f

    const-string v1, "android.intent.category.OPENABLE"

    if-eqz v0, :cond_82

    .line 43
    :try_start_38
    invoke-static {p0}, Lru/supportagent/ConfigStore;->exportBytes(Landroid/content/Context;)[B

    move-result-object p1

    iput-object p1, p0, Lru/supportagent/ConfigActivity;->pendingExport:[B

    .line 44
    new-instance p1, Landroid/content/Intent;

    const-string v0, "android.intent.action.CREATE_DOCUMENT"

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 45
    invoke-virtual {p1, v1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    .line 46
    const-string v0, "application/octet-stream"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 47
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "yyyy-MM-dd-HH-mm"

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v1, Ljava/util/Date;

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "support-agent-"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ".sacfg"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 48
    const-string v1, "android.intent.extra.title"

    invoke-virtual {p1, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 49
    const/4 v0, 0x1

    invoke-virtual {p0, p1, v0}, Lru/supportagent/ConfigActivity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 50
    return-void

    .line 52
    :cond_82
    const-string v0, "import"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_9e

    .line 53
    new-instance p1, Landroid/content/Intent;

    const-string v0, "android.intent.action.OPEN_DOCUMENT"

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 54
    invoke-virtual {p1, v1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    .line 55
    const-string v0, "*/*"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 56
    const/4 v0, 0x2

    invoke-virtual {p0, p1, v0}, Lru/supportagent/ConfigActivity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_9d
    .catch Ljava/lang/Exception; {:try_start_38 .. :try_end_9d} :catch_9f

    .line 57
    return-void

    .line 61
    :cond_9e
    goto :goto_ba

    .line 59
    :catch_9f
    move-exception p1

    .line 60
    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lru/supportagent/ConfigActivity;->toast(Ljava/lang/String;)V

    .line 62
    :goto_ba
    invoke-virtual {p0}, Lru/supportagent/ConfigActivity;->finish()V

    .line 63
    return-void
.end method
