.class public final synthetic Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda17;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnShowListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/TemplateManagerActivity;

.field public final synthetic f$1:Landroidx/appcompat/app/AlertDialog;

.field public final synthetic f$2:Landroid/widget/EditText;

.field public final synthetic f$3:Lru/supportagent/Topic;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/TemplateManagerActivity;Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;Lru/supportagent/Topic;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda17;->f$0:Lru/supportagent/TemplateManagerActivity;

    iput-object p2, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda17;->f$1:Landroidx/appcompat/app/AlertDialog;

    iput-object p3, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda17;->f$2:Landroid/widget/EditText;

    iput-object p4, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda17;->f$3:Lru/supportagent/Topic;

    return-void
.end method


# virtual methods
.method public final onShow(Landroid/content/DialogInterface;)V
    .locals 4

    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda17;->f$0:Lru/supportagent/TemplateManagerActivity;

    iget-object v1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda17;->f$1:Landroidx/appcompat/app/AlertDialog;

    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda17;->f$2:Landroid/widget/EditText;

    iget-object v3, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda17;->f$3:Lru/supportagent/Topic;

    invoke-virtual {v0, v1, v2, v3, p1}, Lru/supportagent/TemplateManagerActivity;->lambda$topicDialog$10$ru-supportagent-TemplateManagerActivity(Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;Lru/supportagent/Topic;Landroid/content/DialogInterface;)V

    return-void
.end method
