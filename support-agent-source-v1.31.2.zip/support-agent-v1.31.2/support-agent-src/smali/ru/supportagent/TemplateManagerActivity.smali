.class public final Lru/supportagent/TemplateManagerActivity;
.super Landroidx/appcompat/app/AppCompatActivity;
.source "TemplateManagerActivity.java"


# instance fields
.field private activeTopic:Lru/supportagent/Topic;

.field private palette:Lru/supportagent/AgentPalette;

.field private repository:Lru/supportagent/TemplateRepository;

.field private root:Landroid/widget/LinearLayout;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 21
    invoke-direct {p0}, Landroidx/appcompat/app/AppCompatActivity;-><init>()V

    return-void
.end method

.method private deleteTemplateConfirm(Lru/supportagent/AnswerTemplate;)V
    .locals 3

    .line 293
    new-instance v0, Landroidx/appcompat/app/AlertDialog$Builder;

    const v1, 0x7f0e00a2

    invoke-direct {v0, p0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    const-string v1, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u043e\u0442\u0432\u0435\u0442?"

    .line 294
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "\u00ab"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p1, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\u00bb \u0431\u0443\u0434\u0435\u0442 \u0443\u0434\u0430\u043b\u0451\u043d \u0431\u0435\u0437 \u0432\u043e\u0437\u043c\u043e\u0436\u043d\u043e\u0441\u0442\u0438 \u0432\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 295
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "\u041e\u0422\u041c\u0415\u041d\u0410"

    const/4 v2, 0x0

    .line 296
    invoke-virtual {v0, v1, v2}, Landroidx/appcompat/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p1}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda0;-><init>(Lru/supportagent/TemplateManagerActivity;Lru/supportagent/AnswerTemplate;)V

    const-string p1, "\u0423\u0414\u0410\u041b\u0418\u0422\u042c"

    .line 297
    invoke-virtual {v0, p1, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object p1

    .line 302
    invoke-virtual {p1}, Landroidx/appcompat/app/AlertDialog$Builder;->create()Landroidx/appcompat/app/AlertDialog;

    move-result-object p1

    .line 303
    new-instance v0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda10;

    invoke-direct {v0, p0, p1}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda10;-><init>(Lru/supportagent/TemplateManagerActivity;Landroidx/appcompat/app/AlertDialog;)V

    invoke-virtual {p1, v0}, Landroidx/appcompat/app/AlertDialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 304
    invoke-virtual {p1}, Landroidx/appcompat/app/AlertDialog;->show()V

    return-void
.end method

.method private deleteTopicConfirm(Lru/supportagent/Topic;)V
    .locals 3

    .line 308
    new-instance v0, Landroidx/appcompat/app/AlertDialog$Builder;

    const v1, 0x7f0e00a2

    invoke-direct {v0, p0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    const-string v1, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u0442\u0435\u043c\u0443?"

    .line 309
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "\u0412\u043c\u0435\u0441\u0442\u0435 \u0441 \u0442\u0435\u043c\u043e\u0439 \u00ab"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p1, Lru/supportagent/Topic;->name:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\u00bb \u0443\u0434\u0430\u043b\u044f\u0442\u0441\u044f \u0432\u0441\u0435 \u0435\u0451 \u043e\u0442\u0432\u0435\u0442\u044b."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 310
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "\u041e\u0422\u041c\u0415\u041d\u0410"

    const/4 v2, 0x0

    .line 311
    invoke-virtual {v0, v1, v2}, Landroidx/appcompat/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda11;

    invoke-direct {v1, p0, p1}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda11;-><init>(Lru/supportagent/TemplateManagerActivity;Lru/supportagent/Topic;)V

    const-string p1, "\u0423\u0414\u0410\u041b\u0418\u0422\u042c"

    .line 312
    invoke-virtual {v0, p1, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object p1

    .line 317
    invoke-virtual {p1}, Landroidx/appcompat/app/AlertDialog$Builder;->create()Landroidx/appcompat/app/AlertDialog;

    move-result-object p1

    .line 318
    new-instance v0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda12;

    invoke-direct {v0, p0, p1}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda12;-><init>(Lru/supportagent/TemplateManagerActivity;Landroidx/appcompat/app/AlertDialog;)V

    invoke-virtual {p1, v0}, Landroidx/appcompat/app/AlertDialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 319
    invoke-virtual {p1}, Landroidx/appcompat/app/AlertDialog;->show()V

    return-void
.end method

.method private dialogBox()Landroid/widget/LinearLayout;
    .locals 4

    .line 266
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 267
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v1, 0x40800000    # 4.0f

    .line 268
    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    const/high16 v2, 0x41000000    # 8.0f

    .line 269
    invoke-static {p0, v2}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v2, v1, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    return-object v0
.end method

.method private dialogLabel(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 3

    .line 274
    invoke-virtual {p1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    const/4 v1, 0x1

    const/high16 v2, 0x41300000    # 11.0f

    invoke-static {p0, p1, v2, v0, v1}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p1

    const v0, 0x3d75c28f    # 0.06f

    .line 275
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLetterSpacing(F)V

    return-object p1
.end method

.method private newPage(Ljava/lang/String;Ljava/lang/String;Z)Landroid/widget/LinearLayout;
    .locals 14

    move-object v7, p0

    .line 58
    iget-object v0, v7, Lru/supportagent/TemplateManagerActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 59
    iget-object v0, v7, Lru/supportagent/TemplateManagerActivity;->root:Landroid/widget/LinearLayout;

    iget-object v1, v7, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 60
    new-instance v0, Landroid/widget/ScrollView;

    invoke-direct {v0, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 61
    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v9, 0x1

    .line 62
    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v1, 0x41a00000    # 20.0f

    .line 63
    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    const/high16 v3, 0x41b00000    # 22.0f

    invoke-static {p0, v3}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    const/high16 v4, 0x41f00000    # 30.0f

    invoke-static {p0, v4}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    invoke-virtual {v8, v2, v3, v1, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 64
    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, -0x1

    const/4 v10, -0x2

    invoke-direct {v1, v2, v10}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v8, v1}, Landroid/widget/ScrollView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 65
    iget-object v1, v7, Lru/supportagent/TemplateManagerActivity;->root:Landroid/widget/LinearLayout;

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v3, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 67
    new-instance v11, Landroid/widget/LinearLayout;

    invoke-direct {v11, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x10

    .line 68
    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/4 v12, 0x0

    if-eqz p3, :cond_0

    const-string v0, "\u2039"

    .line 70
    iget-object v1, v7, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-static {p0, v0, v1, v12}, Lru/supportagent/Ui;->button(Landroid/content/Context;Ljava/lang/String;Lru/supportagent/AgentPalette;Z)Landroid/widget/TextView;

    move-result-object v13

    const/high16 v0, 0x41c80000    # 25.0f

    .line 71
    invoke-virtual {v13, v0}, Landroid/widget/TextView;->setTextSize(F)V

    const/high16 v0, 0x40000000    # 2.0f

    .line 72
    invoke-static {p0, v0}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    invoke-virtual {v13, v12, v12, v12, v0}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 73
    new-instance v0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda16;

    invoke-direct {v0, p0}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda16;-><init>(Lru/supportagent/TemplateManagerActivity;)V

    invoke-virtual {v13, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v1, 0x2d

    const/16 v2, 0x2a

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/16 v5, 0xc

    const/4 v6, 0x0

    move-object v0, p0

    .line 74
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 76
    :cond_0
    iget-object v0, v7, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v0

    const/high16 v1, 0x41a80000    # 21.0f

    move-object v2, p1

    invoke-static {p0, p1, v1, v0, v9}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    .line 77
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-direct {v1, v12, v10, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v11, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    move-object v0, p0

    .line 78
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 79
    iget-object v0, v7, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    const/high16 v1, 0x41300000    # 11.0f

    move-object/from16 v2, p2

    invoke-static {p0, v2, v1, v0, v9}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v9

    const v0, 0x3d99999a    # 0.075f

    .line 80
    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setLetterSpacing(F)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    if-eqz p3, :cond_1

    const/16 v0, 0x39

    goto :goto_0

    :cond_1
    const/4 v0, 0x2

    :goto_0
    move v3, v0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v6, 0x14

    move-object v0, p0

    .line 81
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v8
.end method

.method private refreshOverlay()V
    .locals 2

    .line 331
    invoke-static {}, Lru/supportagent/OverlayService;->isRunning()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 332
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lru/supportagent/OverlayService;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v1, "ru.supportagent.REFRESH"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 333
    invoke-virtual {p0, v0}, Lru/supportagent/TemplateManagerActivity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :cond_0
    return-void
.end method

.method private showTemplates(Lru/supportagent/Topic;)V
    .locals 11

    .line 126
    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->repository:Lru/supportagent/TemplateRepository;

    iget-object p1, p1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v0, p1}, Lru/supportagent/TemplateRepository;->getTopic(Ljava/lang/String;)Lru/supportagent/Topic;

    move-result-object p1

    iput-object p1, p0, Lru/supportagent/TemplateManagerActivity;->activeTopic:Lru/supportagent/Topic;

    if-nez p1, :cond_0

    .line 127
    invoke-direct {p0}, Lru/supportagent/TemplateManagerActivity;->showTopics()V

    return-void

    .line 128
    :cond_0
    iget-object p1, p1, Lru/supportagent/Topic;->name:Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object p1

    const-string v0, "\u041d\u0410\u0416\u041c\u0418\u0422\u0415 \u041d\u0410 \u041e\u0422\u0412\u0415\u0422, \u0427\u0422\u041e\u0411\u042b \u0418\u0417\u041c\u0415\u041d\u0418\u0422\u042c"

    const/4 v1, 0x1

    invoke-direct {p0, p1, v0, v1}, Lru/supportagent/TemplateManagerActivity;->newPage(Ljava/lang/String;Ljava/lang/String;Z)Landroid/widget/LinearLayout;

    move-result-object p1

    .line 129
    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->repository:Lru/supportagent/TemplateRepository;

    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity;->activeTopic:Lru/supportagent/Topic;

    iget-object v2, v2, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v0, v2}, Lru/supportagent/TemplateRepository;->getTemplates(Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    .line 130
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1

    .line 131
    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-static {p0, v2}, Lru/supportagent/Ui;->card(Landroid/content/Context;Lru/supportagent/AgentPalette;)Landroid/widget/LinearLayout;

    move-result-object v2

    .line 132
    iget-object v3, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v3

    const/4 v4, 0x0

    const-string v5, "\u0412 \u044d\u0442\u043e\u0439 \u0442\u0435\u043c\u0435 \u043f\u043e\u043a\u0430 \u043d\u0435\u0442 \u043e\u0442\u0432\u0435\u0442\u043e\u0432."

    const/high16 v6, 0x41600000    # 14.0f

    invoke-static {p0, v5, v6, v3, v4}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v3

    .line 133
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v5, -0x1

    const/4 v6, -0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/16 v10, 0xb

    move-object v4, p0

    .line 134
    invoke-static/range {v4 .. v10}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    invoke-virtual {p1, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 136
    :cond_1
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/AnswerTemplate;

    invoke-direct {p0, v2}, Lru/supportagent/TemplateManagerActivity;->templateCard(Lru/supportagent/AnswerTemplate;)Landroid/view/View;

    move-result-object v2

    const/4 v4, -0x1

    const/4 v5, -0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/16 v9, 0x9

    move-object v3, p0

    invoke-static/range {v3 .. v9}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    invoke-virtual {p1, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_0

    :cond_2
    const-string v0, "+ \u0414\u041e\u0411\u0410\u0412\u0418\u0422\u042c \u041e\u0422\u0412\u0415\u0422"

    .line 137
    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-static {p0, v0, v2, v1}, Lru/supportagent/Ui;->button(Landroid/content/Context;Ljava/lang/String;Lru/supportagent/AgentPalette;Z)Landroid/widget/TextView;

    move-result-object v0

    .line 138
    new-instance v1, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda15;

    invoke-direct {v1, p0}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda15;-><init>(Lru/supportagent/TemplateManagerActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, -0x1

    const/4 v4, -0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v2, p0

    .line 139
    invoke-static/range {v2 .. v8}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private showTopics()V
    .locals 13

    const/4 v0, 0x0

    .line 86
    iput-object v0, p0, Lru/supportagent/TemplateManagerActivity;->activeTopic:Lru/supportagent/Topic;

    const-string v0, "\u0422\u0415\u041c\u042b \u0418 \u0428\u0410\u0411\u041b\u041e\u041d\u042b"

    const-string v1, "\u0412\u0421\u0401 \u0421\u041e\u0425\u0420\u0410\u041d\u042f\u0415\u0422\u0421\u042f \u0422\u041e\u041b\u042c\u041a\u041e \u041d\u0410 \u0422\u0415\u041b\u0415\u0424\u041e\u041d\u0415"

    const/4 v2, 0x0

    .line 87
    invoke-direct {p0, v0, v1, v2}, Lru/supportagent/TemplateManagerActivity;->newPage(Ljava/lang/String;Ljava/lang/String;Z)Landroid/widget/LinearLayout;

    move-result-object v0

    .line 88
    iget-object v1, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-static {p0, v1}, Lru/supportagent/Ui;->card(Landroid/content/Context;Lru/supportagent/AgentPalette;)Landroid/widget/LinearLayout;

    move-result-object v1

    .line 89
    iget-object v3, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->goldColor()I

    move-result v3

    const/16 v4, 0x1e

    invoke-static {v3, v4}, Lru/supportagent/Ui;->withAlpha(II)I

    move-result v3

    iget-object v4, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v4}, Lru/supportagent/AgentPalette;->goldColor()I

    move-result v4

    iget-object v5, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    const-string v6, "\u0424\u0418\u041a\u0421\u0418\u0420\u041e\u0412\u0410\u041d\u041d\u042b\u0419 \u0424\u041e\u0420\u041c\u0410\u0422"

    invoke-static {p0, v6, v3, v4, v5}, Lru/supportagent/Ui;->chip(Landroid/content/Context;Ljava/lang/String;IILru/supportagent/AgentPalette;)Landroid/widget/TextView;

    move-result-object v3

    const/4 v5, -0x2

    const/4 v6, -0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/16 v10, 0x9

    move-object v4, p0

    .line 90
    invoke-static/range {v4 .. v10}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 91
    iget-object v3, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v3

    const-string v4, "\u041a\u0430\u0436\u0434\u044b\u0439 \u043e\u0442\u0432\u0435\u0442 \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u043d\u0430\u0447\u0438\u043d\u0430\u0435\u0442\u0441\u044f \u0441 \u00ab\u0417\u0434\u0440\u0430\u0432\u0441\u0442\u0432\u0443\u0439\u0442\u0435,\u00bb \u0438 \u0437\u0430\u043a\u0430\u043d\u0447\u0438\u0432\u0430\u0435\u0442\u0441\u044f \u00ab// \u041f\u0440\u0438\u044f\u0442\u043d\u043e\u0439 \u0438\u0433\u0440\u044b\u00bb. \u0412 \u0440\u0435\u0434\u0430\u043a\u0442\u043e\u0440\u0435 \u043c\u0435\u043d\u044f\u0435\u0442\u0441\u044f \u0442\u043e\u043b\u044c\u043a\u043e \u043e\u0441\u043d\u043e\u0432\u043d\u0430\u044f \u0447\u0430\u0441\u0442\u044c."

    const/high16 v5, 0x41500000    # 13.0f

    invoke-static {p0, v4, v5, v3, v2}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v3

    const/high16 v4, 0x40000000    # 2.0f

    .line 92
    invoke-static {p0, v4}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    int-to-float v4, v4

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-virtual {v3, v4, v5}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 93
    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v7, -0x1

    const/4 v8, -0x2

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/16 v12, 0xe

    move-object v6, p0

    .line 94
    invoke-static/range {v6 .. v12}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 96
    iget-object v1, p0, Lru/supportagent/TemplateManagerActivity;->repository:Lru/supportagent/TemplateRepository;

    invoke-virtual {v1}, Lru/supportagent/TemplateRepository;->getTopics()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lru/supportagent/Topic;

    invoke-direct {p0, v3}, Lru/supportagent/TemplateManagerActivity;->topicCard(Lru/supportagent/Topic;)Landroid/view/View;

    move-result-object v3

    const/4 v5, -0x1

    const/4 v6, -0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/16 v10, 0x9

    move-object v4, p0

    invoke-static/range {v4 .. v10}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_0

    :cond_0
    const-string v1, "+ \u0414\u041e\u0411\u0410\u0412\u0418\u0422\u042c \u0422\u0415\u041c\u0423"

    .line 97
    iget-object v3, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-static {p0, v1, v3, v2}, Lru/supportagent/Ui;->button(Landroid/content/Context;Ljava/lang/String;Lru/supportagent/AgentPalette;Z)Landroid/widget/TextView;

    move-result-object v1

    .line 98
    new-instance v2, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda18;

    invoke-direct {v2, p0}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda18;-><init>(Lru/supportagent/TemplateManagerActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v4, -0x1

    const/4 v5, -0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v3, p0

    .line 99
    invoke-static/range {v3 .. v9}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private styledInput(Ljava/lang/String;Z)Landroid/widget/EditText;
    .locals 3

    .line 280
    new-instance v0, Landroid/widget/EditText;

    invoke-direct {v0, p0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    .line 281
    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    const/4 p1, 0x0

    .line 282
    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setSelectAllOnFocus(Z)V

    const/high16 p1, 0x41700000    # 15.0f

    .line 283
    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setTextSize(F)V

    .line 284
    iget-object p1, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->textColor()I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setTextColor(I)V

    .line 285
    iget-object p1, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setHintTextColor(I)V

    xor-int/lit8 p1, p2, 0x1

    .line 286
    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setSingleLine(Z)V

    const/high16 p1, 0x41400000    # 12.0f

    .line 287
    invoke-static {p0, p1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result p2

    const/high16 v1, 0x41200000    # 10.0f

    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    invoke-static {p0, p1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result p1

    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    invoke-virtual {v0, p2, v2, p1, v1}, Landroid/widget/EditText;->setPadding(IIII)V

    .line 288
    iget-object p1, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result p1

    iget-object p2, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result p2

    const/high16 v1, 0x41100000    # 9.0f

    invoke-static {p1, p2, v1, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-object v0
.end method

.method private templateCard(Lru/supportagent/AnswerTemplate;)Landroid/view/View;
    .locals 14

    .line 143
    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-static {p0, v0}, Lru/supportagent/Ui;->card(Landroid/content/Context;Lru/supportagent/AgentPalette;)Landroid/widget/LinearLayout;

    move-result-object v0

    .line 144
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v2, 0x10

    .line 145
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 146
    iget-object v2, p1, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    iget-object v3, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v3

    const/4 v4, 0x1

    const/high16 v5, 0x41800000    # 16.0f

    invoke-static {p0, v2, v5, v3, v4}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v2

    .line 147
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, 0x0

    const/4 v5, -0x2

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-direct {v3, v4, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 148
    iget-object v2, p1, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    invoke-static {v2}, Lru/supportagent/ReplyComposer;->length(Ljava/lang/String;)I

    move-result v2

    .line 149
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, "/120"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v5, 0x78

    iget-object v7, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    if-le v2, v5, :cond_0

    invoke-virtual {v7}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v7

    goto :goto_0

    :cond_0
    invoke-virtual {v7}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v7

    :goto_0
    const/16 v8, 0x5a

    invoke-static {v7, v8}, Lru/supportagent/Ui;->withAlpha(II)I

    move-result v7

    if-le v2, v5, :cond_1

    .line 150
    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v2

    goto :goto_1

    :cond_1
    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v2

    :goto_1
    iget-object v5, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    .line 149
    invoke-static {p0, v3, v7, v2, v5}, Lru/supportagent/Ui;->chip(Landroid/content/Context;Ljava/lang/String;IILru/supportagent/AgentPalette;)Landroid/widget/TextView;

    move-result-object v2

    const/4 v8, -0x2

    const/4 v9, -0x2

    const/16 v10, 0x8

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    move-object v7, p0

    .line 151
    invoke-static/range {v7 .. v13}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 152
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 153
    iget-object v1, p1, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    invoke-static {v1}, Lru/supportagent/ReplyComposer;->compose(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v2

    const v3, 0x414b3333    # 12.7f

    invoke-static {p0, v1, v3, v2, v4}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v1

    const/4 v2, 0x2

    .line 154
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setMaxLines(I)V

    const/high16 v2, 0x40000000    # 2.0f

    .line 155
    invoke-static {p0, v2}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v1, v2, v6}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v8, -0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    .line 156
    invoke-static/range {v7 .. v13}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 157
    new-instance v1, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0, p1}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda5;-><init>(Lru/supportagent/TemplateManagerActivity;Lru/supportagent/AnswerTemplate;)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 158
    new-instance v1, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda6;

    invoke-direct {v1, p0, p1}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda6;-><init>(Lru/supportagent/TemplateManagerActivity;Lru/supportagent/AnswerTemplate;)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    return-object v0
.end method

.method private templateDialog(Lru/supportagent/AnswerTemplate;)V
    .locals 12

    .line 206
    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->activeTopic:Lru/supportagent/Topic;

    if-nez v0, :cond_0

    return-void

    .line 207
    :cond_0
    invoke-direct {p0}, Lru/supportagent/TemplateManagerActivity;->dialogBox()Landroid/widget/LinearLayout;

    move-result-object v7

    const-string v0, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u043a\u043d\u043e\u043f\u043a\u0438"

    .line 208
    invoke-direct {p0, v0}, Lru/supportagent/TemplateManagerActivity;->dialogLabel(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v8

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    move-object v0, p0

    .line 209
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v7, v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v8, ""

    if-nez p1, :cond_1

    move-object v0, v8

    goto :goto_0

    .line 210
    :cond_1
    iget-object v0, p1, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    :goto_0
    const/4 v9, 0x0

    invoke-direct {p0, v0, v9}, Lru/supportagent/TemplateManagerActivity;->styledInput(Ljava/lang/String;Z)Landroid/widget/EditText;

    move-result-object v10

    const-string v0, "\u041d\u0430\u043f\u0440\u0438\u043c\u0435\u0440, \u041c\u0427\u0421"

    .line 211
    invoke-virtual {v10, v0}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v6, 0xd

    move-object v0, p0

    .line 212
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v7, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u041e\u0441\u043d\u043e\u0432\u043d\u043e\u0439 \u0442\u0435\u043a\u0441\u0442 \u043e\u0442\u0432\u0435\u0442\u0430"

    .line 213
    invoke-direct {p0, v0}, Lru/supportagent/TemplateManagerActivity;->dialogLabel(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v11

    const/4 v6, 0x7

    move-object v0, p0

    .line 214
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v7, v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-nez p1, :cond_2

    move-object v0, v8

    goto :goto_1

    .line 215
    :cond_2
    iget-object v0, p1, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    :goto_1
    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Lru/supportagent/TemplateManagerActivity;->styledInput(Ljava/lang/String;Z)Landroid/widget/EditText;

    move-result-object v11

    const-string v0, "\u041d\u0430\u043f\u0440\u0438\u043c\u0435\u0440, \u0434\u043b\u044f \u041c\u0427\u0421 \u043d\u0443\u0436\u0435\u043d 5 \u0443\u0440\u043e\u0432\u0435\u043d\u044c"

    .line 216
    invoke-virtual {v11, v0}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    const v0, 0x800033

    .line 217
    invoke-virtual {v11, v0}, Landroid/widget/EditText;->setGravity(I)V

    const/4 v0, 0x3

    .line 218
    invoke-virtual {v11, v0}, Landroid/widget/EditText;->setMinLines(I)V

    const/4 v0, 0x5

    .line 219
    invoke-virtual {v11, v0}, Landroid/widget/EditText;->setMaxLines(I)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    move-object v0, p0

    .line 220
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v7, v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 221
    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    const/high16 v1, 0x41400000    # 12.0f

    invoke-static {p0, v8, v1, v0, v9}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v8

    const v0, 0x800005

    .line 222
    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v1, -0x1

    const/4 v6, 0x4

    move-object v0, p0

    .line 223
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v7, v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 224
    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    const-string v1, "\u041f\u0440\u0438\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435 \u0438 \u00ab// \u041f\u0440\u0438\u044f\u0442\u043d\u043e\u0439 \u0438\u0433\u0440\u044b\u00bb \u0434\u043e\u0431\u0430\u0432\u044f\u0442\u0441\u044f \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438."

    const/high16 v2, 0x41380000    # 11.5f

    invoke-static {p0, v1, v2, v0, v9}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v9

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v4, 0x3

    const/4 v6, 0x0

    move-object v0, p0

    .line 225
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v7, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 227
    new-instance v0, Landroidx/appcompat/app/AlertDialog$Builder;

    const v1, 0x7f0e00a2

    invoke-direct {v0, p0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    if-nez p1, :cond_3

    const-string v1, "\u041d\u043e\u0432\u044b\u0439 \u043e\u0442\u0432\u0435\u0442"

    goto :goto_2

    :cond_3
    const-string v1, "\u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u043e\u0442\u0432\u0435\u0442"

    .line 228
    :goto_2
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    .line 229
    invoke-virtual {v0, v7}, Landroidx/appcompat/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "\u041e\u0422\u041c\u0415\u041d\u0410"

    const/4 v2, 0x0

    .line 230
    invoke-virtual {v0, v1, v2}, Landroidx/appcompat/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "\u0421\u041e\u0425\u0420\u0410\u041d\u0418\u0422\u042c"

    .line 231
    invoke-virtual {v0, v1, v2}, Landroidx/appcompat/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    if-eqz p1, :cond_4

    const-string v1, "\u0423\u0414\u0410\u041b\u0418\u0422\u042c"

    .line 232
    invoke-virtual {v0, v1, v2}, Landroidx/appcompat/app/AlertDialog$Builder;->setNeutralButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    .line 233
    :cond_4
    invoke-virtual {v0}, Landroidx/appcompat/app/AlertDialog$Builder;->create()Landroidx/appcompat/app/AlertDialog;

    move-result-object v7

    .line 234
    new-instance v9, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda1;

    move-object v0, v9

    move-object v1, p0

    move-object v2, v7

    move-object v3, v11

    move-object v4, v8

    move-object v5, v10

    move-object v6, p1

    invoke-direct/range {v0 .. v6}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda1;-><init>(Lru/supportagent/TemplateManagerActivity;Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;Landroid/widget/TextView;Landroid/widget/EditText;Lru/supportagent/AnswerTemplate;)V

    invoke-virtual {v7, v9}, Landroidx/appcompat/app/AlertDialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 262
    invoke-virtual {v7}, Landroidx/appcompat/app/AlertDialog;->show()V

    return-void
.end method

.method private tintDialog(Landroidx/appcompat/app/AlertDialog;)V
    .locals 2

    .line 323
    invoke-virtual {p1}, Landroidx/appcompat/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 325
    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    iget-object v1, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v1

    invoke-direct {v0, v1}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {p1, v0}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 326
    invoke-virtual {p0}, Lru/supportagent/TemplateManagerActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-float v0, v0

    const v1, 0x3f6b851f    # 0.92f

    mul-float/2addr v0, v1

    float-to-int v0, v0

    const/4 v1, -0x2

    invoke-virtual {p1, v0, v1}, Landroid/view/Window;->setLayout(II)V

    :cond_0
    return-void
.end method

.method private topicActions(Lru/supportagent/Topic;)V
    .locals 3

    const-string v0, "\u041f\u0435\u0440\u0435\u0438\u043c\u0435\u043d\u043e\u0432\u0430\u0442\u044c"

    const-string v1, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u0442\u0435\u043c\u0443"

    .line 163
    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    .line 164
    new-instance v1, Landroidx/appcompat/app/AlertDialog$Builder;

    const v2, 0x7f0e00a2

    invoke-direct {v1, p0, v2}, Landroidx/appcompat/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    iget-object v2, p1, Lru/supportagent/Topic;->name:Ljava/lang/String;

    .line 165
    invoke-virtual {v1, v2}, Landroidx/appcompat/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v1

    new-instance v2, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda13;

    invoke-direct {v2, p0, p1}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda13;-><init>(Lru/supportagent/TemplateManagerActivity;Lru/supportagent/Topic;)V

    .line 166
    invoke-virtual {v1, v0, v2}, Landroidx/appcompat/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object p1

    const-string v0, "\u041e\u0422\u041c\u0415\u041d\u0410"

    const/4 v1, 0x0

    .line 169
    invoke-virtual {p1, v0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object p1

    .line 170
    invoke-virtual {p1}, Landroidx/appcompat/app/AlertDialog$Builder;->create()Landroidx/appcompat/app/AlertDialog;

    move-result-object p1

    .line 171
    new-instance v0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda14;

    invoke-direct {v0, p0, p1}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda14;-><init>(Lru/supportagent/TemplateManagerActivity;Landroidx/appcompat/app/AlertDialog;)V

    invoke-virtual {p1, v0}, Landroidx/appcompat/app/AlertDialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 172
    invoke-virtual {p1}, Landroidx/appcompat/app/AlertDialog;->show()V

    return-void
.end method

.method private topicCard(Lru/supportagent/Topic;)Landroid/view/View;
    .locals 12

    .line 103
    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-static {p0, v0}, Lru/supportagent/Ui;->card(Landroid/content/Context;Lru/supportagent/AgentPalette;)Landroid/widget/LinearLayout;

    move-result-object v7

    .line 104
    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x10

    .line 105
    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 106
    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    const/16 v1, 0x20

    invoke-static {v0, v1}, Lru/supportagent/Ui;->withAlpha(II)I

    move-result v0

    iget-object v1, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    const-string v3, "?"

    invoke-static {p0, v3, v0, v1, v2}, Lru/supportagent/Ui;->chip(Landroid/content/Context;Ljava/lang/String;IILru/supportagent/AgentPalette;)Landroid/widget/TextView;

    move-result-object v9

    const/high16 v10, 0x41800000    # 16.0f

    .line 107
    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextSize(F)V

    const/16 v1, 0x26

    const/16 v2, 0x26

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/16 v5, 0xc

    const/4 v6, 0x0

    move-object v0, p0

    .line 108
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 109
    new-instance v9, Landroid/widget/LinearLayout;

    invoke-direct {v9, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    .line 110
    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 111
    iget-object v1, p1, Lru/supportagent/Topic;->name:Ljava/lang/String;

    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v2

    invoke-static {p0, v1, v10, v2, v0}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    .line 112
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity;->repository:Lru/supportagent/TemplateRepository;

    iget-object v3, p1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lru/supportagent/TemplateRepository;->countForTopic(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u043e\u0442\u0432\u0435\u0442\u043e\u0432"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v2

    const/high16 v3, 0x41480000    # 12.5f

    const/4 v10, 0x0

    invoke-static {p0, v1, v3, v2, v10}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v11

    .line 113
    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    move-object v0, p0

    .line 114
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v9, v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 115
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-direct {v0, v10, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v8, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 116
    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    const-string v1, "\u203a"

    const/high16 v2, 0x41f00000    # 30.0f

    invoke-static {p0, v1, v2, v0, v10}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v9

    const/16 v0, 0x11

    .line 117
    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v1, 0x1e

    const/16 v2, 0x28

    const/4 v3, 0x4

    const/4 v4, 0x0

    move-object v0, p0

    .line 118
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 119
    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 120
    new-instance v0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda8;

    invoke-direct {v0, p0, p1}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda8;-><init>(Lru/supportagent/TemplateManagerActivity;Lru/supportagent/Topic;)V

    invoke-virtual {v7, v0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 121
    new-instance v0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda9;

    invoke-direct {v0, p0, p1}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda9;-><init>(Lru/supportagent/TemplateManagerActivity;Lru/supportagent/Topic;)V

    invoke-virtual {v7, v0}, Landroid/widget/LinearLayout;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    return-object v7
.end method

.method private topicDialog(Lru/supportagent/Topic;)V
    .locals 10

    .line 176
    invoke-direct {p0}, Lru/supportagent/TemplateManagerActivity;->dialogBox()Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v1, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u0442\u0435\u043c\u044b"

    .line 177
    invoke-direct {p0, v1}, Lru/supportagent/TemplateManagerActivity;->dialogLabel(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    const/4 v3, -0x1

    const/4 v4, -0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    move-object v2, p0

    .line 178
    invoke-static/range {v2 .. v8}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-nez p1, :cond_0

    const-string v1, ""

    goto :goto_0

    .line 179
    :cond_0
    iget-object v1, p1, Lru/supportagent/Topic;->name:Ljava/lang/String;

    :goto_0
    const/4 v2, 0x0

    invoke-direct {p0, v1, v2}, Lru/supportagent/TemplateManagerActivity;->styledInput(Ljava/lang/String;Z)Landroid/widget/EditText;

    move-result-object v1

    const-string v2, "\u041d\u0430\u043f\u0440\u0438\u043c\u0435\u0440, \u0424\u0440\u0430\u043a\u0446\u0438\u0438"

    .line 180
    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    const/4 v4, -0x1

    const/4 v5, -0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v3, p0

    .line 181
    invoke-static/range {v3 .. v9}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 182
    new-instance v2, Landroidx/appcompat/app/AlertDialog$Builder;

    const v3, 0x7f0e00a2

    invoke-direct {v2, p0, v3}, Landroidx/appcompat/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    if-nez p1, :cond_1

    const-string v3, "\u041d\u043e\u0432\u0430\u044f \u0442\u0435\u043c\u0430"

    goto :goto_1

    :cond_1
    const-string v3, "\u0418\u0437\u043c\u0435\u043d\u0438\u0442\u044c \u0442\u0435\u043c\u0443"

    .line 183
    :goto_1
    invoke-virtual {v2, v3}, Landroidx/appcompat/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v2

    .line 184
    invoke-virtual {v2, v0}, Landroidx/appcompat/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    const-string v2, "\u041e\u0422\u041c\u0415\u041d\u0410"

    const/4 v3, 0x0

    .line 185
    invoke-virtual {v0, v2, v3}, Landroidx/appcompat/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    const-string v2, "\u0421\u041e\u0425\u0420\u0410\u041d\u0418\u0422\u042c"

    .line 186
    invoke-virtual {v0, v2, v3}, Landroidx/appcompat/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    .line 187
    invoke-virtual {v0}, Landroidx/appcompat/app/AlertDialog$Builder;->create()Landroidx/appcompat/app/AlertDialog;

    move-result-object v0

    .line 188
    new-instance v2, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda17;

    invoke-direct {v2, p0, v0, v1, p1}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda17;-><init>(Lru/supportagent/TemplateManagerActivity;Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;Lru/supportagent/Topic;)V

    invoke-virtual {v0, v2}, Landroidx/appcompat/app/AlertDialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 202
    invoke-virtual {v0}, Landroidx/appcompat/app/AlertDialog;->show()V

    return-void
.end method


# virtual methods
.method synthetic lambda$deleteTemplateConfirm$15$ru-supportagent-TemplateManagerActivity(Lru/supportagent/AnswerTemplate;Landroid/content/DialogInterface;I)V
    .locals 0

    .line 298
    iget-object p2, p0, Lru/supportagent/TemplateManagerActivity;->repository:Lru/supportagent/TemplateRepository;

    iget-object p1, p1, Lru/supportagent/AnswerTemplate;->id:Ljava/lang/String;

    invoke-virtual {p2, p1}, Lru/supportagent/TemplateRepository;->deleteTemplate(Ljava/lang/String;)V

    .line 299
    invoke-direct {p0}, Lru/supportagent/TemplateManagerActivity;->refreshOverlay()V

    .line 300
    iget-object p1, p0, Lru/supportagent/TemplateManagerActivity;->activeTopic:Lru/supportagent/Topic;

    if-nez p1, :cond_0

    invoke-direct {p0}, Lru/supportagent/TemplateManagerActivity;->showTopics()V

    goto :goto_0

    :cond_0
    invoke-direct {p0, p1}, Lru/supportagent/TemplateManagerActivity;->showTemplates(Lru/supportagent/Topic;)V

    :goto_0
    return-void
.end method

.method synthetic lambda$deleteTemplateConfirm$16$ru-supportagent-TemplateManagerActivity(Landroidx/appcompat/app/AlertDialog;Landroid/content/DialogInterface;)V
    .locals 0

    .line 303
    invoke-direct {p0, p1}, Lru/supportagent/TemplateManagerActivity;->tintDialog(Landroidx/appcompat/app/AlertDialog;)V

    return-void
.end method

.method synthetic lambda$deleteTopicConfirm$17$ru-supportagent-TemplateManagerActivity(Lru/supportagent/Topic;Landroid/content/DialogInterface;I)V
    .locals 0

    .line 313
    iget-object p2, p0, Lru/supportagent/TemplateManagerActivity;->repository:Lru/supportagent/TemplateRepository;

    invoke-virtual {p2, p1}, Lru/supportagent/TemplateRepository;->deleteTopic(Lru/supportagent/Topic;)V

    .line 314
    invoke-direct {p0}, Lru/supportagent/TemplateManagerActivity;->refreshOverlay()V

    .line 315
    invoke-direct {p0}, Lru/supportagent/TemplateManagerActivity;->showTopics()V

    return-void
.end method

.method synthetic lambda$deleteTopicConfirm$18$ru-supportagent-TemplateManagerActivity(Landroidx/appcompat/app/AlertDialog;Landroid/content/DialogInterface;)V
    .locals 0

    .line 318
    invoke-direct {p0, p1}, Lru/supportagent/TemplateManagerActivity;->tintDialog(Landroidx/appcompat/app/AlertDialog;)V

    return-void
.end method

.method synthetic lambda$newPage$0$ru-supportagent-TemplateManagerActivity(Landroid/view/View;)V
    .locals 0

    .line 73
    invoke-direct {p0}, Lru/supportagent/TemplateManagerActivity;->showTopics()V

    return-void
.end method

.method synthetic lambda$showTemplates$4$ru-supportagent-TemplateManagerActivity(Landroid/view/View;)V
    .locals 0

    const/4 p1, 0x0

    .line 138
    invoke-direct {p0, p1}, Lru/supportagent/TemplateManagerActivity;->templateDialog(Lru/supportagent/AnswerTemplate;)V

    return-void
.end method

.method synthetic lambda$showTopics$1$ru-supportagent-TemplateManagerActivity(Landroid/view/View;)V
    .locals 0

    const/4 p1, 0x0

    .line 98
    invoke-direct {p0, p1}, Lru/supportagent/TemplateManagerActivity;->topicDialog(Lru/supportagent/Topic;)V

    return-void
.end method

.method synthetic lambda$templateCard$5$ru-supportagent-TemplateManagerActivity(Lru/supportagent/AnswerTemplate;Landroid/view/View;)V
    .locals 0

    .line 157
    invoke-direct {p0, p1}, Lru/supportagent/TemplateManagerActivity;->templateDialog(Lru/supportagent/AnswerTemplate;)V

    return-void
.end method

.method synthetic lambda$templateCard$6$ru-supportagent-TemplateManagerActivity(Lru/supportagent/AnswerTemplate;Landroid/view/View;)Z
    .locals 0

    .line 158
    invoke-direct {p0, p1}, Lru/supportagent/TemplateManagerActivity;->deleteTemplateConfirm(Lru/supportagent/AnswerTemplate;)V

    const/4 p1, 0x1

    return p1
.end method

.method synthetic lambda$templateDialog$11$ru-supportagent-TemplateManagerActivity(Landroid/widget/EditText;Landroid/widget/TextView;Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;)V
    .locals 2

    .line 237
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lru/supportagent/ReplyComposer;->length(Ljava/lang/String;)I

    move-result v0

    .line 238
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lru/supportagent/ReplyComposer;->isValid(Ljava/lang/String;)Z

    move-result p1

    .line 239
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " / 120"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    if-eqz p1, :cond_0

    const-string v1, ""

    goto :goto_0

    :cond_0
    const-string v1, " \u2014 \u0438\u0441\u043f\u0440\u0430\u0432\u044c\u0442\u0435 \u0442\u0435\u043a\u0441\u0442"

    :goto_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 240
    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    if-eqz p1, :cond_1

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    goto :goto_1

    :cond_1
    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    :goto_1
    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 p2, -0x1

    .line 241
    invoke-virtual {p3, p2}, Landroidx/appcompat/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object p2

    if-eqz p1, :cond_2

    invoke-virtual {p4}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_2

    const/4 p1, 0x1

    goto :goto_2

    :cond_2
    const/4 p1, 0x0

    :goto_2
    invoke-virtual {p2, p1}, Landroid/widget/Button;->setEnabled(Z)V

    return-void
.end method

.method synthetic lambda$templateDialog$12$ru-supportagent-TemplateManagerActivity(Lru/supportagent/AnswerTemplate;Landroid/widget/EditText;Landroid/widget/EditText;Landroidx/appcompat/app/AlertDialog;Landroid/view/View;)V
    .locals 1

    .line 247
    iget-object p5, p0, Lru/supportagent/TemplateManagerActivity;->repository:Lru/supportagent/TemplateRepository;

    if-nez p1, :cond_0

    const-string p1, ""

    goto :goto_0

    :cond_0
    iget-object p1, p1, Lru/supportagent/AnswerTemplate;->id:Ljava/lang/String;

    :goto_0
    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->activeTopic:Lru/supportagent/Topic;

    iget-object v0, v0, Lru/supportagent/Topic;->id:Ljava/lang/String;

    .line 248
    invoke-virtual {p2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p3

    .line 247
    invoke-virtual {p5, p1, v0, p2, p3}, Lru/supportagent/TemplateRepository;->saveTemplate(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lru/supportagent/AnswerTemplate;

    move-result-object p1

    if-nez p1, :cond_1

    const-string p1, "\u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u0438 \u0434\u043b\u0438\u043d\u0443 \u043e\u0442\u0432\u0435\u0442\u0430"

    const/4 p2, 0x0

    .line 250
    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    .line 253
    :cond_1
    invoke-virtual {p4}, Landroidx/appcompat/app/AlertDialog;->dismiss()V

    .line 254
    invoke-direct {p0}, Lru/supportagent/TemplateManagerActivity;->refreshOverlay()V

    .line 255
    iget-object p1, p0, Lru/supportagent/TemplateManagerActivity;->activeTopic:Lru/supportagent/Topic;

    invoke-direct {p0, p1}, Lru/supportagent/TemplateManagerActivity;->showTemplates(Lru/supportagent/Topic;)V

    return-void
.end method

.method synthetic lambda$templateDialog$13$ru-supportagent-TemplateManagerActivity(Landroidx/appcompat/app/AlertDialog;Lru/supportagent/AnswerTemplate;Landroid/view/View;)V
    .locals 0

    .line 258
    invoke-virtual {p1}, Landroidx/appcompat/app/AlertDialog;->dismiss()V

    .line 259
    invoke-direct {p0, p2}, Lru/supportagent/TemplateManagerActivity;->deleteTemplateConfirm(Lru/supportagent/AnswerTemplate;)V

    return-void
.end method

.method synthetic lambda$templateDialog$14$ru-supportagent-TemplateManagerActivity(Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;Landroid/widget/TextView;Landroid/widget/EditText;Lru/supportagent/AnswerTemplate;Landroid/content/DialogInterface;)V
    .locals 6

    .line 235
    invoke-direct {p0, p1}, Lru/supportagent/TemplateManagerActivity;->tintDialog(Landroidx/appcompat/app/AlertDialog;)V

    .line 236
    new-instance p6, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda2;

    move-object v0, p6

    move-object v1, p0

    move-object v2, p2

    move-object v3, p3

    move-object v4, p1

    move-object v5, p4

    invoke-direct/range {v0 .. v5}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda2;-><init>(Lru/supportagent/TemplateManagerActivity;Landroid/widget/EditText;Landroid/widget/TextView;Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;)V

    .line 243
    new-instance p3, Lru/supportagent/SimpleTextWatcher;

    invoke-direct {p3, p6}, Lru/supportagent/SimpleTextWatcher;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p2, p3}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 244
    new-instance p3, Lru/supportagent/SimpleTextWatcher;

    invoke-direct {p3, p6}, Lru/supportagent/SimpleTextWatcher;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p4, p3}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 245
    invoke-interface {p6}, Ljava/lang/Runnable;->run()V

    const/4 p3, -0x1

    .line 246
    invoke-virtual {p1, p3}, Landroidx/appcompat/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object p3

    new-instance p6, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda3;

    move-object v0, p6

    move-object v2, p5

    move-object v3, p4

    move-object v4, p2

    move-object v5, p1

    invoke-direct/range {v0 .. v5}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda3;-><init>(Lru/supportagent/TemplateManagerActivity;Lru/supportagent/AnswerTemplate;Landroid/widget/EditText;Landroid/widget/EditText;Landroidx/appcompat/app/AlertDialog;)V

    invoke-virtual {p3, p6}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    if-eqz p5, :cond_0

    const/4 p2, -0x3

    .line 257
    invoke-virtual {p1, p2}, Landroidx/appcompat/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object p2

    new-instance p3, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda4;

    invoke-direct {p3, p0, p1, p5}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda4;-><init>(Lru/supportagent/TemplateManagerActivity;Landroidx/appcompat/app/AlertDialog;Lru/supportagent/AnswerTemplate;)V

    invoke-virtual {p2, p3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_0
    return-void
.end method

.method synthetic lambda$topicActions$7$ru-supportagent-TemplateManagerActivity(Lru/supportagent/Topic;Landroid/content/DialogInterface;I)V
    .locals 0

    if-nez p3, :cond_0

    .line 167
    invoke-direct {p0, p1}, Lru/supportagent/TemplateManagerActivity;->topicDialog(Lru/supportagent/Topic;)V

    goto :goto_0

    :cond_0
    invoke-direct {p0, p1}, Lru/supportagent/TemplateManagerActivity;->deleteTopicConfirm(Lru/supportagent/Topic;)V

    :goto_0
    return-void
.end method

.method synthetic lambda$topicActions$8$ru-supportagent-TemplateManagerActivity(Landroidx/appcompat/app/AlertDialog;Landroid/content/DialogInterface;)V
    .locals 0

    .line 171
    invoke-direct {p0, p1}, Lru/supportagent/TemplateManagerActivity;->tintDialog(Landroidx/appcompat/app/AlertDialog;)V

    return-void
.end method

.method synthetic lambda$topicCard$2$ru-supportagent-TemplateManagerActivity(Lru/supportagent/Topic;Landroid/view/View;)V
    .locals 0

    .line 120
    invoke-direct {p0, p1}, Lru/supportagent/TemplateManagerActivity;->showTemplates(Lru/supportagent/Topic;)V

    return-void
.end method

.method synthetic lambda$topicCard$3$ru-supportagent-TemplateManagerActivity(Lru/supportagent/Topic;Landroid/view/View;)Z
    .locals 0

    .line 121
    invoke-direct {p0, p1}, Lru/supportagent/TemplateManagerActivity;->topicActions(Lru/supportagent/Topic;)V

    const/4 p1, 0x1

    return p1
.end method

.method synthetic lambda$topicDialog$10$ru-supportagent-TemplateManagerActivity(Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;Lru/supportagent/Topic;Landroid/content/DialogInterface;)V
    .locals 1

    .line 189
    invoke-direct {p0, p1}, Lru/supportagent/TemplateManagerActivity;->tintDialog(Landroidx/appcompat/app/AlertDialog;)V

    const/4 p4, -0x1

    .line 190
    invoke-virtual {p1, p4}, Landroidx/appcompat/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object p4

    new-instance v0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda7;

    invoke-direct {v0, p0, p2, p3, p1}, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda7;-><init>(Lru/supportagent/TemplateManagerActivity;Landroid/widget/EditText;Lru/supportagent/Topic;Landroidx/appcompat/app/AlertDialog;)V

    invoke-virtual {p4, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method synthetic lambda$topicDialog$9$ru-supportagent-TemplateManagerActivity(Landroid/widget/EditText;Lru/supportagent/Topic;Landroidx/appcompat/app/AlertDialog;Landroid/view/View;)V
    .locals 0

    .line 191
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p4

    invoke-virtual {p4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p4

    invoke-virtual {p4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p4

    invoke-virtual {p4}, Ljava/lang/String;->isEmpty()Z

    move-result p4

    if-eqz p4, :cond_0

    const-string p2, "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435"

    .line 192
    invoke-virtual {p1, p2}, Landroid/widget/EditText;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_0
    if-nez p2, :cond_1

    .line 195
    iget-object p2, p0, Lru/supportagent/TemplateManagerActivity;->repository:Lru/supportagent/TemplateRepository;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Lru/supportagent/TemplateRepository;->addTopic(Ljava/lang/String;)Lru/supportagent/Topic;

    goto :goto_0

    .line 196
    :cond_1
    iget-object p4, p0, Lru/supportagent/TemplateManagerActivity;->repository:Lru/supportagent/TemplateRepository;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p4, p2, p1}, Lru/supportagent/TemplateRepository;->updateTopic(Lru/supportagent/Topic;Ljava/lang/String;)V

    .line 197
    :goto_0
    invoke-virtual {p3}, Landroidx/appcompat/app/AlertDialog;->dismiss()V

    .line 198
    invoke-direct {p0}, Lru/supportagent/TemplateManagerActivity;->refreshOverlay()V

    .line 199
    invoke-direct {p0}, Lru/supportagent/TemplateManagerActivity;->showTopics()V

    return-void
.end method

.method public onBackPressed()V
    .locals 1

    .line 54
    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->activeTopic:Lru/supportagent/Topic;

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lru/supportagent/TemplateManagerActivity;->showTopics()V

    goto :goto_0

    :cond_0
    invoke-super {p0}, Landroidx/appcompat/app/AppCompatActivity;->onBackPressed()V

    :goto_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    .line 29
    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->onCreate(Landroid/os/Bundle;)V

    .line 30
    new-instance p1, Lru/supportagent/TemplateRepository;

    invoke-direct {p1, p0}, Lru/supportagent/TemplateRepository;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lru/supportagent/TemplateManagerActivity;->repository:Lru/supportagent/TemplateRepository;

    .line 31
    new-instance p1, Lru/supportagent/PaletteRepository;

    invoke-direct {p1, p0}, Lru/supportagent/PaletteRepository;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1}, Lru/supportagent/PaletteRepository;->getActive()Lru/supportagent/AgentPalette;

    move-result-object p1

    iput-object p1, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    .line 32
    invoke-virtual {p0}, Lru/supportagent/TemplateManagerActivity;->getWindow()Landroid/view/Window;

    move-result-object p1

    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 33
    invoke-virtual {p0}, Lru/supportagent/TemplateManagerActivity;->getWindow()Landroid/view/Window;

    move-result-object p1

    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 34
    new-instance p1, Landroid/widget/LinearLayout;

    invoke-direct {p1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lru/supportagent/TemplateManagerActivity;->root:Landroid/widget/LinearLayout;

    const/4 v0, 0x1

    .line 35
    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 36
    iget-object p1, p0, Lru/supportagent/TemplateManagerActivity;->root:Landroid/widget/LinearLayout;

    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 37
    iget-object p1, p0, Lru/supportagent/TemplateManagerActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {p0, p1}, Lru/supportagent/TemplateManagerActivity;->setContentView(Landroid/view/View;)V

    .line 38
    invoke-direct {p0}, Lru/supportagent/TemplateManagerActivity;->showTopics()V

    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 43
    invoke-super {p0}, Landroidx/appcompat/app/AppCompatActivity;->onResume()V

    .line 44
    new-instance v0, Lru/supportagent/PaletteRepository;

    invoke-direct {v0, p0}, Lru/supportagent/PaletteRepository;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lru/supportagent/PaletteRepository;->getActive()Lru/supportagent/AgentPalette;

    move-result-object v0

    iput-object v0, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    .line 45
    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->root:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_1

    .line 46
    invoke-virtual {p0}, Lru/supportagent/TemplateManagerActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    iget-object v1, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 47
    invoke-virtual {p0}, Lru/supportagent/TemplateManagerActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    iget-object v1, p0, Lru/supportagent/TemplateManagerActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 48
    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity;->activeTopic:Lru/supportagent/Topic;

    if-nez v0, :cond_0

    invoke-direct {p0}, Lru/supportagent/TemplateManagerActivity;->showTopics()V

    goto :goto_0

    :cond_0
    invoke-direct {p0, v0}, Lru/supportagent/TemplateManagerActivity;->showTemplates(Lru/supportagent/Topic;)V

    :cond_1
    :goto_0
    return-void
.end method
