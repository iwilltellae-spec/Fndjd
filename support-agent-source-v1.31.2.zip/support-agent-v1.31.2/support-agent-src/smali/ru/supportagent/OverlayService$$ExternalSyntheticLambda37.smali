.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:Landroid/widget/LinearLayout;

.field public final synthetic f$2:Lru/supportagent/Topic;

.field public final synthetic f$3:Ljava/util/List;

.field public final synthetic f$4:Ljava/util/List;

.field public final synthetic f$5:[Ljava/lang/String;

.field public final synthetic f$6:Landroid/widget/LinearLayout;

.field public final synthetic f$7:Landroid/widget/ScrollView;

.field public final synthetic f$8:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$0:Lru/supportagent/OverlayService;

    iput-object p2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$1:Landroid/widget/LinearLayout;

    iput-object p3, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$2:Lru/supportagent/Topic;

    iput-object p4, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$3:Ljava/util/List;

    iput-object p5, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$4:Ljava/util/List;

    iput-object p6, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$5:[Ljava/lang/String;

    iput-object p7, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$6:Landroid/widget/LinearLayout;

    iput-object p8, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$7:Landroid/widget/ScrollView;

    iput-object p9, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$8:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 10

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$0:Lru/supportagent/OverlayService;

    iget-object v1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$1:Landroid/widget/LinearLayout;

    iget-object v2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$2:Lru/supportagent/Topic;

    iget-object v3, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$3:Ljava/util/List;

    iget-object v4, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$4:Ljava/util/List;

    iget-object v5, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$5:[Ljava/lang/String;

    iget-object v6, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$6:Landroid/widget/LinearLayout;

    iget-object v7, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$7:Landroid/widget/ScrollView;

    iget-object v8, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;->f$8:Ljava/lang/String;

    move-object v9, p1

    invoke-virtual/range {v0 .. v9}, Lru/supportagent/OverlayService;->lambda$renderSectionOverview$41$ru-supportagent-OverlayService(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;Ljava/lang/String;Landroid/view/View;)V

    return-void
.end method
