.class public final synthetic Lru/supportagent/TemplateRepository$SearchResults-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
