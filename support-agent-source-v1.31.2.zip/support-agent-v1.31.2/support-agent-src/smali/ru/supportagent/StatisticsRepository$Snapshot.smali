.class public final Lru/supportagent/StatisticsRepository$Snapshot;
.super Ljava/lang/Object;
.source "StatisticsRepository.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lru/supportagent/StatisticsRepository;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Snapshot"
.end annotation


# instance fields
.field public final gameActive:Z

.field public final todayAnswers:I

.field public final todayGameMillis:J

.field public final totalAnswers:I


# direct methods
.method private constructor <init>(IIJZ)V
    .locals 0

    .line 135
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 136
    iput p1, p0, Lru/supportagent/StatisticsRepository$Snapshot;->totalAnswers:I

    .line 137
    iput p2, p0, Lru/supportagent/StatisticsRepository$Snapshot;->todayAnswers:I

    .line 138
    iput-wide p3, p0, Lru/supportagent/StatisticsRepository$Snapshot;->todayGameMillis:J

    .line 139
    iput-boolean p5, p0, Lru/supportagent/StatisticsRepository$Snapshot;->gameActive:Z

    return-void
.end method

.method synthetic constructor <init>(IIJZLru/supportagent/StatisticsRepository$Snapshot-IA;)V
    .locals 0

    invoke-direct/range {p0 .. p5}, Lru/supportagent/StatisticsRepository$Snapshot;-><init>(IIJZ)V

    return-void
.end method
