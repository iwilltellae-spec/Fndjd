.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda39;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lru/supportagent/OverlayService$SearchRenderer;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:Landroid/widget/LinearLayout;

.field public final synthetic f$2:Lru/supportagent/Topic;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;Landroid/widget/LinearLayout;Lru/supportagent/Topic;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda39;->f$0:Lru/supportagent/OverlayService;

    iput-object p2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda39;->f$1:Landroid/widget/LinearLayout;

    iput-object p3, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda39;->f$2:Lru/supportagent/Topic;

    return-void
.end method


# virtual methods
.method public final render(Ljava/lang/String;)V
    .locals 3

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda39;->f$0:Lru/supportagent/OverlayService;

    iget-object v1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda39;->f$1:Landroid/widget/LinearLayout;

    iget-object v2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda39;->f$2:Lru/supportagent/Topic;

    invoke-virtual {v0, v1, v2, p1}, Lru/supportagent/OverlayService;->lambda$showTopicSearch$44$ru-supportagent-OverlayService(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/lang/String;)V

    return-void
.end method
