.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda72;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:Lru/supportagent/PaletteRepository;

.field public final synthetic f$2:[I


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;Lru/supportagent/PaletteRepository;[I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda72;->f$0:Lru/supportagent/OverlayService;

    iput-object p2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda72;->f$1:Lru/supportagent/PaletteRepository;

    iput-object p3, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda72;->f$2:[I

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda72;->f$0:Lru/supportagent/OverlayService;

    iget-object v1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda72;->f$1:Lru/supportagent/PaletteRepository;

    iget-object v2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda72;->f$2:[I

    invoke-virtual {v0, v1, v2, p1}, Lru/supportagent/OverlayService;->lambda$showManageThemes$54$ru-supportagent-OverlayService(Lru/supportagent/PaletteRepository;[ILandroid/view/View;)V

    return-void
.end method
