package ru.supportagent;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

/** Small modern hero badge for the first-run / ready screens. */
public final class WelcomeHero {

    private WelcomeHero() {
    }

    public static View create(Context context, int accent, int iconRes) {
        float d = context.getResources().getDisplayMetrics().density;
        int badge = (int) (78.0f * d);
        int icon = (int) (36.0f * d);

        LinearLayout box = new LinearLayout(context);
        box.setGravity(Gravity.CENTER);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor((accent & 0x00FFFFFF) | 0x2E000000);
        bg.setCornerRadius(badge / 2.0f);
        box.setBackground(bg);

        ImageView image = new ImageView(context);
        image.setImageResource(iconRes);
        image.setColorFilter(accent);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        box.addView(image, new LinearLayout.LayoutParams(icon, icon));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(badge, badge);
        lp.setMargins(0, 0, 0, (int) (20.0f * d));
        box.setLayoutParams(lp);
        return box;
    }
}
