package ru.supportagent;

import android.content.Context;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Compact inline control: [pin icon] СДВИГ: N — placed next to the topic title. */
public final class GpsShiftUi {
    private static final int ICON = 0x7f070082;

    private GpsShiftUi() {}

    public static View makeRow(Context c, Runnable onOpen) {
        float d = c.getResources().getDisplayMetrics().density;

        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, (int) (2 * d), (int) (4 * d), (int) (2 * d));

        ImageView icon = new ImageView(c);
        icon.setImageResource(ICON);
        icon.setColorFilter(0xFFFFFFFF);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        row.addView(icon, new LinearLayout.LayoutParams((int) (15 * d), (int) (15 * d)));

        TextView label = new TextView(c);
        label.setText("\u0421\u0414\u0412\u0418\u0413: " + GpsShift.get(c));
        label.setTextColor(0xFFB9C6D6);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.0f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins((int) (6 * d), 0, 0, 0);
        row.addView(label, lp);

        row.setClickable(true);
        row.setOnClickListener(new OpenListener(onOpen));

        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-2, -2);
        rp.setMargins((int) (8 * d), 0, 0, 0);
        row.setLayoutParams(rp);
        return row;
    }

    static final class OpenListener implements View.OnClickListener {
        private final Runnable target;
        OpenListener(Runnable target) { this.target = target; }
        @Override public void onClick(View v) {
            if (target != null) target.run();
        }
    }
}
