# -*- coding: utf-8 -*-
import sys, struct
sys.path.insert(0,'/home/user/patches_v2')
from lib import *
def fhex(x): return '0x%08x' % struct.unpack('<I',struct.pack('<f',x))[0]
p='smali/ru/supportagent/OverlayService.smali'
s=read(p)
m=[x for x in methods(s) if x['name']=='showQuickOverflow'][0]
blk=m['block']
old='''    const/4 v1, -0x2

    invoke-direct {v7, v11, v0, v1}, Lru/supportagent/OverlayService;->showModal(Landroid/view/View;II)V

    return-void
.end method
'''
new='''    const/high16 v1, %s    # 200.0f

    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-direct {v7, v11, v0, v1}, Lru/supportagent/OverlayService;->showModal(Landroid/view/View;II)V

    invoke-direct {v7}, Lru/supportagent/OverlayService;->positionQuickOverflow()V

    return-void
.end method
'''%fhex(200.0)
assert blk.count(old)==1, blk.count(old)
blk=blk.replace(old,new,1)
s=s[:m['c0']]+blk+s[m['c1']:]
write(p,s)
print('OK  popup fixed compact height + reposition (showQuickOverflow only)')

pos='''.method private positionQuickOverflow()V
    .locals 8

    iget-object v0, p0, Lru/supportagent/OverlayService;->quickAnchor:Landroid/view/View;

    if-eqz v0, :pq_exit

    iget-object v1, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    if-eqz v1, :pq_exit

    iget-object v2, p0, Lru/supportagent/OverlayService;->modalParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz v2, :pq_exit

    const/4 v3, 0x2

    new-array v3, v3, [I

    invoke-virtual {v0, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v4, 0x0

    aget v4, v3, v4

    const/4 v5, 0x1

    aget v5, v3, v5

    iget v6, v2, Landroid/view/WindowManager$LayoutParams;->width:I

    sub-int/2addr v4, v6

    const/high16 v6, 0x40c00000    # 6.0f

    invoke-direct {p0, v6}, Lru/supportagent/OverlayService;->od(F)I

    move-result v6

    sub-int/2addr v4, v6

    const/high16 v6, 0x41000000    # 8.0f

    invoke-direct {p0, v6}, Lru/supportagent/OverlayService;->od(F)I

    move-result v7

    const/4 v6, 0x0

    invoke-static {v7, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    sub-int/2addr v5, v7

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v3

    sub-int/2addr v3, v7

    iget v7, v2, Landroid/view/WindowManager$LayoutParams;->height:I

    sub-int/2addr v3, v7

    invoke-static {v3, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    const/4 v7, 0x0

    invoke-static {v7, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    iput v4, v2, Landroid/view/WindowManager$LayoutParams;->x:I

    iput v5, v2, Landroid/view/WindowManager$LayoutParams;->y:I

    :try_start_0
    iget-object v0, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v0, v1, v2}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :pq_exit

    :pq_exit
    return-void
.end method

'''
rep(p,'.method private preparePage(Ljava/lang/String;)V\n',
       pos+'.method private preparePage(Ljava/lang/String;)V\n',
    label='add positionQuickOverflow()')
print('DONE p2b')
