import re, os, sys
SRC='/home/user/src'
def read(p): return open(os.path.join(SRC,p),encoding='utf-8').read()
def write(p,s): open(os.path.join(SRC,p),'w',encoding='utf-8').write(s)
def rep(p,old,new,label=None,count=1):
    s=read(p); n=s.count(old)
    if n!=count:
        print('FAIL',label,'expected',count,'found',n); print(repr(old[:200])); sys.exit(1)
    write(p,s.replace(old,new,count)); print('OK ',label)
