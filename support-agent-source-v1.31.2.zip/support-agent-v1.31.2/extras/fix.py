# -*- coding: utf-8 -*-
import sys
sys.path.insert(0,'/home/user/p6')
from lib import *

p='smali/ru/supportagent/OverlayService.smali'

# --- 1. field: marks that the current modal is the compact quick-overflow window
rep(p,'.field private quickAnchor:Landroid/view/View;\n',
       '.field private quickAnchor:Landroid/view/View;\n\n'
       '.field private quickModal:Z\n',
    'add quickModal flag')

# --- 2. mark it when the quick-overflow window is shown, clear when any modal closes
rep(p,'''    invoke-direct {v7, v11, v0, v1}, Lru/supportagent/OverlayService;->showModal(Landroid/view/View;II)V

    invoke-direct {v7}, Lru/supportagent/OverlayService;->positionQuickOverflow()V
''','''    invoke-direct {v7, v11, v0, v1}, Lru/supportagent/OverlayService;->showModal(Landroid/view/View;II)V

    const/4 v0, 0x1

    iput-boolean v0, v7, Lru/supportagent/OverlayService;->quickModal:Z

    invoke-direct {v7}, Lru/supportagent/OverlayService;->positionQuickOverflow()V
''','showQuickOverflow: set quickModal=1')
rep(p,'''    iput-object v1, p0, Lru/supportagent/OverlayService;->modalParams:Landroid/view/WindowManager$LayoutParams;

    return-void
.end method
''','''    iput-object v1, p0, Lru/supportagent/OverlayService;->modalParams:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x0

    iput-boolean v2, p0, Lru/supportagent/OverlayService;->quickModal:Z

    return-void
.end method
''','closeModal: reset quickModal=0')

# --- 3. while dragging the panel, re-anchor the compact window to its icon
#        instead of re-centring it in the middle of the main panel.
rep(p,'''    .line 2608
    iget-object v0, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    if-eqz v0, :cond_4
''','''    .line 2608
    iget-boolean v0, p0, Lru/supportagent/OverlayService;->quickModal:Z

    if-eqz v0, :qm_normal

    invoke-direct {p0}, Lru/supportagent/OverlayService;->positionQuickOverflow()V

    return-void

    :qm_normal
    iget-object v0, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    if-eqz v0, :cond_4
''','repositionModalOverPanel: keep quick window next to its icon')

# --- 4. version
y='apktool.yml'; t=read(y)
t=t.replace('apkFileName: SUPPORT-AGENT-v1.25.0.apk','apkFileName: SUPPORT-AGENT-v1.26.0.apk')
t=t.replace('  versionCode: 62','  versionCode: 63')
t=t.replace('  versionName: 1.25.0','  versionName: 1.26.0')
write(y,t)
print('OK  version 1.26.0 / 63')
print('DONE p6')
