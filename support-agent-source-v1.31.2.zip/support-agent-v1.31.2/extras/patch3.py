import os, sys
SRC='/home/user/src'
def read(p): return open(os.path.join(SRC,p),encoding='utf-8').read()
def write(p,s): open(os.path.join(SRC,p),'w',encoding='utf-8').write(s)
def rep(p,old,new,label):
    s=read(p); n=s.count(old)
    if n!=1:
        print('FAIL',label,n); sys.exit(1)
    write(p,s.replace(old,new,1)); print('OK ',label)

p='smali/ru/supportagent/OverlayService.smali'
# v5 must be 0 again before the original invoke-direct/range {v0..v6} olp(...) call
rep(p,'''    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 933
''','''    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v5, 0x0

    .line 933
''','showHome restore v5=0')

p='smali/ru/supportagent/MainActivity.smali'
# v1 is the "bold" boolean used by Ui.text() further down in renderReady
rep(p,'''    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 184
''','''    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v1, 0x1

    .line 184
''','renderReady restore v1=1')

p='smali/ru/supportagent/ReplyComposer.smali'
# fix inverted endsWith test and accept the trailing dot of the new reply
rep(p,'''    const-string v2, "\\u043f\\u0440\\u0438\\u044f\\u0442\\u043d\\u043e\\u0439 \\u0438\\u0433\\u0440\\u044b"

    invoke-virtual {v1, v2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :sa_compose_wrap

    return-object v0

    :sa_compose_wrap
''','''    const-string v2, "\\u043f\\u0440\\u0438\\u044f\\u0442\\u043d\\u043e\\u0439 \\u0438\\u0433\\u0440\\u044b"

    invoke-virtual {v1, v2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :sa_compose_ready

    const-string v2, "\\u043f\\u0440\\u0438\\u044f\\u0442\\u043d\\u043e\\u0439 \\u0438\\u0433\\u0440\\u044b."

    invoke-virtual {v1, v2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :sa_compose_wrap

    :sa_compose_ready
    return-object v0

    :sa_compose_wrap
''','compose short-circuit condition')
