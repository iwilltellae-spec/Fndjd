package ru.supportagent;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Полный экспорт/импорт настроек SUPPORT AGENT: все SharedPreferences (каждый
 * файл целиком, через getAll — «ВСЕ без исключения») и все файлы из filesDir
 * (кроме снимков configs/). Формат — ZIP: "m" метаданные, "p/<имя>" префы
 * (DataOutput: ключ + тип + значение), "f/<путь>" файлы (сырые байты).
 */
public final class ConfigStore {
    private static final int FORMAT = 1;

    private ConfigStore() {
    }

    public static byte[] exportBytes(Context c) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ZipOutputStream z = new ZipOutputStream(bos);
        writeMeta(c, z);
        writePrefs(c, z);
        writeFiles(c, z);
        z.finish();
        z.flush();
        return bos.toByteArray();
    }

    public static boolean snapshot(Context c) {
        try {
            File dir = new File(c.getFilesDir(), "configs");
            dir.mkdirs();
            FileOutputStream out = new FileOutputStream(new File(dir, "snapshot.sacfg"));
            out.write(exportBytes(c));
            out.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static void writeMeta(Context c, ZipOutputStream z) throws IOException {
        String ver = "";
        try {
            ver = c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        z.putNextEntry(new ZipEntry("m"));
        DataOutputStream d = new DataOutputStream(z);
        d.writeInt(FORMAT);
        d.writeUTF(c.getPackageName());
        d.writeUTF(ver == null ? "" : ver);
        d.writeLong(System.currentTimeMillis());
        d.flush();
        z.closeEntry();
    }

    private static void writePrefs(Context c, ZipOutputStream z) throws IOException {
        File dir = new File(c.getApplicationInfo().dataDir, "shared_prefs");
        File[] fs = dir.listFiles();
        if (fs == null) {
            return;
        }
        Arrays.sort(fs, new Comparator<File>() {
            public int compare(File a, File b) {
                return a.getName().compareTo(b.getName());
            }
        });
        for (int i = 0; i < fs.length; i++) {
            String n = fs[i].getName();
            if (!n.endsWith(".xml")) {
                continue;
            }
            String name = n.substring(0, n.length() - 4);
            Map<String, ?> all = c.getSharedPreferences(name, 0).getAll();
            z.putNextEntry(new ZipEntry("p/" + name));
            DataOutputStream d = new DataOutputStream(z);
            d.writeInt(all.size());
            for (Map.Entry<String, ?> e : all.entrySet()) {
                Object v = e.getValue();
                d.writeUTF(e.getKey());
                if (v instanceof String) {
                    d.writeByte(0);
                    d.writeUTF((String) v);
                } else if (v instanceof Boolean) {
                    d.writeByte(1);
                    d.writeBoolean(((Boolean) v).booleanValue());
                } else if (v instanceof Integer) {
                    d.writeByte(2);
                    d.writeInt(((Integer) v).intValue());
                } else if (v instanceof Long) {
                    d.writeByte(3);
                    d.writeLong(((Long) v).longValue());
                } else if (v instanceof Float) {
                    d.writeByte(4);
                    d.writeFloat(((Float) v).floatValue());
                } else if (v instanceof Set) {
                    d.writeByte(5);
                    Set<?> s = (Set<?>) v;
                    d.writeInt(s.size());
                    for (Object o : s) {
                        d.writeUTF(String.valueOf(o));
                    }
                } else {
                    d.writeByte(9);
                }
            }
            d.flush();
            z.closeEntry();
        }
    }

    private static void writeFiles(Context c, ZipOutputStream z) throws IOException {
        File root = c.getFilesDir();
        addDir(root, root, z);
    }

    private static void addDir(File root, File dir, ZipOutputStream z) throws IOException {
        File[] fs = dir.listFiles();
        if (fs == null) {
            return;
        }
        for (int i = 0; i < fs.length; i++) {
            File f = fs[i];
            String rel = f.getAbsolutePath().substring(root.getAbsolutePath().length() + 1);
            if (rel.equals("configs") || rel.startsWith("configs/")) {
                continue;
            }
            if (f.isDirectory()) {
                addDir(root, f, z);
                continue;
            }
            z.putNextEntry(new ZipEntry("f/" + rel));
            FileInputStream in = new FileInputStream(f);
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) {
                z.write(buf, 0, r);
            }
            in.close();
            z.closeEntry();
        }
    }

    public static String importConfig(Context c, InputStream src) throws Exception {
        ZipInputStream z = new ZipInputStream(src);
        List<Object[]> prefs = new ArrayList<Object[]>();
        List<Object[]> files = new ArrayList<Object[]>();
        byte[] meta = null;
        byte[] buf = new byte[8192];
        ZipEntry e;
        while ((e = z.getNextEntry()) != null) {
            String n = e.getName();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            int r;
            while ((r = z.read(buf)) > 0) {
                bos.write(buf, 0, r);
            }
            byte[] data = bos.toByteArray();
            if (n.equals("m")) {
                meta = data;
            } else if (n.startsWith("p/") && n.length() > 2) {
                prefs.add(new Object[]{n.substring(2), data});
            } else if (n.startsWith("f/") && n.length() > 2) {
                files.add(new Object[]{n.substring(2), data});
            }
            z.closeEntry();
        }
        z.close();
        if (meta == null) {
            throw new IOException("В файле нет метаданных");
        }
        DataInputStream dm = new DataInputStream(new ByteArrayInputStream(meta));
        int fmt = dm.readInt();
        String pkg = dm.readUTF();
        if (fmt != FORMAT) {
            throw new IOException("Неизвестный формат конфига");
        }
        if (!c.getPackageName().equals(pkg)) {
            throw new IOException("Конфиг от другого приложения");
        }
        int pc = 0;
        int fc = 0;
        for (int i = 0; i < prefs.size(); i++) {
            String name = (String) prefs.get(i)[0];
            DataInputStream d = new DataInputStream(new ByteArrayInputStream((byte[]) prefs.get(i)[1]));
            int count = d.readInt();
            SharedPreferences sp = c.getSharedPreferences(name, 0);
            SharedPreferences.Editor ed = sp.edit();
            ed.clear();
            for (int j = 0; j < count; j++) {
                String k = d.readUTF();
                int t = d.readByte();
                if (t == 0) {
                    ed.putString(k, d.readUTF());
                } else if (t == 1) {
                    ed.putBoolean(k, d.readBoolean());
                } else if (t == 2) {
                    ed.putInt(k, d.readInt());
                } else if (t == 3) {
                    ed.putLong(k, d.readLong());
                } else if (t == 4) {
                    ed.putFloat(k, d.readFloat());
                } else if (t == 5) {
                    int sz = d.readInt();
                    LinkedHashSet<String> set = new LinkedHashSet<String>();
                    for (int q = 0; q < sz; q++) {
                        set.add(d.readUTF());
                    }
                    ed.putStringSet(k, set);
                } else if (t == 9) {
                    // неизвестный тип — пропускаем
                } else {
                    throw new IOException("Повреждённый конфиг");
                }
            }
            ed.commit();
            pc++;
        }
        for (int i = 0; i < files.size(); i++) {
            String rel = (String) files.get(i)[0];
            if (rel.indexOf("..") >= 0 || rel.startsWith("/")) {
                continue;
            }
            File out = new File(c.getFilesDir(), rel);
            File parent = out.getParentFile();
            if (parent != null) {
                parent.mkdirs();
            }
            FileOutputStream fo = new FileOutputStream(out);
            fo.write((byte[]) files.get(i)[1]);
            fo.close();
            fc++;
        }
        return pc + " / " + fc;
    }
}
