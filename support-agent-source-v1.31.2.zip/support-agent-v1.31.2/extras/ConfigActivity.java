package ru.supportagent;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Прозрачный посредник для SAF: выгрузка конфига в файл (CREATE_DOCUMENT),
 * загрузка из файла (OPEN_DOCUMENT), снимок настроек — без SAF.
 * После успешной загрузки уведомляет OverlayService (action CONFIG_IMPORTED).
 */
public class ConfigActivity extends Activity {
    private static final int REQ_EXPORT = 1;
    private static final int REQ_IMPORT = 2;

    private byte[] pendingExport;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String mode = getIntent().getStringExtra("mode");
        if (mode == null) {
            mode = "";
        }
        try {
            if (mode.equals("save")) {
                if (ConfigStore.snapshot(this)) {
                    toast("Снимок настроек сохранён");
                } else {
                    toast("Не удалось сохранить снимок");
                }
                finish();
                return;
            }
            if (mode.equals("export")) {
                pendingExport = ConfigStore.exportBytes(this);
                Intent i = new Intent("android.intent.action.CREATE_DOCUMENT");
                i.addCategory("android.intent.category.OPENABLE");
                i.setType("application/octet-stream");
                String name = "support-agent-" + new SimpleDateFormat("yyyy-MM-dd-HH-mm", Locale.US).format(new Date()) + ".sacfg";
                i.putExtra("android.intent.extra.title", name);
                startActivityForResult(i, REQ_EXPORT);
                return;
            }
            if (mode.equals("import")) {
                Intent i = new Intent("android.intent.action.OPEN_DOCUMENT");
                i.addCategory("android.intent.category.OPENABLE");
                i.setType("*/*");
                startActivityForResult(i, REQ_IMPORT);
                return;
            }
        } catch (Exception e) {
            toast("Ошибка: " + e.getMessage());
        }
        finish();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                ContentResolver cr = getContentResolver();
                if (requestCode == REQ_EXPORT && pendingExport != null) {
                    OutputStream out = cr.openOutputStream(uri);
                    out.write(pendingExport);
                    out.flush();
                    out.close();
                    toast("Конфиг выгружен в файл");
                } else if (requestCode == REQ_IMPORT) {
                    InputStream in = cr.openInputStream(uri);
                    ConfigStore.importConfig(this, in);
                    in.close();
                    toast("Конфиг загружен — все настройки перенесены");
                    Intent s = new Intent(this, OverlayService.class);
                    s.setAction("ru.supportagent.CONFIG_IMPORTED");
                    startService(s);
                }
            }
        } catch (Exception e) {
            toast("Ошибка: " + e.getMessage());
        }
        finish();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
