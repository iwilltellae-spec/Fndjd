# -*- coding: utf-8 -*-
import os, shutil, sys

SRC = '/home/user/src'

def esc(s):
    out = []
    for ch in s:
        if ord(ch) < 128:
            out.append(ch)
        else:
            out.append('\\u%04x' % ord(ch))
    return ''.join(out)

def read(p):
    with open(os.path.join(SRC, p), encoding='utf-8') as f:
        return f.read()

def write(p, s):
    with open(os.path.join(SRC, p), 'w', encoding='utf-8') as f:
        f.write(s)

def rep(p, old, new, count=1, label=None):
    s = read(p)
    n = s.count(old)
    if n != count:
        print('FAIL [%s] expected %d occurrences, found %d' % (label or p, count, n))
        print('OLD:', repr(old[:220]))
        sys.exit(1)
    s = s.replace(old, new, count)
    write(p, s)
    print('OK  [%s] x%d' % (label or p, count))

T4_TITLE = 'Жб на форум'
T4_BODY  = 'Здравствуйте, подайте жалобу на игрока на форуме, прикрепив видеофиксацию с /time // Приятной игры.'
T5_TITLE = 'Нет функции'
T5_BODY  = 'Здравствуйте, данная функция отсутствует на сервере. // Приятной игры'

ADD = 'Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V'

def addseed(title, body):
    return '''    const-string v6, "quick"

    const-string v7, ""

    const-string v8, "%s"

    const-string v9, "%s"

    invoke-direct/range {v4 .. v9}, %s

''' % (esc(title), esc(body), ADD)

# ---------------------------------------------------------------- 1. resources
os.makedirs(os.path.join(SRC, 'res/drawable'), exist_ok=True)
write('res/drawable/ic_quick_reply.xml', '''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24.0dip"
    android:height="24.0dip"
    android:viewportWidth="24.0"
    android:viewportHeight="24.0">
    <path
        android:pathData="M6.8,4.6h10.4a3,3 0,0 1,3 3v6.2a3,3 0,0 1,-3 3h-5.2l-4.2,3.1v-3.1h-0.9a3,3 0,0 1,-3 -3V7.6a3,3 0,0 1,3 -3z"
        android:fillColor="#00000000"
        android:strokeColor="#ffffffff"
        android:strokeWidth="1.7"
        android:strokeLineJoin="round" />
    <path
        android:fillColor="#ffffffff"
        android:pathData="M13.3,6.8l-3.7,5.2h2.3l-0.7,4.4 3.7,-5.3h-2.3z" />
</vector>
''')
print('OK  [ic_quick_reply.xml]')

rep('res/values/public.xml',
    '    <public type="drawable" name="sel_handle_right" id="0x7f070080" />\n',
    '    <public type="drawable" name="sel_handle_right" id="0x7f070080" />\n'
    '    <public type="drawable" name="ic_quick_reply" id="0x7f070081" />\n',
    label='public.xml new drawable id')

rep('smali/ru/supportagent/R$drawable.smali',
    '.field public static final tooltip_frame_light:I = 0x7f07007d\n',
    '.field public static final tooltip_frame_light:I = 0x7f07007d\n\n'
    '.field public static final ic_quick_reply:I = 0x7f070081\n',
    label='R$drawable new field')

# copy generated helper smali
for name in ('KeyboardGuard', 'WelcomeHero'):
    with open('/home/user/work/dec2/smali/ru/supportagent/%s.smali' % name, encoding='utf-8') as f:
        write('smali/ru/supportagent/%s.smali' % name, f.read())
    print('OK  [%s.smali]' % name)

# ---------------------------------------------------------------- 2. manifest
rep('AndroidManifest.xml',
    '<activity android:exported="false" android:name="ru.supportagent.TemplateManagerActivity"/>',
    '<activity android:exported="false" android:name="ru.supportagent.TemplateManagerActivity" android:windowSoftInputMode="adjustResize"/>',
    label='manifest TemplateManagerActivity adjustResize')

# ---------------------------------------------------------------- 3. templates
p = 'smali/ru/supportagent/TemplateRepository.smali'
rep(p, '.field private static final CURRENT_SEED_VERSION:I = 0x3',
       '.field private static final CURRENT_SEED_VERSION:I = 0x4',
       label='CURRENT_SEED_VERSION = 4')

# fresh install: add quick answers 4 and 5 to the initial seed block
old = '''    goto :goto_3

    :cond_4
    move v1, v0
'''
new = '''    %s    %s    goto :goto_3

    :cond_4
    move v1, v0
''' % (addseed(T4_TITLE, T4_BODY), addseed(T5_TITLE, T5_BODY))
rep(p, old, new, label='initial seed: quick answers 4+5')

# upgrade path for existing installs
old = '''    :cond_5
    if-eqz v1, :cond_6
'''
upgrade = '''    :cond_5
    iget-object v0, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {v0, v10, v11}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v5, 0x4

    if-ge v0, v5, :sa_seed_done

    const-string v6, "%s"

    invoke-direct {p0, v3, v6}, Lru/supportagent/TemplateRepository;->hasTemplateTitle(Ljava/util/List;Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :sa_seed_4_skip

    move-object v4, p0

    move-object v5, v3

%s
    const/4 v1, 0x1

    :sa_seed_4_skip
    const-string v6, "%s"

    invoke-direct {p0, v3, v6}, Lru/supportagent/TemplateRepository;->hasTemplateTitle(Ljava/util/List;Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :sa_seed_5_skip

    move-object v4, p0

    move-object v5, v3

%s
    const/4 v1, 0x1

    :sa_seed_5_skip
    :sa_seed_done
    if-eqz v1, :cond_6
''' % (esc(T4_TITLE), addseed(T4_TITLE, T4_BODY), esc(T5_TITLE), addseed(T5_TITLE, T5_BODY))
rep(p, old, upgrade, label='upgrade seed stage (seed_version < 4)')

rep(p, '''    :cond_6
    iget-object v0, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;
''',
'''    :cond_6
    const/4 v4, 0x4

    iget-object v0, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;
''', label='write seed_version = 4')

helper = '''.method private hasTemplateTitle(Ljava/util/List;Ljava/lang/String;)Z
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;",
            "Ljava/lang/String;",
            ")Z"
        }
    .end annotation

    if-eqz p1, :sa_tt_start

    const/4 v0, 0x0

    return v0

    :sa_tt_start
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :sa_tt_loop
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :sa_tt_none

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lru/supportagent/AnswerTemplate;

    iget-object v1, v1, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    if-eqz v1, :sa_tt_loop

    invoke-virtual {v1, p2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :sa_tt_loop

    const/4 v0, 0x1

    return v0

    :sa_tt_none
    const/4 v0, 0x0

    return v0
.end method

'''
rep(p, '.method private hasTopic(Ljava/util/List;Ljava/lang/String;)Z\n',
       helper + '.method private hasTopic(Ljava/util/List;Ljava/lang/String;)Z\n',
    label='hasTemplateTitle helper')

# ---------------------------------------------------------------- 4. composer
p = 'smali/ru/supportagent/ReplyComposer.smali'
rep(p,
    '    const-string v1, "(?iu)\\\\s*//\\\\s*\\u043f\\u0440\\u0438\\u044f\\u0442\\u043d\\u043e\\u0439\\\\s+\\u0438\\u0433\\u0440\\u044b\\\\s*$"',
    '    const-string v1, "(?iu)\\\\s*//\\\\s*\\u043f\\u0440\\u0438\\u044f\\u0442\\u043d\\u043e\\u0439\\\\s+\\u0438\\u0433\\u0440\\u044b\\\\.?\\\\s*$"',
    label='cleanBody accepts trailing dot')

old = '''.method public static compose(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 20
'''
new = '''.method public static compose(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    if-eqz p0, :sa_compose_wrap

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const-string v2, "\\u0437\\u0434\\u0440\\u0430\\u0432\\u0441\\u0442\\u0432\\u0443\\u0439\\u0442\\u0435"

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :sa_compose_wrap

    const-string v2, "\\u043f\\u0440\\u0438\\u044f\\u0442\\u043d\\u043e\\u0439 \\u0438\\u0433\\u0440\\u044b"

    invoke-virtual {v1, v2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :sa_compose_wrap

    return-object v0

    :sa_compose_wrap
    .line 20
'''
rep(p, old, new, label='compose keeps already-formatted replies verbatim')

# ---------------------------------------------------------------- 5. OverlayService
p = 'smali/ru/supportagent/OverlayService.smali'
rep(p, '''    :cond_0
    const/16 v0, 0x320

    :goto_0''', '''    :cond_0
    const/16 v0, 0x120

    :goto_0''', label='focusable overlay flags (no LAYOUT_NO_LIMITS)')

rep(p, '''    if-eqz p3, :cond_1

    const/16 p1, 0x30

    .line 446
    iput p1, v6, Landroid/view/WindowManager$LayoutParams;->softInputMode:I

    :cond_1
    return-object v6''', '''    const/16 p1, 0x10

    iput p1, v6, Landroid/view/WindowManager$LayoutParams;->softInputMode:I

    :cond_1
    return-object v6''', label='softInputMode = ADJUST_RESIZE')

rep(p, '''    invoke-interface {p2, p1, v0}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 p1, 0x0''', '''    invoke-interface {p2, p1, v0}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {p0, p1, v0}, Lru/supportagent/KeyboardGuard;->install(Landroid/content/Context;Landroid/view/View;Landroid/view/WindowManager$LayoutParams;)V

    const/4 p1, 0x0''', label='attachPanel installs KeyboardGuard')

rep(p, '''    :try_start_0
    iget-object v1, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v1, v0}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V''', '''    :try_start_0
    invoke-static {v0}, Lru/supportagent/KeyboardGuard;->release(Landroid/view/View;)V

    iget-object v1, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v1, v0}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V''', label='removePanelOnly releases KeyboardGuard')

# IME flags: NO_EXTRACT_UI | NO_FULLSCREEN
rep(p, '    const/high16 p1, 0x10000000\n', '    const/high16 p1, 0x12000000\n', label='input() multiline imeOptions')
rep(p, '    const p1, 0x10000006\n', '    const p1, 0x12000006\n', label='input() singleline imeOptions')
rep(p, '    const v0, 0x10000006\n', '    const v0, 0x12000006\n', label='secretInput imeOptions')

# home row: adaptive quick-replies icon left of the three dots
old = '''    invoke-direct {v7, v2, v0, v13, v1}, Lru/supportagent/OverlayService;->iconButton(ILjava/lang/String;II)Landroid/widget/ImageView;

    move-result-object v8

    .line 933
'''
icon_home = '''    invoke-direct {v7, v2, v0, v13, v1}, Lru/supportagent/OverlayService;->iconButton(ILjava/lang/String;II)Landroid/widget/ImageView;

    move-result-object v8

    new-instance v5, Landroid/widget/ImageView;

    invoke-direct {v5, v7}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v0, 0x7f070081

    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    sget-object v0, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const-string v0, "\\u0411\\u044b\\u0441\\u0442\\u0440\\u044b\\u0435 \\u043e\\u0442\\u0432\\u0435\\u0442\\u044b"

    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x4

    if-le v0, v1, :sa_q_small

    const/high16 v1, 0x41b00000

    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    goto :sa_q_apply

    :sa_q_small
    const/high16 v1, 0x41800000

    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    :sa_q_apply
    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setColorFilter(I)V

    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v3, 0x40a00000

    invoke-direct {v7, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v2, v4, v4, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v15, v5, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda42;

    invoke-direct {v0, v7, v10}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda42;-><init>(Lru/supportagent/OverlayService;Ljava/util/List;)V

    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 933
'''
rep(p, old, icon_home, label='showHome quick-replies icon next to ⋮')

# overflow header icon
old = '''    .line 1661
    invoke-virtual {v12, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v0, 0x41480000    # 12.5f
'''
icon_overflow = '''    .line 1661
    invoke-virtual {v12, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v13, Landroid/widget/ImageView;

    invoke-direct {v13, v7}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v0, 0x7f070081

    invoke-virtual {v13, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    invoke-virtual {v13, v0}, Landroid/widget/ImageView;->setColorFilter(I)V

    sget-object v0, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v13, v0}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/high16 v0, 0x41900000    # 18.0f

    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v3, 0x40c00000    # 6.0f

    invoke-direct {v7, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v2, v4, v4, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v12, v13, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v0, 0x41480000    # 12.5f
'''
rep(p, old, icon_overflow, label='showQuickOverflow header icon')

# ---------------------------------------------------------------- 6. YandexSearchActivity
rep('smali_classes2/ru/supportagent/YandexSearchActivity.smali',
    '''    const/4 v8, 0x3

    invoke-virtual {v5, v8}, Landroid/widget/EditText;->setImeOptions(I)V''',
    '''    const v8, 0x12000003

    invoke-virtual {v5, v8}, Landroid/widget/EditText;->setImeOptions(I)V''',
    label='YandexSearchActivity imeOptions')

# ---------------------------------------------------------------- 7. MainActivity
p = 'smali/ru/supportagent/MainActivity.smali'

# shorter copy, statistics sentence removed
reps = [
    ('Разрешите показ поверх других приложений — без этого круг не сможет появиться над Black Russia.',
     'Разрешите показ поверх других приложений — это нужно для круга поверх игры.'),
    ('Откройте Black Russia. В горизонтальном режиме панель станет широкой и удобной. Темы редактируются через белую шестерёнку, а статистика открывается значком ! рядом с AGENT.',
     'Откройте Black Russia — помощник уже на экране.'),
    ('Как только разрешён показ поверх других приложений, круг появится сам — повторно включать его в приложении не потребуется.',
     'Круг появится сам — включать его повторно не нужно.'),
    ('ШАГ НАСТРОЙКИ', '01'),
    ('ЧТО БУДЕТ ДАЛЬШЕ', 'ДАЛЬШЕ'),
]
for old, new in reps:
    rep(p, '"%s"' % esc(old), '"%s"' % esc(new), label='text: %s' % new[:36])

# hero badge in renderReady (right after content container is attached)
old = '''    invoke-virtual {v2, v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 184
'''
new = '''    invoke-virtual {v2, v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v1, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    const v2, 0x7f070081

    invoke-static {p0, v1, v2}, Lru/supportagent/WelcomeHero;->create(Landroid/content/Context;II)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 184
'''
rep(p, old, new, label='renderReady hero badge')

# hero badge in renderSetup
old = '''    invoke-virtual {v1, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 134
'''
new = '''    invoke-virtual {v1, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    const v1, 0x7f070081

    invoke-static {p0, v0, v1}, Lru/supportagent/WelcomeHero;->create(Landroid/content/Context;II)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 134
'''
rep(p, old, new, label='renderSetup hero badge')

# softer radius on the hint card (20dp instead of 13dp)
rep(p, '''    invoke-static {v0, v2, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;''',
'''    const/high16 v2, 0x41a00000    # 20.0f

    invoke-static {v0, v2, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;''',
    label='hint card radius 20dp')

print('\nALL PATCHES APPLIED')
