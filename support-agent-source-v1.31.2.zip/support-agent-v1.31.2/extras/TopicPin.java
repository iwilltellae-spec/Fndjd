package ru.supportagent;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;

/** Закрепление тем: до 4 тем вверху списка (новая — всегда первая, пятая выталкивает старую), состояние в prefs support_agent_overlay/pinned_topics. */
public final class TopicPin {
    private static final String PREFS = "support_agent_overlay";
    private static final String KEY = "pinned_topics";
    private static final int MAX = 4;

    private TopicPin() {
    }

    public static List<String> getPinned(Context c) {
        ArrayList<String> out = new ArrayList<String>();
        if (c == null) {
            return out;
        }
        String s = c.getSharedPreferences(PREFS, 0).getString(KEY, "");
        if (s == null) {
            return out;
        }
        String[] parts = s.split(",");
        for (int i = 0; i < parts.length; i++) {
            String t = parts[i].trim();
            if (t.length() > 0 && !out.contains(t)) {
                out.add(t);
            }
        }
        return out;
    }

    private static void save(Context c, List<String> ids) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ids.size(); i++) {
            if (sb.length() > 0) {
                sb.append(',');
            }
            sb.append(ids.get(i));
        }
        c.getSharedPreferences(PREFS, 0).edit().putString(KEY, sb.toString()).commit();
    }

    public static boolean isPinned(Context c, String id) {
        if (id == null) {
            return false;
        }
        return getPinned(c).contains(id);
    }

    /**
     * Закрепить/открепить тему. Новая тема всегда встаёт ПЕРВОЙ; если закреплённых
     * уже MAX — самая старая (последняя в списке) автоматически открепляется.
     * @return 1 — закрепили, 0 — открепили.
     */
    public static int togglePin(Context c, String id) {
        if (c == null || id == null || id.length() == 0) {
            return 0;
        }
        List<String> ids = getPinned(c);
        if (ids.remove(id)) {
            save(c, ids);
            return 0;
        }
        ids.add(0, id);
        while (ids.size() > MAX) {
            ids.remove(ids.size() - 1);
        }
        save(c, ids);
        return 1;
    }

    /** Закреплённые темы — в начало списка (в порядке закрепления), остальные сохраняют порядок. */
    public static void sortTopics(Context c, List<Topic> topics) {
        if (c == null || topics == null) {
            return;
        }
        List<String> ids = getPinned(c);
        if (ids.isEmpty()) {
            return;
        }
        ArrayList<Topic> head = new ArrayList<Topic>();
        for (int i = 0; i < ids.size(); i++) {
            String id = ids.get(i);
            for (int j = 0; j < topics.size(); j++) {
                Topic t = topics.get(j);
                if (t != null && id.equals(t.id)) {
                    head.add(t);
                    break;
                }
            }
        }
        if (head.isEmpty()) {
            return;
        }
        ArrayList<Topic> rest = new ArrayList<Topic>();
        for (int i = 0; i < topics.size(); i++) {
            Topic t = topics.get(i);
            if (t != null && !head.contains(t)) {
                rest.add(t);
            }
        }
        topics.clear();
        topics.addAll(head);
        topics.addAll(rest);
    }
}
