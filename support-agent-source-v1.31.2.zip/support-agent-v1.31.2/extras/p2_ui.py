# -*- coding: utf-8 -*-
import sys, re, struct
sys.path.insert(0,'/home/user/patches_v2')
from lib import *

def fhex(x):
    return '0x%08x' % struct.unpack('<I',struct.pack('<f',x))[0]

p='smali/ru/supportagent/OverlayService.smali'
s=read(p)

# --- tiny leftovers from the Gemini cleanup -------------------------------
s=s.replace('"Lru/supportagent/SaAiClient$Message;"','"Ljava/lang/Object;"')
s=s.replace('const-string v0, "\\u041d\\u0435 \\u0443\\u0434\\u0430\\u043b\\u043e\\u0441\\u044c \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0437\\u0430\\u0449\\u0438\\u0449\\u0451\\u043d\\u043d\\u043e\\u0435 \\u0445\\u0440\\u0430\\u043d\\u0438\\u043b\\u0438\\u0449\\u0435 \\u043a\\u043b\\u044e\\u0447\\u0430."','const-string v0, ""')
write(p,s)
print('OK  leftover Gemini annotation/error string cleaned')

# --- new field: anchor for the quick overflow popup -----------------------
rep(p,'.field private panelParams:Landroid/view/WindowManager$LayoutParams;\n',
       '.field private panelParams:Landroid/view/WindowManager$LayoutParams;\n\n'
       '.field private quickAnchor:Landroid/view/View;\n',
    label='add quickAnchor field')

# --- rewrite the quick answers row ---------------------------------------
s=read(p)
a=s.index('    .line 926\n    new-instance v15, Landroid/widget/LinearLayout;')
b=s.index('    .line 938\n',a)
desc=esc('Открыть меню быстрых ответов')
new='''    .line 926
    new-instance v15, Landroid/widget/LinearLayout;

    invoke-direct {v15, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v6, 0x10

    .line 927
    invoke-virtual {v15, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v0, Landroid/view/View;

    invoke-direct {v0, v7}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, 0x0

    invoke-direct {v1, v2, v2, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v15, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v0, 0x41180000    # 9.5f

    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const/4 v2, 0x1

    invoke-static {v7, v8, v0, v1, v2}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    const v1, 0x3d23d70a    # 0.04f

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setLetterSpacing(F)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    const/4 v3, 0x0

    invoke-direct {v1, v2, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v15, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " / "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->chip(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v0, "%s"

    const/16 v1, 0x5

    const v2, 0x7f070081

    .line 932
    invoke-direct {v7, v2, v0, v13, v1}, Lru/supportagent/OverlayService;->iconButton(ILjava/lang/String;II)Landroid/widget/ImageView;

    move-result-object v8

    iput-object v8, v7, Lru/supportagent/OverlayService;->quickAnchor:Landroid/view/View;

    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda42;

    invoke-direct {v0, v7, v10}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda42;-><init>(Lru/supportagent/OverlayService;Ljava/util/List;)V

    invoke-virtual {v8, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v1, 0x1b

    const/16 v2, 0x1b

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    move v11, v6

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 934
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v15, v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v6, 0x4

    move-object/from16 v0, p0

    .line 935
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v9, v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

''' % desc
s=s[:a]+new+s[b:]
write(p,s)
print('OK  quick answers row: no three dots, white icon, text grouped next to it')

# --- popup header icon: white and closer to the title ---------------------
rep(p,'''    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    invoke-virtual {v13, v0}, Landroid/widget/ImageView;->setColorFilter(I)V
''','''    const/4 v0, -0x1

    invoke-virtual {v13, v0}, Landroid/widget/ImageView;->setColorFilter(I)V
''',label='popup header icon white')
rep(p,'''    const/high16 v3, 0x40c00000    # 6.0f

    invoke-direct {v7, v3}, Lru/supportagent/OverlayService;->od(F)I
''','''    const/high16 v3, 0x40400000    # 3.0f

    invoke-direct {v7, v3}, Lru/supportagent/OverlayService;->od(F)I
''',label='popup header icon/text gap 3dp')

# --- compact popup -------------------------------------------------------
rep(p,'''    const/high16 v0, 0x43a50000    # 330.0f

    goto :goto_8

    :cond_a
    const/high16 v0, 0x43b40000    # 360.0f
''','''    const/high16 v0, %s    # 220.0f

    goto :goto_8

    :cond_a
    const/high16 v0, %s    # 236.0f
'''%(fhex(220.0),fhex(236.0)),label='popup width 220/236dp')

rep(p,'''    const/4 v1, -0x2

    invoke-direct {v7, v11, v0, v1}, Lru/supportagent/OverlayService;->showModal(Landroid/view/View;II)V

    return-void
.end method
''','''    const/high16 v1, %s    # 200.0f

    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-direct {v7, v11, v0, v1}, Lru/supportagent/OverlayService;->showModal(Landroid/view/View;II)V

    invoke-direct {v7}, Lru/supportagent/OverlayService;->positionQuickOverflow()V

    return-void
.end method
'''%fhex(200.0),label='popup fixed compact height + reposition')

# --- new method: place popup to the LEFT of the icon ----------------------
pos='''.method private positionQuickOverflow()V
    .locals 8

    iget-object v0, p0, Lru/supportagent/OverlayService;->quickAnchor:Landroid/view/View;

    if-eqz v0, :pq_exit

    iget-object v1, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    if-eqz v1, :pq_exit

    iget-object v2, p0, Lru/supportagent/OverlayService;->modalParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz v2, :pq_exit

    const/4 v3, 0x2

    new-array v3, v3, [I

    invoke-virtual {v0, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v4, 0x0

    aget v4, v3, v4

    const/4 v5, 0x1

    aget v5, v3, v5

    iget v6, v2, Landroid/view/WindowManager$LayoutParams;->width:I

    sub-int/2addr v4, v6

    const/high16 v6, 0x40c00000    # 6.0f

    invoke-direct {p0, v6}, Lru/supportagent/OverlayService;->od(F)I

    move-result v6

    sub-int/2addr v4, v6

    const/high16 v6, 0x41000000    # 8.0f

    invoke-direct {p0, v6}, Lru/supportagent/OverlayService;->od(F)I

    move-result v7

    const/4 v6, 0x0

    invoke-static {v7, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    sub-int/2addr v5, v7

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v3

    sub-int/2addr v3, v7

    iget v7, v2, Landroid/view/WindowManager$LayoutParams;->height:I

    sub-int/2addr v3, v7

    invoke-static {v3, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    const/4 v7, 0x0

    invoke-static {v7, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    iput v4, v2, Landroid/view/WindowManager$LayoutParams;->x:I

    iput v5, v2, Landroid/view/WindowManager$LayoutParams;->y:I

    :try_start_0
    iget-object v0, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v0, v1, v2}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :pq_exit

    :pq_exit
    return-void
.end method

'''
rep(p,'.method private preparePage(Ljava/lang/String;)V\n',
       pos+'.method private preparePage(Ljava/lang/String;)V\n',
    label='add positionQuickOverflow()')
print('\nDONE p2_ui')
