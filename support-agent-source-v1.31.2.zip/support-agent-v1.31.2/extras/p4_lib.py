import re, os, sys
SRC='/home/user/src'
def esc(s): return ''.join(ch if ord(ch)<128 else '\\u%04x'%ord(ch) for ch in s)
def read(p): return open(os.path.join(SRC,p),encoding='utf-8').read()
def write(p,s): open(os.path.join(SRC,p),'w',encoding='utf-8').write(s)
def rep(p,old,new,label=None,count=1):
    s=read(p); n=s.count(old)
    if n!=count:
        print('FAIL',label,'expected',count,'found',n); print(repr(old[:180])); sys.exit(1)
    write(p,s.replace(old,new,count)); print('OK ',label)
def methods(text):
    out=[]
    for m in re.finditer(r'(?ms)^\.method ([^\n]+)\n.*?^\.end method\n',text):
        sig=m.group(1).strip(); nm=sig.split('(')[0].split()[-1].strip()
        out.append({'c0':m.start(),'c1':m.end(),'name':nm,'sig':sig,'block':m.group(0)})
    return out
def replace_method(text,name,newblock,label=None):
    ms=[m for m in methods(text) if m['name']==name]
    if len(ms)!=1: print('FAIL method',name,len(ms)); sys.exit(1)
    m=ms[0]
    if not newblock.endswith('\n'): newblock+='\n'
    print('OK ',label or name)
    return text[:m['c0']]+newblock+text[m['c1']:]
