package ru.supportagent;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;

/** История поиска: последние 5 запросов, prefs support_agent_overlay/search_history. */
public final class SearchHistory {
    private static final String PREFS = "support_agent_overlay";
    private static final String KEY = "search_history";
    private static final int MAX = 5;

    private SearchHistory() {
    }

    public static List<String> get(Context c) {
        ArrayList<String> out = new ArrayList<String>();
        if (c == null) {
            return out;
        }
        String s = c.getSharedPreferences(PREFS, 0).getString(KEY, "");
        if (s == null) {
            return out;
        }
        String[] parts = s.split("\n");
        for (int i = 0; i < parts.length; i++) {
            String t = parts[i].trim();
            if (t.length() > 0 && !out.contains(t)) {
                out.add(t);
            }
        }
        return out;
    }

    private static void save(Context c, List<String> items) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < items.size(); i++) {
            if (sb.length() > 0) {
                sb.append('\n');
            }
            sb.append(items.get(i));
        }
        c.getSharedPreferences(PREFS, 0).edit().putString(KEY, sb.toString()).commit();
    }

    public static void add(Context c, String q) {
        if (c == null || q == null) {
            return;
        }
        q = q.trim();
        if (q.length() < 2) {
            return;
        }
        if (q.length() > 64) {
            q = q.substring(0, 64);
        }
        List<String> items = get(c);
        items.remove(q);
        items.add(0, q);
        while (items.size() > MAX) {
            items.remove(items.size() - 1);
        }
        save(c, items);
    }

    public static void remove(Context c, String q) {
        if (c == null || q == null) {
            return;
        }
        List<String> items = get(c);
        if (items.remove(q.trim())) {
            save(c, items);
        }
    }
}
