package ru.supportagent;

import android.content.Context;
import android.content.SharedPreferences;

/** Manual shift of the FIRST number in every /gps answer. Range 0..10. */
public final class GpsShift {
    private static final String PREFS = "support_agent_overlay";
    private static final String KEY = "gps_event_shift";
    private static int offset = 0;
    private static Context app;

    private GpsShift() {}

    public static void init(Context c) {
        if (c == null) return;
        try {
            app = c.getApplicationContext();
            offset = app.getSharedPreferences(PREFS, 0).getInt(KEY, 0);
            if (offset < 0 || offset > 10) offset = 0;
        } catch (Throwable t) {
            offset = 0;
        }
    }

    public static int get(Context c) {
        if (app == null) init(c);
        return offset;
    }

    public static void set(Context c, int value) {
        if (app == null) init(c);
        offset = value < 0 ? 0 : (value > 10 ? 10 : value);
        try {
            SharedPreferences p = app.getSharedPreferences(PREFS, 0);
            p.edit().putInt(KEY, offset).commit();
        } catch (Throwable ignored) {
        }
    }

    /** "/gps - 1 - 3 = X" with shift 2 -> "/gps - 3 - 3 = X". */
    public static String apply(String body) {
        if (body == null || offset <= 0) return body;
        try {
            int g = body.indexOf("/gps");
            if (g < 0) return body;
            int i = g + 4;
            int n = body.length();
            while (i < n && !Character.isDigit(body.charAt(i))) i++;
            if (i >= n) return body;
            int j = i;
            while (j < n && Character.isDigit(body.charAt(j))) j++;
            int num = Integer.parseInt(body.substring(i, j));
            return body.substring(0, i) + (num + offset) + body.substring(j);
        } catch (Throwable t) {
            return body;
        }
    }
}
