# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0,'/home/user/p4')
from lib import *

T4=esc('Жб на форум'); T5=esc('Нет функции')
B4=esc('Здравствуйте, подайте жалобу на игрока на форуме, прикрепив видеофиксацию с /time // Приятной игры.')
B5=esc('Здравствуйте, данная функция отсутствует на сервере. // Приятной игры')
ADD='Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V'

# ======================================================= A. SEEDED ANSWERS
p='smali/ru/supportagent/TemplateRepository.smali'
s=read(p)
# 1) fresh install: drop the auto-seeded 5th answer
cut=s.index('.method private normalizeQuickSeeds')
title='    const-string v8, "%s"\n'%T5
i=s.index(title,0,cut)
line_start=s.rfind('const-string v6, "quick"',0,i)
line_start=s.rfind('\n',0,line_start)+1
end=s.index('invoke-direct/range {v4 .. v9}, %s'%ADD,i)
end=s.index('\n',end)+1
removed=s[line_start:end]
assert T5 in removed and B5 in removed
s=s[:line_start]+s[end:]
write(p,s)
print('OK  fresh-install seed: removed auto 5th answer (%d chars)'%len(removed))

# 2) versions 5 -> 6
rep(p,'.field private static final CURRENT_SEED_VERSION:I = 0x5',
       '.field private static final CURRENT_SEED_VERSION:I = 0x6','CURRENT_SEED_VERSION = 6')
rep(p,'''    :cond_5
    iget-object v0, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {v0, v10, v11}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v5, 0x5

    if-ge v0, v5, :sa_seed_done
''','''    :cond_5
    iget-object v0, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {v0, v10, v11}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v5, 0x6

    if-ge v0, v5, :sa_seed_done
''','upgrade stage seed_version < 6')
rep(p,'''    :cond_6
    const/4 v4, 0x5
''','''    :cond_6
    const/4 v4, 0x6
''','write seed_version = 6')

# 3) rewrite the normaliser: fix inverted condition, keep ONE 4th answer only
normal='''.method private normalizeQuickSeeds(Ljava/util/List;)Z
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;",
            ")Z"
        }
    .end annotation

    const/4 v0, 0x0

    if-eqz p1, :nq_add

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :nq_loop
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :nq_add

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/AnswerTemplate;

    iget-object v3, v2, Lru/supportagent/AnswerTemplate;->topicId:Ljava/lang/String;

    const-string v4, "quick"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :nq_loop

    iget-object v3, v2, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    if-eqz v3, :nq_loop

    const-string v4, "%s"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :nq_check5

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    const/4 v0, 0x1

    goto :nq_loop

    :nq_check5
    const-string v4, "%s"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :nq_loop

    iget-object v5, v2, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    const-string v6, "%s"

    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :nq_loop

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    const/4 v0, 0x1

    goto :nq_loop

    :nq_add
    move-object v4, p0

    move-object v5, p1

    const-string v6, "quick"

    const-string v7, ""

    const-string v8, "%s"

    const-string v9, "%s"

    invoke-direct/range {v4 .. v9}, %s

    const/4 v0, 0x1

    return v0
.end method
'''%(T4,T5,B5,T4,B4,ADD)
s=replace_method(read(p),'normalizeQuickSeeds',normal,'normalizeQuickSeeds: keep exactly one 4th answer, remove seeded 5th')
write(p,s)

# ======================================================= B. INPUT -> ORIGINAL
p='smali/ru/supportagent/OverlayService.smali'
rep(p,'''    :cond_0
    const/16 v0, 0x120

    :goto_0
''','''    :cond_0
    const/16 v0, 0x320

    :goto_0
''','overlay flags back to original 0x320')
rep(p,'''    const/16 p1, 0x30

    iput p1, v6, Landroid/view/WindowManager$LayoutParams;->softInputMode:I

    :cond_1
    return-object v6
''','''    if-eqz p3, :cond_1

    const/16 p1, 0x30

    .line 446
    iput p1, v6, Landroid/view/WindowManager$LayoutParams;->softInputMode:I

    :cond_1
    return-object v6
''','softInputMode only for focusable panels, 0x30')
rep(p,'    const/high16 p1, 0x12000000\n','    const/high16 p1, 0x10000000\n','input() multiline imeOptions original')
rep(p,'    const p1, 0x12000006\n','    const p1, 0x10000006\n','input() singleline imeOptions original')
rep(p,'    const v0, 0x12000006\n','    const v0, 0x10000006\n','secretInput imeOptions original')
rep(p,'''    .line 867
    :cond_0
    invoke-static {v0, p1}, Lru/supportagent/KeyboardFit;->fit(Landroid/view/View;Landroid/widget/EditText;)V

    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda0;
''','''    .line 867
    :cond_0
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda0;
''','focusInput: remove KeyboardFit')
rep(p,'''    .line 877
    iget-object v0, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    invoke-static {v0}, Lru/supportagent/KeyboardFit;->reset(Landroid/view/View;)V

    if-eqz v0, :cond_1
''','''    .line 877
    iget-object v0, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    if-eqz v0, :cond_1
''','hideKeyboard: remove KeyboardFit')

rep('smali_classes2/ru/supportagent/YandexSearchActivity.smali',
    '''    const v8, 0x12000003

    invoke-virtual {v5, v8}, Landroid/widget/EditText;->setImeOptions(I)V''',
    '''    const/4 v8, 0x3

    invoke-virtual {v5, v8}, Landroid/widget/EditText;->setImeOptions(I)V''',
    'YandexSearchActivity imeOptions original')
rep('AndroidManifest.xml',
    '<activity android:exported="false" android:name="ru.supportagent.TemplateManagerActivity" android:windowSoftInputMode="adjustResize"/>',
    '<activity android:exported="false" android:name="ru.supportagent.TemplateManagerActivity"/>',
    'manifest: remove adjustResize')

# ======================================================= C. POPUP NOT BELOW PANEL
pos='''.method private positionQuickOverflow()V
    .locals 10

    iget-object v0, p0, Lru/supportagent/OverlayService;->quickAnchor:Landroid/view/View;

    if-eqz v0, :pq_exit

    iget-object v1, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    if-eqz v1, :pq_exit

    iget-object v2, p0, Lru/supportagent/OverlayService;->modalParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz v2, :pq_exit

    const/4 v3, 0x2

    new-array v3, v3, [I

    invoke-virtual {v0, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v4, 0x0

    aget v4, v3, v4

    const/4 v5, 0x1

    aget v5, v3, v5

    const/high16 v6, 0x41000000    # 8.0f

    invoke-direct {p0, v6}, Lru/supportagent/OverlayService;->od(F)I

    move-result v8

    iget v6, v2, Landroid/view/WindowManager$LayoutParams;->width:I

    sub-int/2addr v4, v6

    const/high16 v6, 0x40c00000    # 6.0f

    invoke-direct {p0, v6}, Lru/supportagent/OverlayService;->od(F)I

    move-result v6

    sub-int/2addr v4, v6

    invoke-static {v8, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    sub-int/2addr v5, v8

    iget v6, v2, Landroid/view/WindowManager$LayoutParams;->height:I

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v3

    sub-int/2addr v3, v8

    sub-int/2addr v3, v6

    iget-object v9, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz v9, :pq_panel_done

    iget v7, v9, Landroid/view/WindowManager$LayoutParams;->y:I

    iget v9, v9, Landroid/view/WindowManager$LayoutParams;->height:I

    add-int/2addr v7, v9

    sub-int/2addr v7, v8

    sub-int/2addr v7, v6

    if-le v3, v7, :pq_panel_done

    move v3, v9

    :pq_panel_done
    invoke-static {v3, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    const/4 v7, 0x0

    invoke-static {v7, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    iput v4, v2, Landroid/view/WindowManager$LayoutParams;->x:I

    iput v5, v2, Landroid/view/WindowManager$LayoutParams;->y:I

    :try_start_0
    iget-object v0, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v0, v1, v2}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :pq_exit

    :pq_exit
    return-void
.end method
'''
s=replace_method(read(p),'positionQuickOverflow',pos,'positionQuickOverflow: keep popup bottom above panel bottom')
write(p,s)

# ======================================================= D. VERSION
y='apktool.yml'; t=read(y)
t=t.replace('apkFileName: SUPPORT-AGENT-v1.23.0.apk','apkFileName: SUPPORT-AGENT-v1.24.0.apk')
t=t.replace('  versionCode: 60','  versionCode: 61')
t=t.replace('  versionName: 1.23.0','  versionName: 1.24.0')
write(y,t)
print('OK  version 1.24.0 / 61')

# delete the now-unused helper
f=os.path.join(SRC,'smali/ru/supportagent/KeyboardFit.smali')
if os.path.exists(f): os.remove(f); print('OK  deleted KeyboardFit.smali')
print('\nKeyboardFit refs:',read(p).count('KeyboardFit'))
