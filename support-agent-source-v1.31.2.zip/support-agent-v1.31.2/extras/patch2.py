# -*- coding: utf-8 -*-
import os, sys
SRC='/home/user/src'
def esc(s):
    return ''.join(ch if ord(ch)<128 else '\\u%04x'%ord(ch) for ch in s)
def read(p):
    return open(os.path.join(SRC,p),encoding='utf-8').read()
def write(p,s):
    open(os.path.join(SRC,p),'w',encoding='utf-8').write(s)
def rep(p,old,new,count=1,label=None):
    s=read(p); n=s.count(old)
    if n!=count:
        print('FAIL [%s] expected %d found %d'%(label or p,count,n)); print('OLD:',repr(old[:250])); sys.exit(1)
    write(p,s.replace(old,new,count)); print('OK  [%s] x%d'%(label or p,count))

p='smali/ru/supportagent/OverlayService.smali'

# removePanelOnly only (anchored by method header)
old='''.method private removePanelOnly()V
    .locals 2

    .line 505
    iget-object v0, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    if-eqz v0, :cond_0

    .line 506
    :try_start_0
    iget-object v1, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;
'''
new='''.method private removePanelOnly()V
    .locals 2

    .line 505
    iget-object v0, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    if-eqz v0, :cond_0

    .line 506
    :try_start_0
    invoke-static {v0}, Lru/supportagent/KeyboardGuard;->release(Landroid/view/View;)V

    iget-object v1, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;
'''
rep(p,old,new,label='removePanelOnly releases KeyboardGuard')

# IME flags
rep(p,'    const/high16 p1, 0x10000000\n','    const/high16 p1, 0x12000000\n',label='input() multiline imeOptions')
rep(p,'    const p1, 0x10000006\n','    const p1, 0x12000006\n',label='input() singleline imeOptions')
rep(p,'    const v0, 0x10000006\n','    const v0, 0x12000006\n',label='secretInput imeOptions')

old='''    invoke-direct {v7, v2, v0, v13, v1}, Lru/supportagent/OverlayService;->iconButton(ILjava/lang/String;II)Landroid/widget/ImageView;

    move-result-object v8

    .line 933
'''
icon_home='''    invoke-direct {v7, v2, v0, v13, v1}, Lru/supportagent/OverlayService;->iconButton(ILjava/lang/String;II)Landroid/widget/ImageView;

    move-result-object v8

    new-instance v5, Landroid/widget/ImageView;

    invoke-direct {v5, v7}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v0, 0x7f070081

    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    sget-object v0, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const-string v0, "\\u0411\\u044b\\u0441\\u0442\\u0440\\u044b\\u0435 \\u043e\\u0442\\u0432\\u0435\\u0442\\u044b"

    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x4

    if-le v0, v1, :sa_q_small

    const/high16 v1, 0x41b00000

    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    goto :sa_q_apply

    :sa_q_small
    const/high16 v1, 0x41800000

    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    :sa_q_apply
    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setColorFilter(I)V

    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v3, 0x40a00000

    invoke-direct {v7, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v2, v4, v4, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v15, v5, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda42;

    invoke-direct {v0, v7, v10}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda42;-><init>(Lru/supportagent/OverlayService;Ljava/util/List;)V

    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 933
'''
rep(p,old,icon_home,label='showHome quick-replies icon next to the three dots')

old='''    .line 1661
    invoke-virtual {v12, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v0, 0x41480000    # 12.5f
'''
icon_overflow='''    .line 1661
    invoke-virtual {v12, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v13, Landroid/widget/ImageView;

    invoke-direct {v13, v7}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v0, 0x7f070081

    invoke-virtual {v13, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    invoke-virtual {v13, v0}, Landroid/widget/ImageView;->setColorFilter(I)V

    sget-object v0, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v13, v0}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/high16 v0, 0x41900000    # 18.0f

    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v3, 0x40c00000    # 6.0f

    invoke-direct {v7, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v2, v4, v4, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v12, v13, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v0, 0x41480000    # 12.5f
'''
rep(p,old,icon_overflow,label='showQuickOverflow header icon')

rep('smali_classes2/ru/supportagent/YandexSearchActivity.smali',
'''    const/4 v8, 0x3

    invoke-virtual {v5, v8}, Landroid/widget/EditText;->setImeOptions(I)V''',
'''    const v8, 0x12000003

    invoke-virtual {v5, v8}, Landroid/widget/EditText;->setImeOptions(I)V''',
 label='YandexSearchActivity imeOptions')

p='smali/ru/supportagent/MainActivity.smali'
reps=[
 ('Разрешите показ поверх других приложений — без этого круг не сможет появиться над Black Russia.',
  'Разрешите показ поверх других приложений — это нужно для круга поверх игры.'),
 ('Откройте Black Russia. В горизонтальном режиме панель станет широкой и удобной. Темы редактируются через белую шестерёнку, а статистика открывается значком ! рядом с AGENT.',
  'Откройте Black Russia — помощник уже на экране.'),
 ('Как только разрешён показ поверх других приложений, круг появится сам — повторно включать его в приложении не потребуется.',
  'Круг появится сам — включать его повторно не нужно.'),
 ('ШАГ НАСТРОЙКИ','01'),
 ('ЧТО БУДЕТ ДАЛЬШЕ','ДАЛЬШЕ'),
]
for old,new in reps:
    rep(p,'"%s"'%esc(old),'"%s"'%esc(new),label='text -> %s'%new[:34])

old='''    invoke-virtual {v2, v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 184
'''
new='''    invoke-virtual {v2, v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v1, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    const v2, 0x7f070081

    invoke-static {p0, v1, v2}, Lru/supportagent/WelcomeHero;->create(Landroid/content/Context;II)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 184
'''
rep(p,old,new,label='renderReady hero badge')

old='''    invoke-virtual {v1, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 134
'''
new='''    invoke-virtual {v1, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    const v1, 0x7f070081

    invoke-static {p0, v0, v1}, Lru/supportagent/WelcomeHero;->create(Landroid/content/Context;II)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 134
'''
rep(p,old,new,label='renderSetup hero badge')

rep(p,'''    invoke-static {v0, v2, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;''',
'''    const/high16 v2, 0x41a00000    # 20.0f

    invoke-static {v0, v2, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;''',
 label='hint card radius 20dp')

print('\nALL REMAINING PATCHES APPLIED')
