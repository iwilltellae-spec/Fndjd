# -*- coding: utf-8 -*-
import sys, os, re, glob
sys.path.insert(0,'/home/user/patches_v2')
from lib import *

# ===================== 1. DEDUPE (TemplateRepository) =====================
p='smali/ru/supportagent/TemplateRepository.smali'
s=read(p)
s=s.replace('.field private static final CURRENT_SEED_VERSION:I = 0x4',
            '.field private static final CURRENT_SEED_VERSION:I = 0x5')
start=s.index('    :cond_5\n    iget-object v0, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;')
end=s.index('    if-eqz v1, :cond_6', start)
stage='''    :cond_5
    iget-object v0, p0, Lru/supportagent/TemplateRepository;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {v0, v10, v11}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v5, 0x5

    if-ge v0, v5, :sa_seed_done

    invoke-direct {p0, v3}, Lru/supportagent/TemplateRepository;->normalizeQuickSeeds(Ljava/util/List;)Z

    move-result v0

    or-int/2addr v1, v0

    :sa_seed_done
'''
s=s[:start]+stage+s[end:]
s=s.replace('''    :cond_6
    const/4 v4, 0x4
''','''    :cond_6
    const/4 v4, 0x5
''',1)
ms=[m for m in methods(s) if m['name']=='hasTemplateTitle']
assert len(ms)==1, len(ms)
m=ms[0]
normal='''.method private normalizeQuickSeeds(Ljava/util/List;)Z
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;",
            ")Z"
        }
    .end annotation

    const/4 v0, 0x0

    if-eqz p1, :nq_add

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :nq_loop
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :nq_add

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/AnswerTemplate;

    iget-object v3, v2, Lru/supportagent/AnswerTemplate;->topicId:Ljava/lang/String;

    const-string v4, "quick"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :nq_loop

    iget-object v3, v2, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    if-eqz v3, :nq_loop

    const-string v4, "\\u0416\\u0431 \\u043d\\u0430 \\u0444\\u043e\\u0440\\u0443\\u043c"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :nq_check5

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    const/4 v0, 0x1

    goto :nq_loop

    :nq_check5
    const-string v4, "\\u041d\\u0435\\u0442 \\u0444\\u0443\\u043d\\u043a\\u0446\\u0438\\u0438"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :nq_loop

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    const/4 v0, 0x1

    goto :nq_loop

    :nq_add
    move-object v4, p0

    move-object v5, p1

    const-string v6, "quick"

    const-string v7, ""

    const-string v8, "\\u0416\\u0431 \\u043d\\u0430 \\u0444\\u043e\\u0440\\u0443\\u043c"

    const-string v9, "\\u0417\\u0434\\u0440\\u0430\\u0432\\u0441\\u0442\\u0432\\u0443\\u0439\\u0442\\u0435, \\u043f\\u043e\\u0434\\u0430\\u0439\\u0442\\u0435 \\u0436\\u0430\\u043b\\u043e\\u0431\\u0443 \\u043d\\u0430 \\u0438\\u0433\\u0440\\u043e\\u043a\\u0430 \\u043d\\u0430 \\u0444\\u043e\\u0440\\u0443\\u043c\\u0435, \\u043f\\u0440\\u0438\\u043a\\u0440\\u0435\\u043f\\u0438\\u0432 \\u0432\\u0438\\u0434\\u0435\\u043e\\u0444\\u0438\\u043a\\u0441\\u0430\\u0446\\u0438\\u044e \\u0441 /time // \\u041f\\u0440\\u0438\\u044f\\u0442\\u043d\\u043e\\u0439 \\u0438\\u0433\\u0440\\u044b."

    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    move-object v4, p0

    move-object v5, p1

    const-string v6, "quick"

    const-string v7, ""

    const-string v8, "\\u041d\\u0435\\u0442 \\u0444\\u0443\\u043d\\u043a\\u0446\\u0438\\u0438"

    const-string v9, "\\u0417\\u0434\\u0440\\u0430\\u0432\\u0441\\u0442\\u0432\\u0443\\u0439\\u0442\\u0435, \\u0434\\u0430\\u043d\\u043d\\u0430\\u044f \\u0444\\u0443\\u043d\\u043a\\u0446\\u0438\\u044f \\u043e\\u0442\\u0441\\u0443\\u0442\\u0441\\u0442\\u0432\\u0443\\u0435\\u0442 \\u043d\\u0430 \\u0441\\u0435\\u0440\\u0432\\u0435\\u0440\\u0435. // \\u041f\\u0440\\u0438\\u044f\\u0442\\u043d\\u043e\\u0439 \\u0438\\u0433\\u0440\\u044b"

    invoke-direct/range {v4 .. v9}, Lru/supportagent/TemplateRepository;->addSeed(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x1

    return v0
.end method

'''
s=s[:m['c0']]+normal+s[m['c1']:]
write(p,s)
print('OK  dedupe: normalizeQuickSeeds + seed_version=5')

# ===================== 2. GEMINI REMOVAL (OverlayService) =====================
p='smali/ru/supportagent/OverlayService.smali'
rep(p,'.field private aiSettings:Lru/supportagent/GeminiSettingsRepository;',
       '.field private aiSettings:Ljava/lang/Object;',label='aiSettings field')

rep(p,'''    :try_start_0
    new-instance v0, Lru/supportagent/GeminiSettingsRepository;

    invoke-direct {v0, p0}, Lru/supportagent/GeminiSettingsRepository;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lru/supportagent/OverlayService;->aiSettings:Lru/supportagent/GeminiSettingsRepository;
    :try_end_0
''','''    :try_start_0
    const/4 v0, 0x0

    iput-object v0, p0, Lru/supportagent/OverlayService;->aiSettings:Ljava/lang/Object;
    :try_end_0
''',label='onCreate no Gemini repo')
rep(p,'''    iput-object v0, p0, Lru/supportagent/OverlayService;->aiSettings:Lru/supportagent/GeminiSettingsRepository;''',
       '''    iput-object v0, p0, Lru/supportagent/OverlayService;->aiSettings:Ljava/lang/Object;''',
    label='onCreate catch null')

s=read(p)
todo=[m for m in methods(s) if 'Gemini' in m['block'] and m['name']!='onCreate']
print('stubbing',len(todo),'methods')
for m in sorted(todo,key=lambda x:-x['c0']):
    if m['name'] in ('showAiChat','showAiSetup'):
        blk='.method '+m['sig']+'''\n    .locals 1

    invoke-static {p0}, Lru/supportagent/AgentAiPage;->show(Landroid/content/Context;)V

    return-void
.end method
'''
    else:
        blk=stub_of(m['sig'])
    s=s[:m['c0']]+blk+s[m['c1']:]
write(p,s)
s=read(p)
print('remaining "Gemini" in OverlayService:',s.count('Gemini'))
# cosmetic rename of the remaining method name
s=s.replace('pasteGeminiApiKey','pasteAiKey')
write(p,s)
print('OK  Gemini code stubbed')

# all other smali: neutralise any leftover Gemini strings (method names / labels)
for root,dirs,files in os.walk(os.path.join(SRC,'smali')):
    for f in files:
        if not f.endswith('.smali'): continue
        fp=os.path.join(root,f)
        t=open(fp,encoding='utf-8').read()
        if 'Gemini' in t:
            t=t.replace('pasteGeminiApiKey','pasteAiKey').replace('GeminiAiClient','SaAiClient').replace('GeminiSettingsRepository','SaAiSettings').replace('Gemini','SaAi')
            open(fp,'w',encoding='utf-8').write(t)
            print('cleaned',f)
for root,dirs,files in os.walk(os.path.join(SRC,'smali_classes2')):
    for f in files:
        if not f.endswith('.smali'): continue
        fp=os.path.join(root,f)
        t=open(fp,encoding='utf-8').read()
        if 'Gemini' in t:
            t=t.replace('GeminiAiClient','SaAiClient').replace('GeminiSettingsRepository','SaAiSettings').replace('Gemini','SaAi')
            open(fp,'w',encoding='utf-8').write(t)
            print('cleaned',f)

# delete Gemini classes + the two lambdas holding their types
for f in glob.glob(os.path.join(SRC,'smali/ru/supportagent/Gemini*.smali'))+[
        os.path.join(SRC,'smali/ru/supportagent/OverlayService$$ExternalSyntheticLambda28.smali'),
        os.path.join(SRC,'smali/ru/supportagent/OverlayService$$ExternalSyntheticLambda36.smali')]:
    os.remove(f); print('DEL',os.path.basename(f))
print('\nDONE p1_new')
