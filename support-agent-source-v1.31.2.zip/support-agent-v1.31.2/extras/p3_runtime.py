# -*- coding: utf-8 -*-
import sys
sys.path.insert(0,'/home/user/patches_v2')
from lib import *

p='smali/ru/supportagent/OverlayService.smali'

def edit_method(s,name,fn,label):
    m=[x for x in methods(s) if x['name']==name]
    assert len(m)==1,(name,len(m))
    m=m[0]; blk=fn(m['block'])
    print('OK  [%s]'%label)
    return s[:m['c0']]+blk+s[m['c1']:]

s=read(p)

# ---------- 1. flicker: keep old window until the new one is on screen ----------
def attach(blk):
    old='.method private attachPanel(Landroid/view/View;Z)V\n    .locals 4\n'
    new='''.method private attachPanel(Landroid/view/View;Z)V
    .locals 6

    iget-object v4, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    move-object v5, p1
'''
    assert blk.count(old)==1
    blk=blk.replace(old,new,1)
    a='    .line 482\n    iput-object p1, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;\n'
    b='    .line 482\n    iput-object v5, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;\n'
    assert blk.count(a)==1; blk=blk.replace(a,b,1)
    a='invoke-interface {p2, p1, v0}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V'
    b='invoke-interface {p2, v5, v0}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V'
    assert blk.count(a)==1; blk=blk.replace(a,b,1)
    a='''    invoke-static {p0, p1, v0}, Lru/supportagent/KeyboardGuard;->install(Landroid/content/Context;Landroid/view/View;Landroid/view/WindowManager$LayoutParams;)V
'''
    b='''    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->removeOldPanel(Landroid/view/View;)V
'''
    assert blk.count(a)==1; blk=blk.replace(a,b,1)
    return blk
s=edit_method(s,'attachPanel',attach,'attachPanel: add new window before removing old')

remove_old='''.method private removeOldPanel(Landroid/view/View;)V
    .locals 2

    if-eqz p1, :ro_exit

    :try_start_0
    iget-object v0, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v0, p1}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :ro_exit

    :ro_exit
    return-void
.end method

'''
s=s.replace('.method private preparePage(Ljava/lang/String;)V\n',remove_old+'.method private preparePage(Ljava/lang/String;)V\n',1)
print('OK  [removeOldPanel helper]')

def prep(blk):
    a='    invoke-direct {p0}, Lru/supportagent/OverlayService;->removePanelOnly()V\n\n'
    assert blk.count(a)==1
    return blk.replace(a,'',1)
s=edit_method(s,'preparePage',prep,'preparePage: keep panel until swap (no flicker)')

# ---------- 2. keyboard: remove the shaking guard, use one-shot fit ----------
def rmp(blk):
    a='    invoke-static {v0}, Lru/supportagent/KeyboardGuard;->release(Landroid/view/View;)V\n\n'
    assert blk.count(a)==1
    return blk.replace(a,'',1)
s=edit_method(s,'removePanelOnly',rmp,'removePanelOnly: drop KeyboardGuard')

def focus(blk):
    a='''    .line 867
    :cond_0
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda0;
'''
    b='''    .line 867
    :cond_0
    invoke-static {v0, p1}, Lru/supportagent/KeyboardFit;->fit(Landroid/view/View;Landroid/widget/EditText;)V

    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda0;
'''
    assert blk.count(a)==1
    return blk.replace(a,b,1)
s=edit_method(s,'focusInput',focus,'focusInput: one-shot KeyboardFit')

def hide(blk):
    a='''    .line 877
    iget-object v0, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    if-eqz v0, :cond_1
'''
    b='''    .line 877
    iget-object v0, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    invoke-static {v0}, Lru/supportagent/KeyboardFit;->reset(Landroid/view/View;)V

    if-eqz v0, :cond_1
'''
    assert blk.count(a)==1
    return blk.replace(a,b,1)
s=edit_method(s,'hideKeyboard',hide,'hideKeyboard: reset translation')

# ADJUST_NOTHING: the framework no longer resizes the overlay; KeyboardFit
# moves the content once instead. No competing resize => no oscillation.
a='    const/16 p1, 0x10\n\n    iput p1, v6, Landroid/view/WindowManager$LayoutParams;->softInputMode:I\n'
b='    const/16 p1, 0x30\n\n    iput p1, v6, Landroid/view/WindowManager$LayoutParams;->softInputMode:I\n'
assert s.count(a)==1; s=s.replace(a,b,1)
print('OK  [softInputMode ADJUST_NOTHING - no system resize fight]')
write(p,s)

# ---------- 3. version ----------
y='apktool.yml'; t=read(y)
t=t.replace('apkFileName: SUPPORT-AGENT-v1.22.0.apk','apkFileName: SUPPORT-AGENT-v1.23.0.apk')
t=t.replace('  versionCode: 59','  versionCode: 60')
t=t.replace('  versionName: 1.22.0','  versionName: 1.23.0')
write(y,t)
print('OK  [version 1.23.0 / 60]')

print('\nremaining KeyboardGuard refs:',read(p).count('KeyboardGuard'))
print('Gemini refs:',read(p).count('Gemini'))
print('DONE p3_runtime')
